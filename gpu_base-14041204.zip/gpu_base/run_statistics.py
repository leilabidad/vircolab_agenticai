import pandas as pd
import re
from pathlib import Path
from datetime import datetime
from src.vision.utils import load_cfg

# --------------------------------------------------
# Config
# --------------------------------------------------
cfg = load_cfg("./config/vision_config.yaml")

files = {
    "WOE_CSV": cfg["paths"]["woe"],
    "FULL_CSV": cfg["paths"]["csv"],
    "TRAIN_CM_CSV": cfg["paths"]["cm_output"],
    "TRAIN_SC_CSV": cfg["paths"]["sc_output"],
    "TEST_CSV": cfg["paths"]["final_mimic_visit_level_test"],
    "TEST_CM_OUT": cfg["paths"]["cm_test_output"],
    "TEST_SC_OUT": cfg["paths"]["sc_test_output"],
}

# --------------------------------------------------
# Utils
# --------------------------------------------------
def extract_number(x):
    x = str(x)
    match = re.findall(r"\d+", x)
    return match[0] if match else None

# --------------------------------------------------
# Load and normalize data
# --------------------------------------------------
dfs = {}
stats = {}
study_sets = {}

for name, path in files.items():
    path = Path(path)
    if not path.exists():
        print(f"{name}: File not found ({path})")
        continue

    df = pd.read_csv(path)

    df["subject_id"] = df["subject_id"].apply(extract_number).astype("string")
    df["study_id"] = df["study_id"].apply(extract_number).astype("string")

    df = df.dropna(subset=["subject_id", "study_id"])

    dfs[name] = df

    unique_subjects = df["subject_id"].nunique()
    unique_visits = df["study_id"].nunique()

    outcome_0 = outcome_1 = outcome_empty = None
    if "outcome" in df.columns:
        outcome_0 = df[df["outcome"] == 0]["study_id"].nunique()
        outcome_1 = df[df["outcome"] == 1]["study_id"].nunique()
        outcome_empty = df[df["outcome"].isna()]["study_id"].nunique()

    stats[name] = {
        "file_name": name,
        "unique_subjects": unique_subjects,
        "unique_visits": unique_visits,
        "outcome_0": outcome_0,
        "outcome_1": outcome_1,
        "outcome_empty": outcome_empty,
    }

    study_sets[name] = set(df["study_id"].unique())

# --------------------------------------------------
# Intersection across all files
# --------------------------------------------------
if study_sets:
    common_all = set.intersection(*study_sets.values())
else:
    common_all = set()

print("################### Number of common study_ids across all files:", len(common_all))

# --------------------------------------------------
# TRAIN_CM + TRAIN_SC + FULL (study_id based)
# --------------------------------------------------
full_df = dfs.get("FULL_CSV")
train_cm_df = dfs.get("TRAIN_CM_CSV")
train_sc_df = dfs.get("TRAIN_SC_CSV")

if full_df is not None and train_cm_df is not None and train_sc_df is not None:

    train_common = pd.merge(
        train_cm_df[["study_id"]],
        train_sc_df[["study_id"]],
        on="study_id",
        how="inner"
    ).drop_duplicates()

    merged_all = pd.merge(
        train_common,
        full_df[["study_id", "outcome"]],
        on="study_id",
        how="inner"
    ).drop_duplicates(subset=["study_id"])

    common_visits = merged_all["study_id"].nunique()

    outcome_0_count = (merged_all["outcome"] == 0).sum()
    outcome_1_count = (merged_all["outcome"] == 1).sum()
    outcome_empty_count = merged_all["outcome"].isna().sum()

    stats["TRAIN_CM_SC_vs_FULL"] = {
        "file_name": "TRAIN_CM_SC_vs_FULL",
        "unique_subjects": None,
        "unique_visits": common_visits,
        "outcome_0": outcome_0_count,
        "outcome_1": outcome_1_count,
        "outcome_empty": outcome_empty_count,
    }

    print("################### Common study_ids in FULL + TRAIN_CM + TRAIN_SC:", common_visits)
    print("Outcome = 0:", outcome_0_count)
    print("Outcome = 1:", outcome_1_count)
    print("Outcome = NaN:", outcome_empty_count)

# --------------------------------------------------
# Save statistics
# --------------------------------------------------
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_file = Path(f"statistics_{timestamp}.csv")

df_stats = pd.DataFrame(stats.values())
df_stats.to_csv(output_file, index=False)

print("Statistics saved to", output_file)
