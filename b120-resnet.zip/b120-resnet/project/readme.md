## main
```
project/
│
├── scripts/
│   └── train_swinnetr.py     
│
├── datasets/
│   └── mri_ssl.py         
│
├── models/
│   └── swinnetr_ssl.py       
│
├── trainers/
│   └── ssl_trainer.py     
│
├── metrics/
│   └── classification.py     
│
├── utils/
│   ├── io.py                
│   └── rotations.py           
```