import torch
import torch.nn as nn

class VGG3D(nn.Module):
    def __init__(self, num_classes=2):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv3d(1, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(2),

            nn.Conv3d(16, 32, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(2),

            nn.Conv3d(32, 64, 3, padding=1),
            nn.ReLU(inplace=True)
        )

        self.pool = nn.AdaptiveAvgPool3d(1)
        self.classifier = nn.Linear(64, num_classes)

    def forward(self, x):
        z = self.encoder(x)
        z = self.pool(z)
        zf = z.flatten(1)
        out = self.classifier(zf)
        return out, zf
