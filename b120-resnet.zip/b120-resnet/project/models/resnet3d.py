import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models.video import r3d_18

class ResNet3D(nn.Module):
    def __init__(self, num_classes):
        super().__init__()
        self.backbone = r3d_18(weights=None)
        self.backbone.stem[0] = nn.Conv3d(
            1, 64, kernel_size=(3,7,7), stride=(1,2,2), padding=(1,3,3), bias=False
        )
        self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)

    def forward(self, x):
        z = self.backbone.stem(x)
        z = self.backbone.layer1(z)
        z = self.backbone.layer2(z)
        z = self.backbone.layer3(z)
        z = self.backbone.layer4(z)
        zf = F.adaptive_avg_pool3d(z, 1).flatten(1)
        out = self.backbone.fc(zf)
        return out, zf
