import torch.nn as nn
import torch.nn.functional as F
from ssl_head import SSLHead

class NTXentLoss(nn.Module):
    def __init__(self,t=0.5):
        super().__init__(); self.t=t
    def forward(self,z1,z2):
        z1,z2=F.normalize(z1,1),F.normalize(z2,1)
        sim=z1@z2.T
        return -sim.mean()

def build_model(feature_size, upsample):
    args=type("A",(),{
        "spatial_dims":3,
        "in_channels":1,
        "feature_size":feature_size,
        "dropout_path_rate":0.1,
        "use_checkpoint":True
    })()
    return SSLHead(args, upsample)
