from .vgg3d import VGG3D

__all__ = ["VGG3D"]
