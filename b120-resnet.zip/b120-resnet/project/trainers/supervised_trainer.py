import os
import time
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
import csv

class SupervisedTrainer:
    def __init__(self, model, train_loader, val_loader, optimizer, output_dir, device,
                 patience=20, monitor_metric="auc", mini_batch=2):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizer = optimizer
        self.device = device
        self.output_dir = output_dir
        self.patience = patience
        self.monitor_metric = monitor_metric
        self.mini_batch = mini_batch

        os.makedirs(output_dir, exist_ok=True)
        self.criterion = nn.CrossEntropyLoss()
        self.metrics_file = os.path.join(output_dir, "metrics.csv")
        with open(self.metrics_file, "w") as f:
            writer = csv.writer(f)
            writer.writerow(["epoch", "train_loss", "val_loss", "auc"])

    def train(self, max_epochs=1000):
        best_metric = -1
        epochs_no_improve = 0
        start = time.time()

        for epoch in range(max_epochs):
            # ---- TRAIN ----
            self.model.train()
            train_loss = 0.0
            for batch in self.train_loader:
                x = batch["image"]
                y = batch["label"].long()

                batch_loss = 0.0
                self.optimizer.zero_grad()

                # Split into mini-sub-batches to save GPU memory
                for start_idx in range(0, x.size(0), self.mini_batch):
                    x_sub = x[start_idx:start_idx+self.mini_batch].to(self.device)
                    y_sub = y[start_idx:start_idx+self.mini_batch].to(self.device)

                    logits, zf = self.model(x_sub)
                    loss = self.criterion(logits, y_sub)
                    loss = loss / (x.size(0) / self.mini_batch)  # scale loss
                    loss.backward()
                    batch_loss += loss.item() * (x.size(0) / self.mini_batch)

                self.optimizer.step()
                train_loss += batch_loss

            train_loss /= len(self.train_loader)

            # ---- VALIDATION ----
            self.model.eval()
            val_loss = 0.0
            all_probs, all_labels = [], []
            all_features, all_feat_labels = [], []

            with torch.no_grad():
                for batch in self.val_loader:
                    x = batch["image"]
                    y = batch["label"].long()

                    for start_idx in range(0, x.size(0), self.mini_batch):
                        x_sub = x[start_idx:start_idx+self.mini_batch].to(self.device)
                        y_sub = y[start_idx:start_idx+self.mini_batch].to(self.device)

                        logits, zf = self.model(x_sub)
                        loss = self.criterion(logits, y_sub)
                        val_loss += loss.item() * x_sub.size(0) / x.size(0)

                        probs = torch.softmax(logits, dim=1)[:,1]
                        all_probs.append(probs.cpu())
                        all_labels.append(y_sub.cpu())
                        all_features.append(zf.cpu())
                        all_feat_labels.append(y_sub.cpu())

            val_loss /= len(self.val_loader)
            all_probs = torch.cat(all_probs).numpy()
            all_labels = torch.cat(all_labels).numpy()
            try:
                auc = roc_auc_score(all_labels, all_probs)
            except:
                auc = 0.0

            features = torch.cat(all_features)
            feat_labels = torch.cat(all_feat_labels)

            print(f"Epoch {epoch+1} | train {train_loss:.4f} | val {val_loss:.4f} | auc {auc:.4f}")
            with open(self.metrics_file, "a") as f:
                writer = csv.writer(f)
                writer.writerow([epoch+1, train_loss, val_loss, auc])

            metric = auc if self.monitor_metric=="auc" else -val_loss

            if metric > best_metric:
                best_metric = metric
                epochs_no_improve = 0
                torch.save(self.model.state_dict(), os.path.join(self.output_dir, "best_model.pth"))
                torch.save({"features": features, "labels": feat_labels},
                           os.path.join(self.output_dir, "best_features.pt"))
            else:
                epochs_no_improve += 1
                if epochs_no_improve >= self.patience:
                    print("⏹ Early stopping triggered")
                    break

        torch.save(self.model.state_dict(), os.path.join(self.output_dir, "final_model.pth"))
        print(f"Training finished in {time.time()-start:.1f}s")
