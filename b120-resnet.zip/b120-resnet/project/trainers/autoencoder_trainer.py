import torch
import torch.nn as nn
import os
import json
from sklearn.metrics import roc_auc_score

class AutoencoderTrainer:
    def __init__(self, model, train_loader, val_loader, optimizer, output_dir, device, patience=20):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizer = optimizer
        self.device = device
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.criterion = nn.MSELoss()
        self.patience = patience
        self.history = {"train_loss": [], "val_loss": [], "val_auc": []}
        self.log_path = os.path.join(self.output_dir, "training_log.json")


    def compute_auc(self):
        self.model.eval()
        y_true, y_scores = [], []

        with torch.no_grad():
            for batch in self.val_loader:
                x = batch["image"].to(self.device)
                labels = batch.get("label", None)

                out = self.model(x)

                if isinstance(out, tuple):
                    out_img = out[0]  
                else:
                    out_img = out

                recon_error = ((out_img - x) ** 2) \
                    .view(x.size(0), -1) \
                    .mean(dim=1) \
                    .cpu().numpy()

                if labels is not None:
                    y_true.extend(labels.cpu().numpy())
                    y_scores.extend(recon_error)

        if len(y_true) == 0:
            return None

        return roc_auc_score(y_true, y_scores)



    def train(self, max_epochs):
        best_metric = -float("inf")

        epochs_no_improve = 0

        for epoch in range(max_epochs):
            # ----- Training -----
            self.model.train()
            total_loss = 0
            for batch in self.train_loader:
                x = batch["image"].to(self.device)
                self.optimizer.zero_grad()
                out = self.model(x)
                if isinstance(out, tuple):
                    out = out[0]
                loss = self.criterion(out, x)
                loss.backward()
                self.optimizer.step()
                total_loss += loss.item()
            train_loss = total_loss / len(self.train_loader)

            # ----- Validation -----
            self.model.eval()
            val_loss_total = 0
            with torch.no_grad():
                for batch in self.val_loader:
                    x = batch["image"].to(self.device)
                    out = self.model(x)
                    if isinstance(out, tuple):
                        out = out[0]
                    val_loss_total += self.criterion(out, x).item()
            val_loss = val_loss_total / len(self.val_loader)
            val_auc = self.compute_auc()

            print(f"Epoch {epoch}: Train Loss={train_loss:.6f}, Val Loss={val_loss:.6f}, Val AUC={val_auc if val_auc is not None else 'N/A'}")

            self.history["train_loss"].append(train_loss)
            self.history["val_loss"].append(val_loss)
            self.history["val_auc"].append(val_auc if val_auc is not None else 0)
            with open(self.log_path, "w") as f:
                json.dump(self.history, f, indent=4)

            # ----- Early stopping based on AUC if available, otherwise Val Loss -----
            if val_auc is not None:
                metric = val_auc
            else:
                metric = -val_loss 

            if metric > best_metric:
                best_metric = metric
                epochs_no_improve = 0
                torch.save(self.model.state_dict(), os.path.join(self.output_dir, "best_model.pth"))
            else:
                epochs_no_improve += 1
                if epochs_no_improve >= self.patience:
                    print(f"Early stopping triggered at epoch {epoch}")
                    break

        torch.cuda.empty_cache()
