import os
import csv
import torch
import pandas as pd

def save_summary_csv_from_metrics(output_dir, filename="summary.csv"):
    rows = []
    for f in os.listdir(output_dir):
        if not f.endswith(".json"):
            continue
        path = os.path.join(output_dir, f)
        with open(path) as j:
            d = eval(j.read())
            d["run"] = f.replace(".json", "")
            rows.append(d)
    if not rows:
        return
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(output_dir, filename), index=False)

def save_features_safe(model, dataset, output_dir, batch_size=4, device="cuda", mini_batch=2):
    import os, torch
    from torch.utils.data import DataLoader

    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=2)

    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"]
            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for start_idx in range(0, x.size(0), mini_batch):
                x_sub = x[start_idx:start_idx+mini_batch].to(device)
                out = _model(x_sub)

                z = out[-1] if isinstance(out, (tuple, list)) else out
                if z.dim() > 2:
                    z = torch.flatten(z, start_dim=1)

                z_cpu = z.cpu()
                for i in range(z_cpu.size(0)):
                    fname = os.path.basename(str(filenames[start_idx + i])).replace(".nii.gz", "")
                    torch.save(z_cpu[i], os.path.join(features_dir, f"{fname}_feat.pt"))


def save_features_individual(model, dataset, output_dir, batch_size=4, device="cuda"):
    import os
    import torch

    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)
    loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=False)
    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"].to(device)
            out = _model(x)

            if isinstance(out, tuple) or isinstance(out, list):
                z = out[-1]
            else:
                z = out

            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for i in range(z.size(0)):
                fname = os.path.basename(str(filenames[i]))
                fname = fname.replace(".nii.gz", "")

                torch.save(
                    z[i].cpu(),
                    os.path.join(features_dir, f"{fname}_feat.pt")
                )




def save_features_individual_swinunnetr(
    model,
    dataset,
    output_dir,
    batch_size=4,
    device="cuda"
):


    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)

    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False
    )

    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"].to(device)
            out = _model(x)

            if isinstance(out, dict):
                z = out.get("logits", list(out.values())[-1])
            elif isinstance(out, (tuple, list)):
                z = out[-1]
            else:
                z = out

            if z.dim() > 2:
                z = torch.flatten(z, start_dim=1)

            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for i in range(z.size(0)):
                fname = os.path.basename(str(filenames[i]))
                fname = fname.replace(".nii.gz", "")

                torch.save(
                    z[i].cpu(),
                    os.path.join(features_dir, f"{fname}_feat.pt")
                )




def save_features_individual_autoencoder(
    model,
    dataset,
    output_dir,
    batch_size=4,
    device="cuda"
):
    model.eval()

    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)

    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False
    )

    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"].to(device)

            out = _model(x)
            if not isinstance(out, tuple):
                raise RuntimeError("Autoencoder must return (recon, z)")

            _, z = out  # latent features

            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for i in range(z.size(0)):
                fname = os.path.basename(str(filenames[i]))
                fname = fname.replace(".nii.gz", "")

                torch.save(
                    z[i].cpu(),
                    os.path.join(features_dir, f"{fname}_feat.pt")
                )


def save_summary_single_row(output_dir, results_dict):
    summary_file = os.path.join(output_dir, "summary.csv")
    df = pd.DataFrame([results_dict])
    df.to_csv(summary_file, index=False)
    print(f"[INFO] Summary saved: {summary_file}")
