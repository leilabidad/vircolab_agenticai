import torch

def random_rotations(x):
    b = x.shape[0]
    labels = torch.randint(0, 4, (b,), device=x.device)
    out = []
    for i in range(b):
        out.append(torch.rot90(x[i], labels[i].item(), dims=(2, 3)))
    return torch.stack(out), labels
