import os
import subprocess
import pandas as pd

# -------------------- User Inputs --------------------
dataset_dir = input("Dataset directory [./Prostate]: ") or "./Prostate"
model = input("Model name [vgg3d]: ") or "vgg3d"
batch_size = int(input("Batch size [500]: ") or 500)
gpus = input("GPUs to use [0,1,2,3]: ") or "0,1,2,3"
early_stop_patience = int(input("Early stop patience [20]: ") or 20)
base_output_dir = input("Base output directory [./results/ch7]: ") or "./results/ch7"
chunk_size = int(input("Number of files per chunk [300]: ") or 300)
summary_filename = "summary.csv"
final_summary_file = os.path.join(base_output_dir, "final_summary.csv")

# -------------------- List and filter files --------------------
all_files = sorted([f for f in os.listdir(dataset_dir) if f.endswith(".nii.gz")])
valid_files = []

for f in all_files:
    file_path = os.path.join(dataset_dir, f)
    if os.path.getsize(file_path) > 0:
        valid_files.append(f)
    else:
        print(f"[WARN] Skipping empty/corrupted file: {f}")

if not valid_files:
    raise RuntimeError("No valid .nii.gz files found in dataset_dir!")

# -------------------- Process in chunks --------------------
num_files = len(valid_files)
num_chunks = (num_files + chunk_size - 1) // chunk_size

i = 0
while i < num_chunks:
    start_idx = i * chunk_size
    end_idx = min((i + 1) * chunk_size, num_files)
    chunk_files = valid_files[start_idx:end_idx]

    if i == num_chunks - 1 and len(chunk_files) < 2 and i > 0:
        start_idx = (i - 1) * chunk_size
        chunk_files = valid_files[start_idx:]
        i = num_chunks - 1

    chunk_dir_name = f"{model}-b{batch_size}-pc{i+1}"
    output_dir = os.path.join(base_output_dir, chunk_dir_name)
    os.makedirs(output_dir, exist_ok=True)

    chunk_dataset_dir = os.path.join(output_dir, "chunk_data")
    os.makedirs(chunk_dataset_dir, exist_ok=True)

    for f in chunk_files:
        src = os.path.join(dataset_dir, f)
        dst = os.path.join(chunk_dataset_dir, f)
        if not os.path.exists(dst):
            os.symlink(os.path.abspath(src), dst)

    real_batch_size = min(batch_size, len(chunk_files))

    cmd = [
        "python", "-m", "project.scripts.train_swinnetr",
        "--model", model,
        "--dataset_dir", chunk_dataset_dir,
        "--batch_size", str(real_batch_size),
        "--output_dir", output_dir,
        "--gpus", gpus,
        "--early_stop_patience", str(early_stop_patience)
    ]

    print(f"[INFO] Running chunk {i+1} with {len(chunk_files)} files (batch_size={real_batch_size})...")
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError:
        print(f"[ERROR] Chunk {i+1} failed. Skipping to next chunk.")

    i += 1

# -------------------- Collect final summary --------------------
chunk_dirs = sorted([
    os.path.join(base_output_dir, d)
    for d in os.listdir(base_output_dir)
    if os.path.isdir(os.path.join(base_output_dir, d)) and d.startswith(model)
])

last_summary_row = None
for chunk_dir in chunk_dirs:
    summary_path = os.path.join(chunk_dir, summary_filename)
    if os.path.exists(summary_path):
        df = pd.read_csv(summary_path)
        if not df.empty:
            last_summary_row = df.iloc[[-1]]

if last_summary_row is not None:
    last_summary_row.to_csv(final_summary_file, index=False)
    print(f"[OK] Final summary saved to: {final_summary_file}")
else:
    print("[WARN] No summary row found in any chunk.")
