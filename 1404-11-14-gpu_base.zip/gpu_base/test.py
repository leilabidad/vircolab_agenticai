import pandas as pd

# CSV path
csv_path = "./results/cm_test_output.csv"

# Load CSV
df = pd.read_csv(csv_path)

# Print column names
print("Columns in CSV:")
for col in df.columns:
    print(col)

