import re
import pandas as pd
import numpy as np
from sklearn.metrics import (
    roc_auc_score,
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

# ============================================================
# Safe CSV loader
# ============================================================
def safe_read_csv(path, name):
    try:
        df = pd.read_csv(path)
        print(f"{name} loaded | rows: {len(df)}")
        return df
    except Exception as e:
        print(f"Warning: Failed to load {name}: {e}")
        return None

# ============================================================
# Load DCS test output
# ============================================================
rf_df = safe_read_csv("./results/embedding_rf.csv", "DCS_RF")

if rf_df is None:
    raise RuntimeError("DCS_RF file is required!")

# rename Rf_pred to Rf
if "Rf_pred" in rf_df.columns:
    rf_df = rf_df.rename(columns={"Rf_pred": "Rf"})

required_cols = {"subject_id", "study_id", "outcome", "Rf"}
if not required_cols.issubset(rf_df.columns):
    raise ValueError(f"embedding_rf.csv must contain columns: {required_cols}")

# ============================================================
# Load SwinNet test output (optional)
# ============================================================
swin_df = safe_read_csv("./results/cm_test_output.csv", "SwinNet")

# ---------------------------
# Extract numeric IDs from subject_id and study_id
# ---------------------------

def extract_numbers(x):
    if pd.isna(x):
        return ""
    x = str(x)
    nums = re.findall(r'\d+', x)
    return nums[0] if nums else ""

for col in ["subject_id", "study_id"]:
    if col in swin_df.columns:
        swin_df[col] = swin_df[col].apply(extract_numbers)
        swin_df[col] = swin_df[col].astype(str)

for col in ["subject_id", "study_id"]:
    if col in rf_df.columns:
        rf_df[col] = rf_df[col].apply(extract_numbers)
        rf_df[col] = rf_df[col].astype(str)



if swin_df is None:
    # File missing → create dummy column
    print("Warning: SwinNet file not found. Using NaN for swin_score.")
    rf_df["swin_score"] = np.nan
    df = rf_df.copy()
    evaluate_swin = False
else:
    # Ensure column exists
    if "swin_score" not in swin_df.columns:
        swin_df["swin_score"] = np.nan
    # merge with rf_df
    df = rf_df.merge(
        swin_df[["subject_id", "study_id", "swin_score"]],
        on=["subject_id", "study_id"],
        how="left"
    )
    evaluate_swin = True

print(f"Rows after merge: {len(df)}")

# ============================================================
# Ground truth
# ============================================================
df = df[df["outcome"].isin([0, 1])].reset_index(drop=True)

y_true = df["outcome"].astype(int).values
dcs_score = df["Rf"].astype(float).values
swin_score = df["swin_score"].astype(float).values if evaluate_swin else None

# ============================================================
# Evaluation function
# ============================================================
def evaluate_model(y_true, score, model_name, threshold=0.5):
    # Handle NaN scores
    score = np.nan_to_num(score, nan=0.0)
    y_pred = (score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()

    return {
        "model": model_name,
        "threshold": threshold,
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp + 1e-8),
        "f1_score": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, score)
    }

# ============================================================
# Run evaluation
# ============================================================
metrics = []

# DCS always
metrics.append(evaluate_model(y_true, dcs_score, "DCS"))

# SwinNet if available
if evaluate_swin:
    metrics.append(evaluate_model(y_true, swin_score, "SwinNet_2D"))

metrics_df = pd.DataFrame(metrics)
metrics_df.to_csv("./results/comparison_metrics_final0.csv", index=False)

print("✅ Evaluation completed successfully.")
print(metrics_df)
