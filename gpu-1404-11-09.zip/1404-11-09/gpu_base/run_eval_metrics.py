import pandas as pd
import numpy as np
import json
import yaml
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    balanced_accuracy_score,
    roc_curve
)

# ---------------------------
# Load configuration
# ---------------------------
with open("./config/config.yaml") as f:
    cfg = yaml.safe_load(f)

# ---------------------------
# Safe CSV loader
# ---------------------------
def safe_read_csv(path, name):
    try:
        df = pd.read_csv(path)
        print(f"{name} loaded, rows: {len(df)}")
        return df
    except Exception as e:
        print(f"Error loading {name}: {e}")
        return pd.DataFrame()

cm_df = safe_read_csv(cfg["paths"]["cm_test_output"], "CM")
sc_df = safe_read_csv(cfg["paths"]["sc_test_output"], "SC")
out_df = safe_read_csv(cfg["paths"]["mimic_prepared_csv"], "OUT")

# ---------------------------
# Load weights and scalers
# ---------------------------
def safe_load_json(path, name):
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return {}

weights = safe_load_json("../gpu_base/results/dcs_weights.json", "weights")
scalers = safe_load_json("../gpu_base/results/scalers.json", "scalers")

# ---------------------------
# Normalize IDs
# ---------------------------
for df in [cm_df, sc_df, out_df]:
    for col in ["subject_id", "study_id"]:
        if col in df.columns:
            df[col] = df[col].astype(str)

# ---------------------------
# Merge for DCS evaluation
# ---------------------------
merged_df = cm_df.merge(sc_df, on=["subject_id","study_id"], how="outer", indicator=True)
merged_df = merged_df[merged_df["_merge"]=="both"].drop(columns="_merge")
merged_df = merged_df.merge(out_df, on=["subject_id","study_id"], how="inner")
df = merged_df.copy()
print(f"Rows after merge: {len(df)}")

# ---------------------------
# Compute CM scalar
# ---------------------------
cm_cols = [c for c in df.columns if c.startswith("cm_")]
Cm_raw = df[cm_cols].mean(axis=1).values if cm_cols else np.zeros(len(df))
cm_range = scalers.get("cm_max",1) - scalers.get("cm_min",0)
cm_range = cm_range if cm_range!=0 else 1
Cm = np.clip((Cm_raw - scalers.get("cm_min",0))/cm_range, 0, 1)
df["Cm"] = Cm
print(f"Cm min/max: {Cm.min():.4f}/{Cm.max():.4f}")

# ---------------------------
# Compute SC scalar
# ---------------------------
def parse_embedding(x):
    try:
        arr = np.array(json.loads(x))
        return arr.mean() if arr.size>0 else np.nan
    except:
        return np.nan

Sc_raw = np.array([parse_embedding(x) for x in df.get("sc_embedding",[])])
Sc_raw = np.nan_to_num(Sc_raw, nan=0.0)
sc_range = scalers.get("sc_max",1) - scalers.get("sc_min",0)
sc_range = sc_range if sc_range!=0 else 1
Sc = np.clip((Sc_raw - scalers.get("sc_min",0))/sc_range,0,1)
df["Sc"] = Sc
print(f"Sc min/max: {Sc.min():.4f}/{Sc.max():.4f}")

# ---------------------------
# Compute final Rf for DCS
# ---------------------------
w1, w2, w3, b = weights.get("w1",0), weights.get("w2",0), weights.get("w3",0), weights.get("intercept",0)
Rf = np.clip(w1*Cm + w2*Sc + w3*(Cm*Sc) + b, 0, 1)
df["Rf"] = Rf

# ---------------------------
# Ground truth
# ---------------------------
df = df[df["outcome"].isin([0,1])]
y_true = df["outcome"]

# ---------------------------
# Evaluation function
# ---------------------------
def evaluate(y_true, y_prob, name):
    # ROC-based threshold
    if len(np.unique(y_true))>1:
        fpr, tpr, thresholds = roc_curve(y_true, y_prob)
        j_scores = tpr - fpr
        threshold = thresholds[np.argmax(j_scores)]
    else:
        threshold = 0.5

    y_pred = (y_prob >= threshold).astype(int)
    cm_matrix = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm_matrix.ravel() if cm_matrix.shape==(2,2) else (np.nan, np.nan, np.nan, np.nan)
    specificity = tn/(tn+fp) if (tn+fp)!=0 else np.nan

    metrics = {
        "model": name,
        "threshold": threshold,
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "specificity": specificity,
        "f1_score": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_prob) if len(np.unique(y_true))>1 else np.nan
    }
    return metrics

# ---------------------------
# Compute metrics for both
# ---------------------------
metrics_list = []
metrics_list.append(evaluate(y_true, Cm, "SwinNet_2D"))
metrics_list.append(evaluate(y_true, Rf, "DCS"))

# ---------------------------
# Save Comparision metrics
# ---------------------------

metrics_df = pd.DataFrame(metrics_list)
metrics_df.to_csv("../gpu_base/results/comparision_metrics.csv", index=False)
print("✅ Comparision evaluation completed and saved.")
