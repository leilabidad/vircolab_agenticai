import os
import json
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import GradScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

class SSLTrainer:
    def __init__(self, model, train_loader, val_loader, optimizer, output_dir, device):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizer = optimizer
        self.device = device
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.metric_log_file = os.path.join(output_dir, "metrics.json")
        self.scaler = GradScaler()
        self.rot_criterion = nn.CrossEntropyLoss()
        self.recon_criterion = nn.MSELoss()

    def nt_xent_loss(self, zis, zjs=None, temperature=0.5, eps=1e-8):
        if zjs is None: zjs = zis
        batch_size = zis.size(0)
        zis = F.normalize(zis, p=2, dim=1)
        zjs = F.normalize(zjs, p=2, dim=1)
        reps = torch.cat([zis, zjs], dim=0)
        sim_matrix = torch.mm(reps, reps.t())
        mask = torch.eye(batch_size*2, device=zis.device).bool()
        positives = sim_matrix[mask].view(batch_size*2, 1)
        negatives = sim_matrix[~mask].view(batch_size*2, -1)
        numerator = torch.exp(positives / temperature)
        denominator = torch.exp(negatives / temperature).sum(dim=1, keepdim=True) + numerator
        return -torch.log(numerator / (denominator+eps)).mean()

    def compute_metrics(self, features, labels):
        if len(labels) < 2: return {}
        preds = torch.argmax(features, dim=1).cpu().numpy()
        labels = labels.cpu().numpy()
        binary_labels = (labels != 0).astype(int)
        binary_preds = (preds != 0).astype(int)
        metrics = {
            "accuracy": accuracy_score(binary_labels, binary_preds),
            "precision": precision_score(binary_labels, binary_preds, zero_division=0),
            "recall": recall_score(binary_labels, binary_preds, zero_division=0),
            "f1": f1_score(binary_labels, binary_preds, zero_division=0),
            "confusion_matrix": confusion_matrix(binary_labels, binary_preds).tolist()
        }
        try:
            metrics["auc"] = roc_auc_score(binary_labels, F.softmax(features, dim=1).cpu().numpy()[:,1])
        except:
            metrics["auc"] = None
        return metrics

    def apply_random_rotations(self, images):
        batch_size, c, h, w, d = images.shape
        rotated_images = torch.empty_like(images)
        rotations = torch.randint(0, 4, (batch_size,), device=images.device)
        for i in range(batch_size):
            img = images[i]
            k = rotations[i].item()
            axis = torch.randint(0, 3, (1,), device=images.device).item()
            if axis==0: img_rot = torch.rot90(img, k, [1,2])
            elif axis==1: img_rot = torch.rot90(img, k, [1,3])
            else: img_rot = torch.rot90(img, k, [2,3])
            rotated_images[i] = img_rot
        return rotated_images, rotations

    def train(self, max_epochs=1000, patience=20):
        best_val_loss = float('inf')
        epochs_no_improve = 0
        start_time = time.time()
        for epoch in range(max_epochs):
            self.model.train()
            total_train_loss = 0
            for i, batch in enumerate(self.train_loader):
                inputs = batch["image"].to(self.device)
                labels = torch.tensor(batch["label"], dtype=torch.long, device=self.device)
                rot_inputs_1, rot_labels_1 = self.apply_random_rotations(inputs)
                rot_inputs_2, _ = self.apply_random_rotations(inputs)
                with torch.cuda.amp.autocast():
                    x_rot_1, x_contrastive_1, x_rec_1 = self.model(rot_inputs_1)
                    _, x_contrastive_2, _ = self.model(rot_inputs_2)
                    loss_rot = self.rot_criterion(x_rot_1, rot_labels_1)
                    loss_contrastive = self.nt_xent_loss(x_contrastive_1, x_contrastive_2)
                    inputs_resized = F.interpolate(inputs, size=x_rec_1.shape[2:], mode='trilinear', align_corners=False)
                    loss_recon = self.recon_criterion(x_rec_1, inputs_resized)
                    loss = loss_rot + loss_contrastive + loss_recon
                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad()
                total_train_loss += loss.item()
            avg_train_loss = total_train_loss / len(self.train_loader)

            self.model.eval()
            total_val_loss = 0
            val_features_list = []
            val_labels_list = []
            with torch.no_grad():
                for batch in self.val_loader:
                    inputs = batch["image"].to(self.device)
                    labels = torch.tensor(batch["label"], dtype=torch.long, device=self.device)
                    x_rot, x_contrastive, x_rec = self.model(inputs)
                    inputs_resized = F.interpolate(inputs, size=x_rec.shape[2:], mode='trilinear', align_corners=False)
                    loss_val = self.recon_criterion(x_rec, inputs_resized)
                    total_val_loss += loss_val.item()
                    val_features_list.append(x_contrastive)
                    val_labels_list.append(labels)
            avg_val_loss = total_val_loss / len(self.val_loader)
            val_features = torch.cat(val_features_list, dim=0)
            val_labels = torch.cat(val_labels_list, dim=0)
            metrics = self.compute_metrics(val_features, val_labels)
            with open(self.metric_log_file, "a") as f:
                f.write(json.dumps({"epoch": epoch+1, "train_loss": avg_train_loss, "val_loss": avg_val_loss, "metrics": metrics})+"\n")
            print(f"Epoch {epoch+1} | Train: {avg_train_loss:.5f} | Val: {avg_val_loss:.5f} | Metrics: {metrics}")

            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                epochs_no_improve = 0
                torch.save(self.model.state_dict(), os.path.join(self.output_dir, "best_model.pth"))
            else:
                epochs_no_improve += 1
                if epochs_no_improve >= patience:
                    print(f"Early stopping at epoch {epoch+1}")
                    break
        torch.save(self.model.state_dict(), os.path.join(self.output_dir, "final_model.pth"))
        print(f"Training completed in {time.time()-start_time:.2f} seconds")
