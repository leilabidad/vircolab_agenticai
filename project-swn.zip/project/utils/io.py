import os
import csv
import pandas as pd

def save_summary_csv_from_metrics(output_dir, filename="summary.csv"):
    rows = []
    for f in os.listdir(output_dir):
        if not f.endswith(".json"):
            continue
        path = os.path.join(output_dir, f)
        with open(path) as j:
            d = eval(j.read())
            d["run"] = f.replace(".json", "")
            rows.append(d)
    if not rows:
        return
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(output_dir, filename), index=False)
