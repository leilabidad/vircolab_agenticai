import re
import pandas as pd
import numpy as np
import torch
import yaml
import json
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, confusion_matrix
)
from sklearn.linear_model import LinearRegression

# -------------------------------
# Load configuration
# -------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# -------------------------------
# Load data
# -------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_test_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_test_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# -------------------------------
# Normalize IDs
# -------------------------------
def extract_number(x):
    x = str(x)
    match = re.findall(r'\d+', x)
    return match[0] if match else "0"

for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].apply(extract_number)
    df["study_id"] = df["study_id"].apply(extract_number)

# -------------------------------
# Merge datasets
# -------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(sc_df[["subject_id", "study_id", "sc_embedding"]],
           on=["subject_id", "study_id"], how="inner")
    .merge(out_df[["subject_id", "study_id", "outcome"]],
           on=["subject_id", "study_id"], how="inner")
)

if len(base_df) == 0:
    raise ValueError("No aligned samples after merge! Check IDs.")

# -------------------------------
# Process CM (mean + MinMax)
# -------------------------------
cm_embeds = torch.tensor(base_df[cm_cols].values, dtype=torch.float32)
cm_proj = cm_embeds.mean(dim=1).numpy().reshape(-1, 1)  # میانگین ستون‌ها
cm_scaled = MinMaxScaler().fit_transform(cm_proj).ravel()

# -------------------------------
# Process SC embeddings
# -------------------------------
def parse_embedding(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        try:
            return [float(x) for x in value.strip("[]").split(",")]
        except ValueError:
            return None
    if isinstance(value, (list, tuple)):
        return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding)
parsed_embeddings = parsed_embeddings.dropna()
EXPECTED_DIM = parsed_embeddings.apply(len).iloc[0]
valid_mask = parsed_embeddings.apply(lambda x: x is not None and len(x) == EXPECTED_DIM)

base_df = base_df.loc[valid_mask].reset_index(drop=True)
sc_vectors = parsed_embeddings.loc[valid_mask].tolist()
cm_scaled = cm_scaled[valid_mask.values]

sc_embeds = torch.tensor(sc_vectors, dtype=torch.float32)
sc_proj = sc_embeds.mean(dim=1).numpy().reshape(-1, 1)
sc_scaled = MinMaxScaler().fit_transform(sc_proj).ravel()

# -------------------------------
# Features for all models (processed CM)
# -------------------------------
Cm = cm_scaled
Sc = sc_scaled
Cm_Sc = Cm * Sc
Cm2 = Cm ** 2
Sc2 = Sc ** 2

X_processed = np.column_stack([Cm, Sc, Cm_Sc, Cm2, Sc2])
y_true = base_df["outcome"].astype(int).values

# -------------------------------
# SwinNet proxy (linear regression on CM columns)
# -------------------------------
lr_model = LinearRegression()
lr_model.fit(cm_embeds.numpy(), y_true)  # از CM اصلی میانگین گرفته شده استفاده می‌کنیم
df_swin = base_df[["subject_id", "study_id"]].copy()
df_swin["Rf_SwinNet"] = MinMaxScaler().fit_transform(
    lr_model.predict(cm_embeds.numpy()).reshape(-1,1)
).ravel()

# -------------------------------
# Compute QFL & DCS weights using same processed CM
# -------------------------------
lr_qfl = LinearRegression()
lr_qfl.fit(X_processed, y_true)
qfl_weights = lr_qfl.coef_.tolist()
qfl_intercept = lr_qfl.intercept_

df_final = base_df[["subject_id", "study_id", "outcome"]].copy()
df_final["Cm"] = Cm
df_final["Sc"] = Sc
df_final["Cm_Sc"] = Cm_Sc
df_final["Cm2"] = Cm2
df_final["Sc2"] = Sc2

df_final["Rf_QFL"] = (
    qfl_weights[0]*Cm + qfl_weights[1]*Sc + qfl_weights[2]*Cm_Sc +
    qfl_weights[3]*Cm2 + qfl_weights[4]*Sc2 + qfl_intercept
)

# DCS (میانگین CM هم استفاده می‌شود)
lr_dcs = LinearRegression()
lr_dcs.fit(np.column_stack([Cm, Sc, Cm_Sc]), y_true)
dcs_weights = lr_dcs.coef_.tolist()
dcs_intercept = lr_dcs.intercept_

df_final["Rf_DCS"] = (
    dcs_weights[0]*Cm + dcs_weights[1]*Sc + dcs_weights[2]*Cm_Sc + dcs_intercept
)

# -------------------------------
# Save weights
# -------------------------------
weights_json = {
    "swinnet_weights": lr_model.coef_.tolist(),
    "swinnet_intercept": float(lr_model.intercept_),
    "qfl_weights": qfl_weights,
    "qfl_intercept": float(qfl_intercept),
    "dcs_weights": dcs_weights,
    "dcs_intercept": float(dcs_intercept)
}

with open(cfg["paths"]["qfl_weights_json"], "w") as f:
    json.dump(weights_json, f, indent=4)

# -------------------------------
# Threshold finder & evaluation
# -------------------------------
def find_best_threshold(y, scores):
    scores = np.nan_to_num(scores)
    ts = np.linspace(scores.min(), scores.max(), 200)
    best_t, best_ba = ts[0], 0
    for t in ts:
        y_pred = (scores >= t).astype(int)
        ba = balanced_accuracy_score(y, y_pred)
        if ba > best_ba:
            best_ba = ba
            best_t = t
    return best_t

def evaluate(y, score, name, threshold):
    score = np.nan_to_num(score)
    y_pred = (score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    return {
        "model": name,
        "threshold": threshold,
        "accuracy": accuracy_score(y, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y, y_pred),
        "precision": precision_score(y, y_pred, zero_division=0),
        "recall": recall_score(y, y_pred, zero_division=0),
        "specificity": tn / (tn + fp + 1e-8),
        "f1": f1_score(y, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y, score),
    }

metrics = []
metrics.append(evaluate(y_true, df_final["Rf_QFL"].values, "QFL", 0.5))
metrics.append(evaluate(y_true, df_final["Rf_DCS"].values, "DCS", 0.5))
best_swin_t = find_best_threshold(y_true, df_swin["Rf_SwinNet"].values)
metrics.append(evaluate(y_true, df_swin["Rf_SwinNet"].values, "SwinNet_Proxy", best_swin_t))

metrics_df = pd.DataFrame(metrics)
df_final.to_csv(cfg["paths"]["rf_qfl_output"], index=False)
metrics_df.to_csv("./results/final_comparison_metrics.csv", index=False)

print(metrics_df)
print("Best SwinNet threshold:", best_swin_t)
