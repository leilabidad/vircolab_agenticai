import pandas as pd
import json

df = pd.read_csv("./results/sc_test_output.csv")
emb = json.loads(df["sc_embedding"].iloc[101])
print(len(emb))

import numpy as np

print("min:", np.min(emb))
print("max:", np.max(emb))

