import subprocess

def main():
    options = {
        "0": "run_prepare_metadata.py",
        "1": "run_prepare_dataset.py",
        "2": "run_minimize_dataset.py",
        "3": "run_train_swin_cm.py",
        "4": "run_compute_sc.py",
        "5": "run_compute_dcs_weights.py",
        "6": "run_compute_qfl_weights.py",
        "7": "run_compute_cm_test_dst.py",
        "8": "run_compute_sc_test_dst.py",
        "9": "run_eval_metrics.py",
        "10": "run_eval_metrics_fixed_tershold.py",
        "11": "run_statistics.py",
        #"10": "run_eval_metrics_qfl.py",
        #"11": "run_eval_metrics_qfl_dcs_swin_newswin.py"
        #"11": "run_eval_metrics.py"
       
    }

    print("Select the action to perform:")
    print("0: Prepare metadata")
    print("1: Prepare dataset")
    print("2: Minimize dataset")
    print("3: Train SwinNet 2D and compute Cm")
    print("4: Compute Sc")
    print("5: Compute DCS weights")
    print("6: Compute QFL weights")
    print("7: Run compute Cm embedding for Test dataset")
    print("8: Run compute Sc embedding for Test dataset")
    print("9: Run compute RF & Evaluation Metrics")
    print("10: Run compute RF & Evaluation Metrics (Fixed Threshold)")
    print("11: Final Statistics")
    #print("10: Run compute RF & Evaluation Metrics ML OF QFL")
    #print("11: Run compute RF & Evaluation Metrics ML OF QFL + DCS + SwinNet NewSwin")
        
    choice = input("Enter your choice (0-11): ").strip()
    script = options.get(choice)
    
    if script:
        subprocess.run(["python", script])
    else:
        print("Invalid choice")

if __name__ == "__main__":
    main()
