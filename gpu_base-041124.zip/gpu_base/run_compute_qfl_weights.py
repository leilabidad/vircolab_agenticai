import re
import pandas as pd
import numpy as np
import torch
import yaml
import json
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression

# -------------------------------
# Load configuration
# -------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# -------------------------------
# Load data
# -------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# -------------------------------
# Normalize IDs
# -------------------------------
def extract_number(x):
    x = str(x)
    match = re.findall(r'\d+', x)
    return match[0] if match else "0"

for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].apply(extract_number)
    df["study_id"] = df["study_id"].apply(extract_number)

# -------------------------------
# Merge datasets
# -------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(sc_df[["subject_id", "study_id", "sc_embedding"]],
           on=["subject_id", "study_id"], how="inner")
    .merge(out_df[["subject_id", "study_id", "outcome"]],
           on=["subject_id", "study_id"], how="inner")
)

if len(base_df) == 0:
    raise ValueError("No aligned samples after merge! Check IDs.")

# -------------------------------
# Process CM (mean + MinMax)
# -------------------------------
cm_embeds = torch.tensor(base_df[cm_cols].values, dtype=torch.float32)
cm_proj = cm_embeds.mean(dim=1).numpy().reshape(-1, 1)  # میانگین ستون‌ها
cm_scaled = MinMaxScaler().fit_transform(cm_proj).ravel()

# -------------------------------
# Process SC embeddings
# -------------------------------
def parse_embedding(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        try:
            return [float(x) for x in value.strip("[]").split(",")]
        except ValueError:
            return None
    if isinstance(value, (list, tuple)):
        return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding)
parsed_embeddings = parsed_embeddings.dropna()
EXPECTED_DIM = parsed_embeddings.apply(len).iloc[0]
valid_mask = parsed_embeddings.apply(lambda x: x is not None and len(x) == EXPECTED_DIM)

base_df = base_df.loc[valid_mask].reset_index(drop=True)
sc_vectors = parsed_embeddings.loc[valid_mask].tolist()
cm_scaled = cm_scaled[valid_mask.values]

sc_embeds = torch.tensor(sc_vectors, dtype=torch.float32)
sc_proj = sc_embeds.mean(dim=1).numpy().reshape(-1, 1)
sc_scaled = MinMaxScaler().fit_transform(sc_proj).ravel()

# -------------------------------
# Prepare features for QFL (processed CM)
# -------------------------------
Cm = cm_scaled
Sc = sc_scaled
Cm_Sc = Cm * Sc
Cm2 = Cm ** 2
Sc2 = Sc ** 2

X_processed = np.column_stack([Cm, Sc, Cm_Sc, Cm2, Sc2])
y_true = base_df["outcome"].astype(int).values

# -------------------------------
# Linear Regression to compute weights (mean CM)
# -------------------------------
lr_model = LinearRegression()
lr_model.fit(X_processed, y_true)
weights = lr_model.coef_.tolist()
intercept = lr_model.intercept_

weights_json = {
    "w1": float(weights[0]),
    "w2": float(weights[1]),
    "w3": float(weights[2]),
    "w4": float(weights[3]),
    "w5": float(weights[4]),
    "intercept": float(intercept)
}

with open(cfg["paths"]["qfl_weights_json"], "w") as f:
    json.dump(weights_json, f, indent=4)

# -------------------------------
# Compute QFL predictions
# -------------------------------
df_final = base_df[["subject_id", "study_id", "outcome"]].copy()
df_final["Cm"] = Cm
df_final["Sc"] = Sc
df_final["Cm_Sc"] = Cm_Sc
df_final["Cm2"] = Cm2
df_final["Sc2"] = Sc2

df_final["Rf_QFL"] = (
    weights_json["w1"] * Cm +
    weights_json["w2"] * Sc +
    weights_json["w3"] * Cm_Sc +
    weights_json["w4"] * Cm2 +
    weights_json["w5"] * Sc2 +
    weights_json["intercept"]
)

df_final.to_csv(cfg["paths"]["rf_qfl_output"], index=False)
print("Weights and QFL predictions computed successfully")
