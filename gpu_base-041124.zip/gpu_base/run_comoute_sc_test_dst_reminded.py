import pandas as pd
from pathlib import Path
import requests
import json
import time
import yaml
from datetime import datetime
import math
from typing import Dict, Any, Optional
import sys

# =========================
# Explicit semantic mapping (DO NOT TOUCH)
# =========================
MIMIC_FIELD_SEMANTICS = {
    "Atelectasis": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Cardiomegaly": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Consolidation": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Edema": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Enlarged Cardiomediastinum": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Fracture": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Lung Lesion": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Lung Opacity": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Pleural Effusion": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Pleural Other": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Pneumonia": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Pneumothorax": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "Support Devices": {-1.0: "Unknown", 0.0: "Absent", 1.0: "Present"},
    "gender": {0.0: "Male", 1.0: "Female"}
}

# =========================
# Utils
# =========================
def safe_value(val: Any) -> Optional[float]:
    if val is None:
        return None
    if isinstance(val, float) and math.isnan(val):
        return None
    return val

def format_structured_block(row: Dict[str, Any]) -> str:
    return "\n".join(
        f"{k}: {MIMIC_FIELD_SEMANTICS[k].get(safe_value(row.get(k)), 'Unknown')}"
        for k in MIMIC_FIELD_SEMANTICS
    )

def build_fusion_text(row: Dict[str, Any]) -> str:
    return f"""[STRUCTURED CLINICAL VARIABLES]
{format_structured_block(row)}

[UNSTRUCTURED CLINICAL NOTE]
{row.get("clinical_note_text", "MISSING_NOTE")}
""".strip()

def extract_json(text: str) -> Optional[str]:
    if not isinstance(text, str):
        return None
    s, e = text.find("{"), text.rfind("}")
    if s == -1 or e <= s:
        return None
    return text[s:e+1]


def ask_ollama(prompt: str, timeout: int = 180, retries: int = 3) -> Dict[str, Any]:
    url = "http://localhost:11434/api/generate"

    payload = {
        "model": "llama3.1:70b",
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0,
            "num_ctx": 4096,
            "num_predict": 256 
        }
    }

    last_error = None

    for attempt in range(retries):
        try:
            r = requests.post(
                url,
                json=payload,
                timeout=timeout
            )
            raw = r.json().get("response", "")
            js = extract_json(raw)
            if not js:
                raise ValueError("No JSON in response")

            obj = json.loads(js)
            if obj.get("risk_level") not in {"low", "medium", "high"}:
                raise ValueError("Invalid schema")

            return obj

        except Exception as e:
            last_error = str(e)
            print(f"[WARN] Ollama failed (attempt {attempt+1}/{retries}): {last_error}")
            time.sleep(10) 

    print("[ERROR] Ollama permanently failed, skipping record")
    return {}

time.sleep(1.5)

def show_time():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

# =========================
# Load config & data
# =========================
with open("./config/config.yaml") as f:
    cfg = yaml.safe_load(f)

df = pd.read_csv(cfg["paths"]["mimic_prepared_csv"])
df["subject_id"] = df["subject_id"].astype(str)
df["study_id"] = df["study_id"].astype(str)

# preload notes paths only (lazy file read)
note_paths = df["path_clinical_note"].tolist()

# =========================
# CM vs SC filtering
# =========================
cm_df = pd.read_csv(cfg["paths"]["cm_test_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_test_output"]) if Path(cfg["paths"]["sc_test_output"]).exists() else pd.DataFrame(columns=["study_id"])

cm_ids = set(cm_df["study_id"].astype(str).str.extract(r"(\d+)", expand=False))
sc_ids = set(sc_df["study_id"].astype(str).str.extract(r"(\d+)", expand=False))

allowed_ids = cm_ids - sc_ids
print("Allowed study_ids:", len(allowed_ids))

# =========================
# Output setup
# =========================
output_csv = Path("./results/sc_test_output_reminded.csv")
output_csv.parent.mkdir(parents=True, exist_ok=True)

if not output_csv.exists():
    output_csv.write_text("subject_id,study_id,risk_level,score,issues\n")

processed = set()
if output_csv.exists():
    existing = pd.read_csv(output_csv)
    processed = set(zip(existing["subject_id"].astype(str), existing["study_id"].astype(str)))

# =========================
# Main loop (LEAN)
# =========================
BATCH_SIZE = 5
buffer = []
start = time.time()

for idx, row in df.iterrows():
    sid = row["study_id"]
    key = (row["subject_id"], sid)

    if sid not in allowed_ids or key in processed:
        continue

    try:
        with open(row["path_clinical_note"], "r", encoding="utf-8") as f:
            row["clinical_note_text"] = f.read().strip()
    except Exception:
        row["clinical_note_text"] = "MISSING_NOTE"

    prompt = f"""
Return ONLY valid JSON:
{{"risk_level":"low|medium|high","score":0-1,"issues":[str]}}

{build_fusion_text(row)}
""".strip()

    out = ask_ollama(prompt)
    if not out:
        continue

    buffer.append({
        "subject_id": row["subject_id"],
        "study_id": sid,
        "risk_level": out.get("risk_level"),
        "score": out.get("score"),
        "issues": json.dumps(out.get("issues", []))
    })
    processed.add(key)
    print(f"#### Row added {str(sid)}")
    if len(buffer) >= BATCH_SIZE:
        pd.DataFrame(buffer).to_csv(output_csv, mode="a", header=False, index=False)
        buffer.clear()
        show_time()
        print("Processed:", len(processed))

if buffer:
    pd.DataFrame(buffer).to_csv(output_csv, mode="a", header=False, index=False)

print("Elapsed sec:", round(time.time() - start, 2))
