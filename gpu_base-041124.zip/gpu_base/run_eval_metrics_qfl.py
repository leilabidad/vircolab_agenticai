import re
import pandas as pd
import numpy as np
import torch
import yaml
import json
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, confusion_matrix
)
from sklearn.linear_model import LinearRegression

# -------------------------------
# Load configuration
# -------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# -------------------------------
# Load data
# -------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_test_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_test_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# -------------------------------
# Normalize IDs
# -------------------------------
def extract_number(x):
    x = str(x)
    match = re.findall(r'\d+', x)
    return match[0] if match else "0"

for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].apply(extract_number)
    df["study_id"] = df["study_id"].apply(extract_number)

# -------------------------------
# Merge datasets
# -------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(sc_df[["subject_id", "study_id", "sc_embedding"]],
           on=["subject_id", "study_id"], how="inner")
    .merge(out_df[["subject_id", "study_id", "outcome"]],
           on=["subject_id", "study_id"], how="inner")
)

if len(base_df) == 0:
    raise ValueError("No aligned samples after merge!")

# -------------------------------
# Process CM
# -------------------------------
cm_embeds = torch.tensor(base_df[cm_cols].values, dtype=torch.float32)
Cm = MinMaxScaler().fit_transform(
    cm_embeds.mean(dim=1).numpy().reshape(-1,1)
).ravel()

# -------------------------------
# Process SC
# -------------------------------
def parse_embedding(v):
    try:
        return [float(x) for x in str(v).strip("[]").split(",")]
    except:
        return None

parsed = base_df["sc_embedding"].apply(parse_embedding).dropna()
dim = parsed.apply(len).iloc[0]
mask = parsed.apply(lambda x: len(x)==dim)

base_df = base_df.loc[mask].reset_index(drop=True)
Cm = Cm[mask.values]

Sc = MinMaxScaler().fit_transform(
    torch.tensor(parsed.loc[mask].tolist()).mean(dim=1).numpy().reshape(-1,1)
).ravel()

# -------------------------------
# Feature construction
# -------------------------------
Cm_Sc = Cm * Sc
Cm2 = Cm ** 2
Sc2 = Sc ** 2

y_true = base_df["outcome"].astype(int).values

# -------------------------------
# Utils
# -------------------------------
def find_best_threshold(y, scores):
    ts = np.linspace(scores.min(), scores.max(), 300)
    best_t, best_ba = ts[0], 0
    for t in ts:
        ba = balanced_accuracy_score(y, (scores >= t).astype(int))
        if ba > best_ba:
            best_ba, best_t = ba, t
    return best_t

def evaluate(y, scores, name):
    t = find_best_threshold(y, scores)
    y_pred = (scores >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    return {
        "model": name,
        "threshold": t,
        "accuracy": accuracy_score(y, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y, y_pred),
        "precision": precision_score(y, y_pred, zero_division=0),
        "recall": recall_score(y, y_pred, zero_division=0),
        "specificity": tn / (tn + fp + 1e-8),
        "f1": f1_score(y, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y, scores)
    }

# -------------------------------
# Main models (Dynamic threshold)
# -------------------------------
results = []

# SwinNet Proxy
lr_swin = LinearRegression()
lr_swin.fit(cm_embeds.numpy()[mask.values], y_true)
swin_scores = MinMaxScaler().fit_transform(
    lr_swin.predict(cm_embeds.numpy()[mask.values]).reshape(-1,1)
).ravel()
results.append(evaluate(y_true, swin_scores, "SwinNet_Proxy"))

# DCS
X_dcs = np.column_stack([Cm, Sc, Cm_Sc])
lr_dcs = LinearRegression().fit(X_dcs, y_true)
results.append(evaluate(y_true, lr_dcs.predict(X_dcs), "DCS"))

# QFL
X_qfl = np.column_stack([Cm, Sc, Cm_Sc, Cm2, Sc2])
lr_qfl = LinearRegression().fit(X_qfl, y_true)
results.append(evaluate(y_true, lr_qfl.predict(X_qfl), "QFL"))

metrics_df = pd.DataFrame(results)
metrics_df.to_csv("./results/final_comparison_metrics_dynamic.csv", index=False)

# -------------------------------
# Ablation Study (Dynamic Threshold)
# -------------------------------
ablation_configs = {
    "Cm_only": np.column_stack([Cm]),
    "Sc_only": np.column_stack([Sc]),
    "Cm_Sc": np.column_stack([Cm, Sc]),
    "DCS_like": X_dcs,
    "QFL_full": X_qfl,
}

ablation_results = []

for name, X in ablation_configs.items():
    lr = LinearRegression().fit(X, y_true)
    scores = lr.predict(X)
    ablation_results.append(evaluate(y_true, scores, name))

ablation_df = pd.DataFrame(ablation_results)
ablation_df.to_csv("./results/ablation_study_dynamic.csv", index=False)

print("\n=== Final Model Comparison ===")
print(metrics_df)

print("\n=== Ablation Study ===")
print(ablation_df)
