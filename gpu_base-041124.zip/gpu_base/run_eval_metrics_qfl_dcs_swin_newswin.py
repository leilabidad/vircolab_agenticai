import re
import pandas as pd
import numpy as np
import torch
import yaml
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, confusion_matrix
)
from sklearn.linear_model import LinearRegression
import torch
import torch.nn as nn

# -------------------------------
# Load configuration
# -------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# -------------------------------
# Load data
# -------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_test_output"])
cm_task_df = pd.read_csv(cfg["paths"]["cm_output"])  # task-aware Swin
sc_df = pd.read_csv(cfg["paths"]["sc_test_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# -------------------------------
# Normalize IDs
# -------------------------------
def extract_number(x):
    x = str(x)
    match = re.findall(r'\d+', x)
    return match[0] if match else "0"

for df in (cm_df, cm_task_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].apply(extract_number)
    df["study_id"] = df["study_id"].apply(extract_number)

# -------------------------------
# Helper: process CM embeddings
# -------------------------------
def process_cm(df, cm_cols):
    cm_embeds = torch.tensor(df[cm_cols].values, dtype=torch.float32)
    Cm = MinMaxScaler().fit_transform(cm_embeds.mean(dim=1).numpy().reshape(-1,1)).ravel()
    return cm_embeds, Cm

# -------------------------------
# Helper: process SC embeddings
# -------------------------------
def process_sc(df):
    def parse_embedding(v):
        try:
            return [float(x) for x in str(v).strip("[]").split(",")]
        except:
            return None

    parsed = df["sc_embedding"].apply(parse_embedding).dropna()
    dim = parsed.apply(len).iloc[0]
    mask = parsed.apply(lambda x: len(x) == dim)

    df = df.loc[mask].reset_index(drop=True)
    Sc = MinMaxScaler().fit_transform(torch.tensor(parsed.loc[mask].tolist()).mean(dim=1).numpy().reshape(-1,1)).ravel()
    return df, Sc

# -------------------------------
# Helper: feature construction
# -------------------------------
def build_features(Cm, Sc):
    Cm_Sc = Cm * Sc
    Cm2 = Cm ** 2
    Sc2 = Sc ** 2
    X_dcs = np.column_stack([Cm, Sc, Cm_Sc])
    X_qfl = np.column_stack([Cm, Sc, Cm_Sc, Cm2, Sc2])
    return X_dcs, X_qfl

# -------------------------------
# Helper: evaluation
# -------------------------------
def find_best_threshold(y, scores):
    ts = np.linspace(scores.min(), scores.max(), 300)
    best_t, best_ba = ts[0], 0
    for t in ts:
        ba = balanced_accuracy_score(y, (scores >= t).astype(int))
        if ba > best_ba:
            best_ba, best_t = ba, t
    return best_t

def evaluate(y, scores, name):
    t = find_best_threshold(y, scores)
    y_pred = (scores >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    return {
        "model": name,
        "threshold": t,
        "accuracy": accuracy_score(y, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y, y_pred),
        "precision": precision_score(y, y_pred, zero_division=0),
        "recall": recall_score(y, y_pred, zero_division=0),
        "specificity": tn / (tn + fp + 1e-8),
        "f1": f1_score(y, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y, scores)
    }

# -------------------------------
# Prepare models
# -------------------------------
results = []

# -------------------------------
# 1. SwinNet Proxy
# -------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]
base_swin = cm_df.merge(out_df, on=["subject_id", "study_id"], how="inner")
cm_embeds, Cm = process_cm(base_swin, cm_cols)
y_true = base_swin["outcome"].astype(int).values

lr_swin = LinearRegression().fit(cm_embeds.numpy(), y_true)
scores_swin = MinMaxScaler().fit_transform(lr_swin.predict(cm_embeds.numpy()).reshape(-1,1)).ravel()
results.append(evaluate(y_true, scores_swin, "Task-Aware CM (Swin Backbone Only)"))


# -------------------------------
# 2. Task-aware Swin (Test-only, Deep MLP)
# -------------------------------
from sklearn.preprocessing import StandardScaler
import torch.nn as nn

# Extract embeddings from test set (cm_df + outcomes)
base_task_swin = cm_df.merge(out_df, on=["subject_id", "study_id"], how="inner")
cm_task_cols = [c for c in cm_df.columns if c.startswith("cm_")]
cm_task_embeds, Cm_task = process_cm(base_task_swin, cm_task_cols)
y_task = base_task_swin["outcome"].astype(int).values

# Define deeper MLP head
class TaskAwareHead(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, 128)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(128, 64)
        self.relu2 = nn.ReLU()
        self.fc3 = nn.Linear(64, 1)

    def forward(self, x):
        x = self.relu1(self.fc1(x))
        x = self.relu2(self.fc2(x))
        x = self.fc3(x)
        return x

# Instantiate model
model = TaskAwareHead(cm_task_embeds.shape[1])
model.eval() 

# Forward pass
with torch.no_grad():
    scores_task = model(cm_task_embeds).squeeze().numpy()

scores_task = StandardScaler().fit_transform(scores_task.reshape(-1,1)).ravel()

results.append(evaluate(y_task, scores_task, "Task-Aware CM (Deep MLP)"))






# -------------------------------
# 3 & 4. DCS Fusion & QFL Fusion (require SC)
# -------------------------------
base_dcs_qfl = cm_df.merge(sc_df, on=["subject_id", "study_id"], how="inner")\
                     .merge(out_df, on=["subject_id", "study_id"], how="inner")
base_dcs_qfl, Sc = process_sc(base_dcs_qfl)
cm_embeds, Cm = process_cm(base_dcs_qfl, cm_cols)
y_dcs_qfl = base_dcs_qfl["outcome"].astype(int).values

X_dcs, X_qfl = build_features(Cm, Sc)

# DCS Fusion
lr_dcs = LinearRegression().fit(X_dcs, y_dcs_qfl)
results.append(evaluate(y_dcs_qfl, lr_dcs.predict(X_dcs), "DCS Fusion"))

# QFL Fusion
lr_qfl = LinearRegression().fit(X_qfl, y_dcs_qfl)
results.append(evaluate(y_dcs_qfl, lr_qfl.predict(X_qfl), "QFL Fusion"))

# -------------------------------
# Save metrics
# -------------------------------
metrics_df = pd.DataFrame(results)
metrics_df.to_csv("./results/final_comparison_metrics_dynamic_4models.csv", index=False)
print("\n=== Final Model Comparison ===")
print(metrics_df)



# -------------------------------
# Ablation Study
# -------------------------------
ablation_results = []

# All features must align with DCS Fusion/QFL Fusion samples
y_ab = y_dcs_qfl
Cm_ab = Cm
Sc_ab = Sc
X_dcs_ab = X_dcs
X_qfl_ab = X_qfl

# Cm only
lr = LinearRegression().fit(Cm_ab.reshape(-1,1), y_ab)
scores = lr.predict(Cm_ab.reshape(-1,1))
ablation_results.append(evaluate(y_ab, scores, "Task-Aware CM (Backbone Only)"))

# Task-aware Cm only (truncate if needed to match DCS Fusion/QFL Fusion)
Cm_task_ab = Cm_task[:len(Cm_ab)]
lr = LinearRegression().fit(Cm_task_ab.reshape(-1,1), y_ab)
scores = lr.predict(Cm_task_ab.reshape(-1,1))
ablation_results.append(evaluate(y_ab, scores, "Task-Aware CM (Deep MLP)"))

# Sc only
lr = LinearRegression().fit(Sc_ab.reshape(-1,1), y_ab)
scores = lr.predict(Sc_ab.reshape(-1,1))
ablation_results.append(evaluate(y_ab, scores, "SC-Only (Clinical Text)"))

# Cm + Sc
X = np.column_stack([Cm_ab, Sc_ab])
lr = LinearRegression().fit(X, y_ab)
scores = lr.predict(X)
ablation_results.append(evaluate(y_ab, scores, "CM + SC (Naive Fusion)"))

# DCS Fusion like
lr = LinearRegression().fit(X_dcs_ab, y_ab)
scores = lr.predict(X_dcs_ab)
ablation_results.append(evaluate(y_ab, scores, "DCS Fusion"))

# QFL Fusion full
lr = LinearRegression().fit(X_qfl_ab, y_ab)
scores = lr.predict(X_qfl_ab)
ablation_results.append(evaluate(y_ab, scores, "QFL Fusion"))

# Save and print
ablation_df = pd.DataFrame(ablation_results)
ablation_df.to_csv("./results/ablation_study_dynamic_4models.csv", index=False)
print("\n=== Ablation Study ===")
print(ablation_df)
