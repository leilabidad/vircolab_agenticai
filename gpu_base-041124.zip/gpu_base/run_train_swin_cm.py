import pandas as pd
import torch
import timm
from torch.utils.data import DataLoader
from torch import nn, optim
from src.vision.dataset import DualViewCXRDataset
from src.vision.train import train_swin
from src.vision.utils import load_cfg, cxr_transform

# -------------------------------
# Config & device
# -------------------------------
cfg = load_cfg("./config/vision_config.yaml")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.backends.cudnn.benchmark = True

# -------------------------------
# Dataset & loader
# -------------------------------
dataset = DualViewCXRDataset(
    cfg["paths"]["csv"],
    cfg,
    cfg["data"]["train_split"],
    cxr_transform()
)

loader = DataLoader(
    dataset,
    batch_size=cfg["training"]["batch_size"],
    shuffle=True
)

# -------------------------------
# Backbone
# -------------------------------
backbone = timm.create_model(
    "swin_base_patch4_window7_224",
    pretrained=True,
    num_classes=0
)

# -------------------------------
# Dual-view Swin with classifier
# -------------------------------
class DualViewSwin(nn.Module):
    def __init__(self, backbone, out_dim):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = backbone.num_features
        self.classifier = nn.Linear(self.embed_dim, out_dim)

    def forward(self, frontal, lateral):
        x_f = self.backbone(frontal)
        x_l = self.backbone(lateral)
        cm = (x_f + x_l) / 2
        logits = self.classifier(cm)
        return logits, cm

model = DualViewSwin(
    backbone,
    out_dim=len(cfg["data"]["label_columns"])
).to(device)

# -------------------------------
# Optim & loss
# -------------------------------
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.AdamW(
    model.parameters(),
    lr=cfg["training"]["lr"]
)

# -------------------------------
# Train (classification-driven)
# -------------------------------
train_swin(
    model,
    loader,
    optimizer,
    criterion,
    device,
    cfg["training"]["epochs"]
)

torch.save(model.state_dict(), cfg["paths"]["checkpoint"])

# -------------------------------
# Cm extraction (task-aware)
# -------------------------------
model.eval()
rows = []

with torch.no_grad():
    for batch in loader:
        frontal = batch[0].to(device)
        lateral = batch[1].to(device)
        subject_id = batch[-2]
        study_id = batch[-1]

        _, Cm = model(frontal, lateral)

        for i in range(Cm.size(0)):
            row = {
                "subject_id": subject_id[i].item(),
                "study_id": study_id[i].item()
            }
            for j, v in enumerate(Cm[i].cpu().tolist()):
                row[f"cm_{j}"] = v
            rows.append(row)

pd.DataFrame(rows).to_csv(cfg["paths"]["cm_output"], index=False)

print("Finished: task-aware Cm embeddings saved.")
