import nibabel as nib
import numpy as np
from multiprocessing import Pool, cpu_count

def _process_file_for_label(path, lower=40, upper=60, trim=5, noise_std=0.05):
    img = np.asarray(nib.load(path).dataobj, dtype=np.float32)
    img = np.clip(img, 0, 1) + np.random.normal(0, noise_std, img.shape)
    flat = img.flatten()
    trim_n = int(len(flat) * trim / 100)
    trimmed_flat = np.sort(flat)[trim_n:-trim_n] if trim_n > 0 else flat
    return trimmed_flat.mean()

def generate_labels_parallel(file_list, lower=40, upper=60, trim=5, noise_std=0.05, n_processes=None):
    if n_processes is None:
        n_processes = max(1, cpu_count() - 1)

    with Pool(n_processes) as pool:
        means = pool.starmap(_process_file_for_label, [(f, lower, upper, trim, noise_std) for f in file_list])

    means = np.array(means)
    if len(means) < 2:
        return np.zeros(len(means), dtype=np.int64)

    neg_thresh = np.percentile(means, lower)
    pos_thresh = np.percentile(means, upper)
    labels = np.array([0 if m <= neg_thresh else 1 if m >= pos_thresh else np.random.choice([0, 1]) for m in means], dtype=np.int64)
    return labels
