import os
import csv
import torch
import pandas as pd


def save_summary_csv_from_metrics(output_dir, filename="summary.csv"):
    rows = []
    for f in os.listdir(output_dir):
        if not f.endswith(".json"):
            continue
        path = os.path.join(output_dir, f)
        with open(path) as j:
            d = eval(j.read())
            d["run"] = f.replace(".json", "")
            rows.append(d)
    if not rows:
        return
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(output_dir, filename), index=False)

def save_features_safe(model, dataset, output_dir, batch_size=4, device="cuda", mini_batch=2):
    import os, torch
    from torch.utils.data import DataLoader

    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"]
            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for start_idx in range(0, x.size(0), mini_batch):
                x_sub = x[start_idx:start_idx+mini_batch].to(device)
                out = _model(x_sub)

                z = out[-1] if isinstance(out, (tuple, list)) else out
                if z.dim() > 2:
                    z = torch.flatten(z, start_dim=1)

                z_cpu = z.cpu()
                for i in range(z_cpu.size(0)):
                    fname = os.path.basename(str(filenames[start_idx + i])).replace(".nii.gz", "")
                    torch.save(z_cpu[i], os.path.join(features_dir, f"{fname}_feat.pt"))


def save_features_individual(model, dataset, output_dir, batch_size=4, device="cuda"):
    import os
    import torch

    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)
    loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=False)
    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"].to(device)
            out = _model(x)

            if isinstance(out, tuple) or isinstance(out, list):
                z = out[-1]
            else:
                z = out

            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for i in range(z.size(0)):
                fname = os.path.basename(str(filenames[i]))
                fname = fname.replace(".nii.gz", "")

                torch.save(
                    z[i].cpu(),
                    os.path.join(features_dir, f"{fname}_feat.pt")
                )




import os
import time
import csv
import torch

def save_features_individual_swinunnetr(
    model,
    data,
    output_dir,
    batch_size=1,
    device="cuda",
    csv_name="features_summary.csv"
):
    os.makedirs(output_dir, exist_ok=True)
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)

    model.eval()

    dataset = data.dataset if hasattr(data, "dataset") else data
    total_samples = len(dataset)

    start_time = time.time()
    saved = 0

    with torch.no_grad():
        for start in range(0, total_samples, batch_size):
            end = min(start + batch_size, total_samples)

            batch = [dataset[i]["image"] for i in range(start, end)]
            x = torch.stack(batch).to(device)

            out = model(x)
            if isinstance(out, dict):
                out = out.get("logits", list(out.values())[-1])
            elif isinstance(out, (tuple, list)):
                out = out[-1]

            if out.dim() > 2:
                out = out.flatten(start_dim=1)

            for i in range(out.size(0)):
                torch.save(
                    out[i].cpu(),
                    os.path.join(features_dir, f"feat_{start + i}.pt")
                )
                saved += 1

    elapsed = time.time() - start_time

    csv_path = os.path.join(output_dir, csv_name)
    write_header = not os.path.exists(csv_path)

    with open(csv_path, "a", newline="") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow([
                "total_images",
                "batch_size",
                "features_saved",
                "execution_time_seconds"
            ])
        writer.writerow([
            total_samples,
            batch_size,
            saved,
            round(elapsed, 2)
        ])

    print(f"Saved {saved}/{total_samples} features in {elapsed:.2f}s")


def save_features_individual_autoencoder(
    model,
    loader,           # DataLoader با batch_size واقعی
    output_dir,
    device="cuda",
    micro_batch=4     # کنترل GPU
):
    import os, torch
    model.eval()
    features_dir = os.path.join(output_dir, "features")
    os.makedirs(features_dir, exist_ok=True)
    saved = 0

    _model = model.module if hasattr(model, "module") else model

    with torch.no_grad():
        for batch in loader:
            x = batch["image"]
            filenames = batch["image_meta_dict"]["filename_or_obj"]

            for start in range(0, x.size(0), micro_batch):
                x_sub = x[start:start+micro_batch].to(device)
                out = _model(x_sub)

                if not isinstance(out, tuple):
                    raise RuntimeError("Autoencoder must return (recon, z)")

                _, z = out  # latent features

                if z.dim() > 2:
                    z = z.flatten(start_dim=1)

                for i in range(z.size(0)):
                    fname = os.path.basename(str(filenames[start + i])).replace(".nii.gz", "")
                    torch.save(z[i].cpu(), os.path.join(features_dir, f"{fname}_feat.pt"))
                    saved += 1

    print(f"[OK] Saved {saved} feature files")




def save_summary_single_row(output_dir, results_dict):
    os.makedirs(output_dir, exist_ok=True)
    summary_file = os.path.join(output_dir, "summary.csv")

    # Default metrics file check
    metrics_file = os.path.join(output_dir, "metrics.csv")
    if not os.path.exists(metrics_file):
        metrics_file = os.path.join(output_dir, "metrics_summary.csv")
        if not os.path.exists(metrics_file):
            # If metrics file not found, fallback to results_dict
            df = pd.DataFrame([results_dict])
            df.to_csv(summary_file, index=False)
            print(f"[INFO] Summary saved using results_dict fallback: {summary_file}")
            return

    # Read metrics and save the last row
    df_metrics = pd.read_csv(metrics_file)
    if df_metrics.empty:
        df = pd.DataFrame([results_dict])
        df.to_csv(summary_file, index=False)
        print(f"[WARN] Metrics file empty, fallback to results_dict: {summary_file}")
        return

    last_row = df_metrics.iloc[[-1]]
    last_row.to_csv(summary_file, index=False)
    print(f"[INFO] Summary saved from metrics file: {summary_file}")

