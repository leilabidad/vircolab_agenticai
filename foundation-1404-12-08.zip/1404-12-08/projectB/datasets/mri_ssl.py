# datasets/mri_ssl.py
import os, json, glob
import numpy as np
import nibabel as nib
from monai.transforms import *
from monai.data import CacheDataset, load_decathlon_datalist

def clean_invalid_volumes(paths):
    for p in paths:
        if nib.load(p).get_fdata().ndim != 3:
            os.remove(p)

def build_dataset(dataset_dir, output_dir):
    imgs = sorted(glob.glob(os.path.join(dataset_dir, "*.nii.gz")))
    clean_invalid_volumes(imgs)

    js = {"tensorImageSize":"3D","training":[],"validation":[]}
    for p in imgs[:-5]: js["training"].append({"image":os.path.abspath(p)})
    for p in imgs[-5:]: js["validation"].append({"image":os.path.abspath(p)})

    path = os.path.join(output_dir,"dataset.json")
    with open(path,"w") as f: json.dump(js,f)

    return (
        load_decathlon_datalist(path, True, "training"),
        load_decathlon_datalist(path, True, "validation")
    )

def generate_trimmed_labels(files, lp=40, up=60):
    means=[]
    for f in files:
        img=nib.load(f).get_fdata().astype(np.float32)
        means.append(img.mean())
    lo,hi=np.percentile(means,lp),np.percentile(means,up)
    return np.array([0 if m<=lo else 1 if m>=hi else np.random.randint(2) for m in means])

def get_transforms(train=True):
    t=[LoadImaged(keys=["image"],ensure_channel_first=True),
       ScaleIntensityRanged(keys=["image"],-175,250,0,1,clip=True),
       CropForegroundd(keys=["image"],source_key="image"),
       Orientationd(keys=["image"],axcodes="RAS"),
       Spacingd(keys=["image"],(2,2,2),mode="bilinear"),
       Resized(keys=["image"],(98,98,98),mode="trilinear")]
    if train:
        t+= [RandFlipd(keys=["image"],spatial_axis=i,prob=0.1) for i in range(3)]
    t.append(EnsureTyped(keys=["image"]))
    return Compose(t)
