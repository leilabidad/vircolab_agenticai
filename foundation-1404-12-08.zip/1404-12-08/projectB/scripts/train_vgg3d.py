import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import glob
import json
import argparse
import nibabel as nib
import torch
from monai.transforms import Compose, LoadImaged, ScaleIntensityRanged, CropForegroundd, Orientationd, Spacingd, Resized, RandFlipd, RandRotate90d, RandShiftIntensityd, EnsureTyped
from monai.data import ThreadDataLoader, load_decathlon_datalist, CacheDataset
from models import VGG3D
from trainers.supervised_trainer import SupervisedTrainer
from utils.io import save_features_individual, save_summary_single_row
import torch.nn as nn

parser = argparse.ArgumentParser()
parser.add_argument("--dataset_dir", type=str, required=True)
parser.add_argument("--output_dir", type=str, default="weights")
parser.add_argument("--batch_size", type=int, default=1)
parser.add_argument("--max_epochs", type=int, default=1000)
parser.add_argument("--lr", type=float, default=1e-4)
parser.add_argument("--weight_decay", type=float, default=1e-5)
parser.add_argument("--early_stop_patience", type=int, default=20)
parser.add_argument("--gpus", type=str, default=None)
args = parser.parse_args()

if args.gpus:
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# -------------------- Model & Optimizer --------------------
model = VGG3D(num_classes=2).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
criterion = nn.CrossEntropyLoss()

# -------------------- Load dataset --------------------
image_paths = sorted(glob.glob(os.path.join(args.dataset_dir, "*.nii.gz")))
valid_image_paths = []
for p in image_paths:
    try:
        img_obj = nib.load(p)
        if len(img_obj.shape) == 3:
            valid_image_paths.append(p)
    except:
        continue
image_paths = sorted(valid_image_paths)

dataset_json = {"tensorImageSize": "3D", "training": [], "validation": []}
for path in image_paths[:-5]:
    dataset_json["training"].append({"image": os.path.abspath(path)})
for path in image_paths[-5:]:
    dataset_json["validation"].append({"image": os.path.abspath(path)})

os.makedirs(args.output_dir, exist_ok=True)
dataset_json_path = os.path.join(args.output_dir, "dataset.json")
with open(dataset_json_path, "w") as f:
    json.dump(dataset_json, f)

train_files = load_decathlon_datalist(dataset_json_path, True, "training")
val_files = load_decathlon_datalist(dataset_json_path, True, "validation")

from utils.data_utils import generate_labels_parallel

# Generate pseudo labels if needed
if "label" not in train_files[0]:
    labels = generate_labels_parallel([f["image"] for f in train_files])
    for i, f in enumerate(train_files):
        f["label"] = labels[i]

if "label" not in val_files[0]:
    labels = generate_labels_parallel([f["image"] for f in val_files])
    for i, f in enumerate(val_files):
        f["label"] = labels[i]

# -------------------- Transforms --------------------
train_transforms = Compose([
    LoadImaged(keys=["image"], ensure_channel_first=True),
    ScaleIntensityRanged(keys=["image"], a_min=-175, a_max=250, b_min=0.0, b_max=1.0, clip=True),
    CropForegroundd(keys=["image"], source_key="image"),
    Orientationd(keys=["image"], axcodes="RAS"),
    Spacingd(keys=["image"], pixdim=(2.0, 2.0, 2.0), mode="bilinear"),
    Resized(keys=["image"], spatial_size=(98,98,98), mode="trilinear"),
    RandFlipd(keys=["image"], spatial_axis=0, prob=0.1),
    RandFlipd(keys=["image"], spatial_axis=1, prob=0.1),
    RandFlipd(keys=["image"], spatial_axis=2, prob=0.1),
    RandRotate90d(keys=["image"], prob=0.1, max_k=3),
    RandShiftIntensityd(keys=["image"], offsets=0.1, prob=0.5),
    EnsureTyped(keys=["image"])
])

val_transforms = Compose([
    LoadImaged(keys=["image"], ensure_channel_first=True),
    ScaleIntensityRanged(keys=["image"], a_min=-175, a_max=250, b_min=0.0, b_max=1.0, clip=True),
    CropForegroundd(keys=["image"], source_key="image"),
    Orientationd(keys=["image"], axcodes="RAS"),
    Spacingd(keys=["image"], pixdim=(2.0, 2.0, 2.0), mode="bilinear"),
    Resized(keys=["image"], spatial_size=(98,98,98), mode="trilinear"),
    EnsureTyped(keys=["image"])
])

train_ds = CacheDataset(data=train_files, transform=train_transforms, cache_rate=1.0, num_workers=4)
val_ds = CacheDataset(data=val_files, transform=val_transforms, cache_rate=1.0, num_workers=4)

train_loader = ThreadDataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)
val_loader = ThreadDataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)

torch.cuda.empty_cache()

# -------------------- Train --------------------
trainer = SupervisedTrainer(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    optimizer=optimizer,
    output_dir=args.output_dir,
    device=device,
    patience=args.early_stop_patience,
    monitor_metric="auc"
)
trainer.train(max_epochs=args.max_epochs)

torch.cuda.empty_cache()

# -------------------- Save features --------------------
model.eval()
with torch.no_grad():
    save_features_individual(model, train_ds, args.output_dir)

# -------------------- Save final summary --------------------
if hasattr(trainer, "history"):
    avg_loss = trainer.history.get("train_loss", [0])[-1]
    val_loss = trainer.history.get("val_loss", [0])[-1]
    val_auc = trainer.history.get("val_auc", [0])[-1]
else:
    avg_loss = val_loss = val_auc = 0

final_results = {"train_loss": float(avg_loss), "val_loss": float(val_loss), "val_auc": float(val_auc)}
save_summary_single_row(args.output_dir, final_results)
torch.cuda.empty_cache()