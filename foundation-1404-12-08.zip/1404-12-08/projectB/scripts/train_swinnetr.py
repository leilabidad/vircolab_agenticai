import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import glob
import json
import argparse
import nibabel as nib
import numpy as np
import torch
from monai.transforms import Compose, LoadImaged, ScaleIntensityRanged, CropForegroundd, Orientationd, Spacingd, Resized, RandFlipd, RandRotate90d, RandShiftIntensityd, EnsureTyped
from monai.data import ThreadDataLoader, Dataset, load_decathlon_datalist
from models.ssl_head import SSLHead
from trainers.ssl_trainer import SSLTrainer
from models import VGG3D
from models.resnet3d import ResNet3D
from models.autoencoder3d import Autoencoder3D
from trainers.supervised_trainer import SupervisedTrainer
from utils.io import save_features_individual, save_features_safe, save_features_individual_autoencoder, save_summary_single_row, save_features_individual_swinunnetr
import torch.nn as nn

parser = argparse.ArgumentParser()
parser.add_argument("--dataset_dir", type=str, required=True)
parser.add_argument("--output_dir", type=str, default="weights")
parser.add_argument("--batch_size", type=int, default=1)
parser.add_argument("--max_epochs", type=int, default=1000)
parser.add_argument("--lr", type=float, default=1e-4)
parser.add_argument("--weight_decay", type=float, default=1e-5)
parser.add_argument("--patience", type=int, default=20)
parser.add_argument("--early_stop_patience", type=int, default=20)
parser.add_argument("--feature_size", type=int, default=48)
parser.add_argument("--upsample", type=str, default="vae")
parser.add_argument("--model", type=str, choices=["sslhead", "vgg3d", "resnet", "autoencoder"], default="sslhead")
parser.add_argument("--gpus", type=str, default=None)
args = parser.parse_args()

if args.gpus:
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# -------------------- Model & Optimizer --------------------
criterion = None

if args.model == "vgg3d":
    model = VGG3D(num_classes=2).to(device)  
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.CrossEntropyLoss()         

elif args.model == "resnet":
    model = ResNet3D(num_classes=2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.CrossEntropyLoss()
elif args.model == "autoencoder":
    model = Autoencoder3D().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)



else:  # sslhead
    class ModelArgs:
        spatial_dims = 3
        in_channels = 1
        feature_size = args.feature_size
        dropout_path_rate = 0.1
        use_checkpoint = False


    model = SSLHead(ModelArgs(), upsample=args.upsample)
    if torch.cuda.device_count() > 1:
        if args.gpus:
            device_ids = [int(i) for i in args.gpus.split(",")]
            model = nn.DataParallel(model, device_ids=device_ids)
        else:
            model = nn.DataParallel(model)
    model = model.to(device)



    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

# -------------------- Load dataset --------------------
image_paths = sorted(glob.glob(os.path.join(args.dataset_dir, "*.nii.gz")))
valid_image_paths = []
for p in image_paths:
    try:
        img_obj = nib.load(p)
        if len(img_obj.shape) == 3:
            valid_image_paths.append(p)

    except Exception as e:
        print(f"[WARN] Skipping corrupted file {p}: {e}")

image_paths = sorted(valid_image_paths)

dataset_json = {"tensorImageSize": "3D", "training": [], "validation": []}
for path in image_paths[:-5]:
    dataset_json["training"].append({"image": os.path.abspath(path)})
for path in image_paths[-5:]:
    dataset_json["validation"].append({"image": os.path.abspath(path)})

os.makedirs(args.output_dir, exist_ok=True)
dataset_json_path = os.path.join(args.output_dir, "dataset.json")
with open(dataset_json_path, "w") as f:
    json.dump(dataset_json, f)

train_files = load_decathlon_datalist(dataset_json_path, True, "training")
val_files = load_decathlon_datalist(dataset_json_path, True, "validation")

# -------------------- Generate pseudo labels --------------------

from utils.data_utils import generate_labels_parallel

# Check if labels already exist
need_labels_train = "label" not in train_files[0]
need_labels_val = "label" not in val_files[0]

if need_labels_train:
    train_labels = generate_labels_parallel([f["image"] for f in train_files])
    for i, f in enumerate(train_files):
        f["label"] = train_labels[i]

if need_labels_val:
    val_labels = generate_labels_parallel([f["image"] for f in val_files])
    for i, f in enumerate(val_files):
        f["label"] = val_labels[i]



# -------------------- Transforms --------------------
train_transforms = Compose([
    LoadImaged(keys=["image"], ensure_channel_first=True),
    ScaleIntensityRanged(keys=["image"], a_min=-175, a_max=250, b_min=0.0, b_max=1.0, clip=True),
    CropForegroundd(keys=["image"], source_key="image"),
    Orientationd(keys=["image"], axcodes="RAS"),
    Spacingd(keys=["image"], pixdim=(2.0, 2.0, 2.0), mode="bilinear"),
    Resized(keys=["image"], spatial_size=(98,98,98), mode="trilinear"),
    RandFlipd(keys=["image"], spatial_axis=0, prob=0.1),
    RandFlipd(keys=["image"], spatial_axis=1, prob=0.1),
    RandFlipd(keys=["image"], spatial_axis=2, prob=0.1),
    RandRotate90d(keys=["image"], prob=0.1, max_k=3),
    RandShiftIntensityd(keys=["image"], offsets=0.1, prob=0.5),
    EnsureTyped(keys=["image"])
])

val_transforms = Compose([
    LoadImaged(keys=["image"], ensure_channel_first=True),
    ScaleIntensityRanged(keys=["image"], a_min=-175, a_max=250, b_min=0.0, b_max=1.0, clip=True),
    CropForegroundd(keys=["image"], source_key="image"),
    Orientationd(keys=["image"], axcodes="RAS"),
    Spacingd(keys=["image"], pixdim=(2.0, 2.0, 2.0), mode="bilinear"),
    Resized(keys=["image"], spatial_size=(98,98,98), mode="trilinear"),
    EnsureTyped(keys=["image"])
])


from monai.data import CacheDataset, ThreadDataLoader

train_ds = CacheDataset(
    data=train_files,
    transform=train_transforms,
    cache_rate=1.0,      # همه دیتا cache بشه
    num_workers=4         # یا بیشتر اگر CPU قویه
)

val_ds = CacheDataset(
    data=val_files,
    transform=val_transforms,
    cache_rate=1.0,
    num_workers=4
)

train_loader = ThreadDataLoader(
    train_ds,
    batch_size=args.batch_size,
    shuffle=True,
    num_workers=4,
    pin_memory=True
)

val_loader = ThreadDataLoader(
    val_ds,
    batch_size=args.batch_size,
    shuffle=False,
    num_workers=4,
    pin_memory=True
)

torch.cuda.empty_cache()

# -------------------- Train --------------------
if args.model in ["vgg3d", "resnet"]:

    trainer = SupervisedTrainer(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            optimizer=optimizer,
            output_dir=args.output_dir,
            device=device,
            patience=args.early_stop_patience,
            monitor_metric="auc"
        )
    trainer.train(max_epochs=args.max_epochs)
        
elif args.model == "autoencoder":
    from trainers.autoencoder_trainer import AutoencoderTrainer
    trainer = AutoencoderTrainer(
        model, train_loader, val_loader, optimizer,
        args.output_dir, device,
        patience=args.early_stop_patience
    )
    trainer.train(max_epochs=args.max_epochs)


else:
    trainer = SSLTrainer(
        model,
        train_loader,
        val_loader,
        optimizer,
        args.output_dir,
        device,
        patience=args.early_stop_patience
    )
    trainer.train(max_epochs=args.max_epochs)

torch.cuda.empty_cache()



# -------------------- Save features --------------------
model.eval()
with torch.no_grad():
    if args.model == "autoencoder":
        save_features_individual_autoencoder(
            model=model,
            loader=train_loader,
            output_dir=args.output_dir,
            device=device,
            micro_batch=8 
        )


    elif args.model in ["vgg3d"]:
        save_features_individual(
            model,
            train_ds,
            args.output_dir
        )


    elif args.model in ["resnet"]:
        save_features_safe(
            model,
            train_ds,
            args.output_dir
        )


    else:
        save_features_individual_swinunnetr(
            model=model,
            data=train_ds,
            output_dir=args.output_dir,
            batch_size=args.batch_size,
            device=device
        )

# -------------------- Save final summary --------------------
if hasattr(trainer, "history"):
    avg_loss = trainer.history.get("train_loss", [0])[-1]
    val_loss = trainer.history.get("val_loss", [0])[-1]
    val_auc = trainer.history.get("val_auc", [0])[-1]
else:
    avg_loss = val_loss = val_auc = 0

final_results = {
    "train_loss": float(avg_loss),
    "val_loss": float(val_loss),
    "val_auc": float(val_auc)
}

save_summary_single_row(args.output_dir, final_results)
torch.cuda.empty_cache()
