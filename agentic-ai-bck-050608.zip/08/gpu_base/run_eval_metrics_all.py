from __future__ import annotations

import json
import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import seaborn as sns
import yaml
import matplotlib.pyplot as plt

from sklearn.metrics import (
    roc_auc_score,
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

BASE_CFG_PATH = "./config/config.yaml"
VISION_CFG_PATH = "./config/vision_config.yaml"


# =========================================================
# Config / Paths
# =========================================================
def load_yaml(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p.resolve()}")
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


# =========================================================
# ID normalization
# =========================================================
def normalize_id_value(v):
    if pd.isna(v):
        return np.nan

    s = str(v).strip()

    if s.startswith("tensor(") and s.endswith(")"):
        s = s[len("tensor("):-1].strip()

    s = s.replace("tensor(", "").replace(")", "").strip()

    if re.fullmatch(r"-?\d+\.0+", s):
        s = str(int(float(s)))
    elif s.endswith(".0") and re.fullmatch(r"-?\d+(\.0)?", s):
        s = s[:-2]

    return s.strip()


def normalize_ids(df: pd.DataFrame, id_cols=("subject_id", "study_id")) -> pd.DataFrame:
    out = df.copy()
    for col in id_cols:
        if col not in out.columns:
            raise KeyError(f"Missing required ID column: {col}")
        out[col] = out[col].map(normalize_id_value)
    return out


def assert_unique_keys(df: pd.DataFrame, keys: List[str], name: str) -> None:
    dup_mask = df.duplicated(subset=keys, keep=False)
    if dup_mask.any():
        dup_rows = df.loc[dup_mask, keys].head(20)
        raise ValueError(
            f"[{name}] Duplicate keys found for {keys}.\n"
            f"Sample duplicates:\n{dup_rows.to_string(index=False)}"
        )


# =========================================================
# Utilities
# =========================================================
def safe_numeric_series(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")


def binarize_label(s: pd.Series) -> pd.Series:
    x = safe_numeric_series(s).fillna(0)
    return (x > 0).astype(int)


def pick_existing_column(df: pd.DataFrame, candidates: List[str], required=True) -> Optional[str]:
    for c in candidates:
        if c in df.columns:
            return c
    if required:
        raise KeyError(
            f"None of these columns found: {candidates}\nAvailable: {list(df.columns)}"
        )
    return None


def load_best_alpha_if_exists(alpha_json_path: Path) -> Optional[float]:
    if not alpha_json_path.exists():
        return None
    try:
        with alpha_json_path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        for key in ["best_alpha", "alpha", "optimal_alpha"]:
            if key in obj:
                return float(obj[key])
    except Exception:
        return None
    return None


# =========================================================
# CM helpers
# =========================================================
def extract_cm_score_from_logits(df: pd.DataFrame) -> pd.Series:
    """
    Expected CM columns:
      cm_0, cm_1, ...
    Convert logits/prob-like columns to a single scalar score by row mean.
    If only one cm_* column exists, use it directly.
    """
    cm_cols = [c for c in df.columns if str(c).startswith("cm_")]
    if not cm_cols:
        raise KeyError("No cm_* columns found in CM dataframe.")

    cm_values = df[cm_cols].apply(pd.to_numeric, errors="coerce")

    # If logits/probabilities are already in multi-label format, average is consistent
    # with your fusion script behavior summary.
    if len(cm_cols) == 1:
        return cm_values[cm_cols[0]].fillna(0.0).astype(float)

    return cm_values.mean(axis=1).fillna(0.0).astype(float)


# =========================================================
# Threshold selection / metrics
# =========================================================
def best_threshold_search(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score).astype(float)

    mask = np.isfinite(y_score)
    y_true = y_true[mask]
    y_score = y_score[mask]

    if len(y_score) == 0:
        return 0.5

    smin = float(np.min(y_score))
    smax = float(np.max(y_score))

    if np.isclose(smin, smax):
        return smin

    thresholds = np.linspace(smin, smax, 201)
    best_thr = thresholds[0]
    best_f1 = -1.0

    for thr in thresholds:
        y_pred = (y_score >= thr).astype(int)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        if f1 > best_f1:
            best_f1 = f1
            best_thr = float(thr)

    return float(best_thr)


def evaluate_metrics(
    y_true: np.ndarray,
    y_score: np.ndarray,
    disease: str,
    model: str,
    threshold: float,
) -> Dict[str, object]:
    y_true = np.asarray(y_true).astype(int)
    y_score = np.asarray(y_score).astype(float)

    mask = np.isfinite(y_score)
    y_true = y_true[mask]
    y_score = y_score[mask]

    if len(y_true) == 0:
        return {
            "disease": disease,
            "model": model,
            "n": 0,
            "auc": np.nan,
            "threshold": threshold,
            "accuracy": np.nan,
            "balanced_acc": np.nan,
            "precision": np.nan,
            "recall_score": np.nan,
            "specificity": np.nan,
            "f1": np.nan,
            "tp": np.nan,
            "tn": np.nan,
            "fp": np.nan,
            "fn": np.nan,
        }

    y_pred = (y_score >= threshold).astype(int)

    try:
        auc = roc_auc_score(y_true, y_score)
    except Exception:
        auc = np.nan

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    accuracy = accuracy_score(y_true, y_pred)
    balanced_acc = balanced_accuracy_score(y_true, y_pred) if len(np.unique(y_true)) > 1 else np.nan
    f1 = f1_score(y_true, y_pred, zero_division=0)

    return {
        "disease": disease,
        "model": model,
        "n": int(len(y_true)),
        "auc": float(auc) if pd.notna(auc) else np.nan,
        "threshold": float(threshold),
        "accuracy": float(accuracy),
        "balanced_acc": float(balanced_acc) if pd.notna(balanced_acc) else np.nan,
        "precision": float(precision),
        "recall_score": float(recall),
        "specificity": float(specificity),
        "f1": float(f1),
        "tp": int(tp),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
    }


# =========================================================
# Plotting
# =========================================================
def plot_auc_comparison(df: pd.DataFrame, out_path: Path) -> None:
    if df.empty:
        return

    plt.figure(figsize=(max(14, len(df["disease"].unique()) * 0.9), 7))
    ax = sns.barplot(
        data=df,
        x="disease",
        y="auc",
        hue="model",
        palette="viridis",
    )
    ax.axhline(0.5, linestyle="--", color="red", linewidth=1)
    ax.set_title("AUC Comparison per Disease")
    ax.set_xlabel("Disease")
    ax.set_ylabel("AUC")
    plt.xticks(rotation=45, ha="right")
    plt.ylim(0, 1.05)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close()


def plot_average_performance(summary_df: pd.DataFrame, out_path: Path) -> None:
    if summary_df.empty:
        return

    metrics = ["auc", "f1", "accuracy", "recall_score", "specificity"]
    cols = ["model"] + [m for m in metrics if m in summary_df.columns]

    plot_df = summary_df[cols].melt(
        id_vars="model",
        var_name="metric",
        value_name="value",
    )

    plt.figure(figsize=(12, 7))
    ax = sns.barplot(
        data=plot_df,
        x="metric",
        y="value",
        hue="model",
        palette="Set2",
    )
    ax.set_title("Average Performance Summary")
    ax.set_xlabel("Metric")
    ax.set_ylabel("Score")
    plt.ylim(0, 1.05)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close()


# =========================================================
# Data loading
# =========================================================
def prepare_truth_dataframe(truth_path: Path, label_cols: List[str]) -> pd.DataFrame:
    truth_df = pd.read_csv(truth_path)
    truth_df = normalize_ids(truth_df)

    required = ["subject_id", "study_id"] + label_cols
    missing = [c for c in required if c not in truth_df.columns]
    if missing:
        raise KeyError(f"Missing columns in ground truth file: {missing}")

    truth_df = truth_df[required].copy()
    assert_unique_keys(truth_df, ["subject_id", "study_id"], "ground_truth")
    return truth_df


def prepare_fusion_dataframe(path: Path, name: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = normalize_ids(df)

    required = ["subject_id", "study_id", "cm_score", "sc_score", "fusion_score"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"[{name}] Missing columns: {missing}")

    df = df[required].copy()
    assert_unique_keys(df, ["subject_id", "study_id"], name)
    return df


def prepare_cm_output_dataframe(path: Path, name: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = normalize_ids(df)

    if "subject_id" not in df.columns or "study_id" not in df.columns:
        raise KeyError(f"[{name}] subject_id/study_id not found")

    cm_cols = [c for c in df.columns if str(c).startswith("cm_")]
    if not cm_cols:
        raise KeyError(f"[{name}] No cm_* columns found")

    df = df[["subject_id", "study_id"] + cm_cols].copy()
    df["cm_score_derived"] = extract_cm_score_from_logits(df)
    assert_unique_keys(df, ["subject_id", "study_id"], name)
    return df


def prepare_sc_output_dataframe(path: Path, name: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = normalize_ids(df)

    required = ["subject_id", "study_id", "score"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"[{name}] Missing columns: {missing}")

    df = df[required].copy()
    df["sc_score_derived"] = pd.to_numeric(df["score"], errors="coerce")
    assert_unique_keys(df, ["subject_id", "study_id"], name)
    return df


def prepare_rf_output_dataframe(path: Path, score_col_candidates: List[str], name: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = normalize_ids(df)

    score_col = pick_existing_column(df, score_col_candidates, required=True)

    required = ["subject_id", "study_id", score_col]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"[{name}] Missing columns: {missing}")

    df = df[required].copy()
    df.rename(columns={score_col: "rf_score"}, inplace=True)
    assert_unique_keys(df, ["subject_id", "study_id"], name)
    return df


# =========================================================
# Threshold builders
# =========================================================
def build_val_thresholds_for_multilabel_models(
    truth_df: pd.DataFrame,
    fusion_val_df: pd.DataFrame,
    cm_val_df: pd.DataFrame,
    sc_val_df: pd.DataFrame,
    label_cols: List[str],
) -> Dict[Tuple[str, str], float]:
    """
    Returns:
        thresholds[(model_name, disease)] = threshold
    """
    thresholds: Dict[Tuple[str, str], float] = {}

    val_cm = truth_df.merge(
        cm_val_df[["subject_id", "study_id", "cm_score_derived"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    val_sc = truth_df.merge(
        sc_val_df[["subject_id", "study_id", "sc_score_derived"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    val_fusion = truth_df.merge(
        fusion_val_df[["subject_id", "study_id", "cm_score", "sc_score", "fusion_score"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    if val_cm.empty:
        raise ValueError("CM validation merge is empty.")
    if val_sc.empty:
        raise ValueError("SC validation merge is empty.")
    if val_fusion.empty:
        raise ValueError("Fusion validation merge is empty.")

    for disease in label_cols:
        y_cm = binarize_label(val_cm[disease]).to_numpy()
        s_cm = pd.to_numeric(val_cm["cm_score_derived"], errors="coerce").fillna(0).to_numpy()
        thresholds[("CM Only", disease)] = best_threshold_search(y_cm, s_cm)

        y_sc = binarize_label(val_sc[disease]).to_numpy()
        s_sc = pd.to_numeric(val_sc["sc_score_derived"], errors="coerce").fillna(0).to_numpy()
        thresholds[("SC Only", disease)] = best_threshold_search(y_sc, s_sc)

        y_fu = binarize_label(val_fusion[disease]).to_numpy()
        s_fu = pd.to_numeric(val_fusion["fusion_score"], errors="coerce").fillna(0).to_numpy()
        thresholds[("Optimized Fusion", disease)] = best_threshold_search(y_fu, s_fu)

    return thresholds


def build_val_threshold_for_single_target_model(
    val_truth_df: pd.DataFrame,
    val_pred_df: pd.DataFrame,
    outcome_col: str,
    model_name: str,
) -> float:
    merged = val_truth_df.merge(
        val_pred_df[["subject_id", "study_id", "rf_score"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    if merged.empty:
        raise ValueError(f"{model_name} validation merge is empty.")

    if outcome_col not in merged.columns:
        raise KeyError(f"{model_name}: outcome column '{outcome_col}' not found in validation truth.")

    y_val = binarize_label(merged[outcome_col]).to_numpy()
    s_val = pd.to_numeric(merged["rf_score"], errors="coerce").fillna(0).to_numpy()

    return best_threshold_search(y_val, s_val)


# =========================================================
# Evaluation
# =========================================================
def evaluate_multilabel_models_on_test(
    truth_df: pd.DataFrame,
    fusion_test_df: pd.DataFrame,
    cm_test_df: pd.DataFrame,
    sc_test_df: pd.DataFrame,
    label_cols: List[str],
    thresholds: Dict[Tuple[str, str], float],
) -> List[Dict[str, object]]:
    rows = []

    test_cm = truth_df.merge(
        cm_test_df[["subject_id", "study_id", "cm_score_derived"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    test_sc = truth_df.merge(
        sc_test_df[["subject_id", "study_id", "sc_score_derived"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    test_fusion = truth_df.merge(
        fusion_test_df[["subject_id", "study_id", "cm_score", "sc_score", "fusion_score"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    for disease in label_cols:
        y_cm = binarize_label(test_cm[disease]).to_numpy()
        s_cm = pd.to_numeric(test_cm["cm_score_derived"], errors="coerce").fillna(0).to_numpy()
        rows.append(
            evaluate_metrics(
                y_true=y_cm,
                y_score=s_cm,
                disease=disease,
                model="CM Only",
                threshold=thresholds[("CM Only", disease)],
            )
        )

        y_sc = binarize_label(test_sc[disease]).to_numpy()
        s_sc = pd.to_numeric(test_sc["sc_score_derived"], errors="coerce").fillna(0).to_numpy()
        rows.append(
            evaluate_metrics(
                y_true=y_sc,
                y_score=s_sc,
                disease=disease,
                model="SC Only",
                threshold=thresholds[("SC Only", disease)],
            )
        )

        y_fu = binarize_label(test_fusion[disease]).to_numpy()
        s_fu = pd.to_numeric(test_fusion["fusion_score"], errors="coerce").fillna(0).to_numpy()
        rows.append(
            evaluate_metrics(
                y_true=y_fu,
                y_score=s_fu,
                disease=disease,
                model="Optimized Fusion",
                threshold=thresholds[("Optimized Fusion", disease)],
            )
        )

    return rows


def evaluate_single_target_model_on_test(
    test_truth_df: pd.DataFrame,
    test_pred_df: pd.DataFrame,
    outcome_col: str,
    model_name: str,
    threshold: float,
) -> List[Dict[str, object]]:
    merged = test_truth_df.merge(
        test_pred_df[["subject_id", "study_id", "rf_score"]],
        on=["subject_id", "study_id"],
        how="inner",
        validate="one_to_one",
    )

    if merged.empty:
        raise ValueError(f"{model_name} test merge is empty.")

    if outcome_col not in merged.columns:
        raise KeyError(f"{model_name}: outcome column '{outcome_col}' not found in test truth.")

    y_test = binarize_label(merged[outcome_col]).to_numpy()
    s_test = pd.to_numeric(merged["rf_score"], errors="coerce").fillna(0).to_numpy()

    row = evaluate_metrics(
        y_true=y_test,
        y_score=s_test,
        disease=outcome_col,
        model=model_name,
        threshold=threshold,
    )
    return [row]


# =========================================================
# Main
# =========================================================
def main():
    warnings.filterwarnings("ignore")

    base_cfg = load_yaml(BASE_CFG_PATH)
    vision_cfg = load_yaml(VISION_CFG_PATH)

    paths = base_cfg.get("paths", {})
    label_cols = vision_cfg.get("data", {}).get("label_columns", [])

    if not label_cols:
        raise ValueError("No label_columns found in vision_config.yaml")

    # -----------------------------
    # Core known paths
    # -----------------------------
    truth_path = Path(paths["mimic_prepared_csv"])
    fusion_output_dir = Path(paths["fusion_output_dir"])

    fusion_val_path = fusion_output_dir / "fusion_val_results.csv"
    fusion_test_path = fusion_output_dir / "fusion_test_results.csv"
    best_alpha_json = fusion_output_dir / "best_alpha.json"

    cm_val_path = Path("../gpu_base/results/final_mimic_cm_val_output.csv")
    sc_val_path = Path(paths["sc_val_output"])
    cm_test_path = Path(paths["cm_test_output"])
    sc_test_path = Path(paths["sc_test_output"])

    out_dir = ensure_dir(fusion_output_dir / "all_models")

    # -----------------------------
    # Optional RF paths
    # -----------------------------
    rf_val_output = paths.get("rf_val_output", None)
    rf_qfl_val_output = paths.get("rf_qfl_val_output", None)
    rf_test_output = paths.get("rf_output", None)
    rf_qfl_test_output = paths.get("rf_qfl_output", None)

    # outcome columns for DCS / QFL
    dcs_outcome_col = paths.get("rf_outcome_col", "outcome")
    qfl_outcome_col = paths.get("rf_qfl_outcome_col", "outcome")

    # -----------------------------
    # Existence checks
    # -----------------------------
    required_files = {
        "truth_path": truth_path,
        "fusion_val_path": fusion_val_path,
        "fusion_test_path": fusion_test_path,
        "cm_val_path": cm_val_path,
        "sc_val_path": sc_val_path,
        "cm_test_path": cm_test_path,
        "sc_test_path": sc_test_path,
    }

    missing = [name for name, p in required_files.items() if not Path(p).exists()]
    if missing:
        lines = [f"{name}: {required_files[name]}" for name in missing]
        raise FileNotFoundError("Missing required files:\n" + "\n".join(lines))

    # -----------------------------
    # Load truth
    # -----------------------------
    truth_df = prepare_truth_dataframe(truth_path, label_cols)

    # -----------------------------
    # Load fusion / cm / sc
    # -----------------------------
    fusion_val_df = prepare_fusion_dataframe(fusion_val_path, "fusion_val_results")
    fusion_test_df = prepare_fusion_dataframe(fusion_test_path, "fusion_test_results")

    cm_val_df = prepare_cm_output_dataframe(cm_val_path, "cm_val_output")
    cm_test_df = prepare_cm_output_dataframe(cm_test_path, "cm_test_output")

    sc_val_df = prepare_sc_output_dataframe(sc_val_path, "sc_val_output")
    sc_test_df = prepare_sc_output_dataframe(sc_test_path, "sc_test_output")

    # -----------------------------
    # Build thresholds from validation
    # -----------------------------
    thresholds = build_val_thresholds_for_multilabel_models(
        truth_df=truth_df,
        fusion_val_df=fusion_val_df,
        cm_val_df=cm_val_df,
        sc_val_df=sc_val_df,
        label_cols=label_cols,
    )

    # Save thresholds
    thr_df = pd.DataFrame(
        [
            {"model": model, "disease": disease, "threshold": thr}
            for (model, disease), thr in thresholds.items()
        ]
    ).sort_values(["model", "disease"])

    thr_df.to_csv(out_dir / "validation_selected_thresholds.csv", index=False)

    # -----------------------------
    # Evaluate CM / SC / Fusion on test
    # -----------------------------
    metrics_rows = evaluate_multilabel_models_on_test(
        truth_df=truth_df,
        fusion_test_df=fusion_test_df,
        cm_test_df=cm_test_df,
        sc_test_df=sc_test_df,
        label_cols=label_cols,
        thresholds=thresholds,
    )

    # -----------------------------
    # Optional: DCS
    # -----------------------------
    dcs_included = False
    if rf_val_output and rf_test_output:
        rf_val_path = Path(rf_val_output)
        rf_test_path = Path(rf_test_output)

        if rf_val_path.exists() and rf_test_path.exists():
            dcs_val_df = prepare_rf_output_dataframe(
                rf_val_path,
                ["Rf_DCS", "rf_dcs", "DCS", "score"],
                "rf_val_output",
            )
            dcs_test_df = prepare_rf_output_dataframe(
                rf_test_path,
                ["Rf_DCS", "rf_dcs", "DCS", "score"],
                "rf_test_output",
            )

            dcs_threshold = build_val_threshold_for_single_target_model(
                val_truth_df=truth_df,
                val_pred_df=dcs_val_df,
                outcome_col=dcs_outcome_col,
                model_name="DCS",
            )

            metrics_rows.extend(
                evaluate_single_target_model_on_test(
                    test_truth_df=truth_df,
                    test_pred_df=dcs_test_df,
                    outcome_col=dcs_outcome_col,
                    model_name="DCS",
                    threshold=dcs_threshold,
                )
            )
            dcs_included = True

    # -----------------------------
    # Optional: QFL
    # -----------------------------
    qfl_included = False
    if rf_qfl_val_output and rf_qfl_test_output:
        qfl_val_path = Path(rf_qfl_val_output)
        qfl_test_path = Path(rf_qfl_test_output)

        if qfl_val_path.exists() and qfl_test_path.exists():
            qfl_val_df = prepare_rf_output_dataframe(
                qfl_val_path,
                ["Rf_QFL", "rf_qfl", "QFL", "score"],
                "rf_qfl_val_output",
            )
            qfl_test_df = prepare_rf_output_dataframe(
                qfl_test_path,
                ["Rf_QFL", "rf_qfl", "QFL", "score"],
                "rf_qfl_test_output",
            )

            qfl_threshold = build_val_threshold_for_single_target_model(
                val_truth_df=truth_df,
                val_pred_df=qfl_val_df,
                outcome_col=qfl_outcome_col,
                model_name="QFL",
            )

            metrics_rows.extend(
                evaluate_single_target_model_on_test(
                    test_truth_df=truth_df,
                    test_pred_df=qfl_test_df,
                    outcome_col=qfl_outcome_col,
                    model_name="QFL",
                    threshold=qfl_threshold,
                )
            )
            qfl_included = True

    # -----------------------------
    # Save metrics
    # -----------------------------
    metrics_df = pd.DataFrame(metrics_rows)
    metrics_csv = out_dir / "evaluation_all_models_metrics.csv"
    metrics_df.to_csv(metrics_csv, index=False)

    # summary
    summary_cols = ["auc", "f1", "accuracy", "recall_score", "specificity", "balanced_acc"]
    summary_df = (
        metrics_df.groupby("model", as_index=False)[summary_cols]
        .mean(numeric_only=True)
        .sort_values("auc", ascending=False)
    )

    summary_csv = out_dir / "all_models_summary.csv"
    summary_df.to_csv(summary_csv, index=False)

    final_report_csv = out_dir / "final_summary_report.csv"
    summary_df.to_csv(final_report_csv, index=False)

    # plots
    plot_auc_comparison(metrics_df, out_dir / "auc_comparison_per_disease.png")
    plot_average_performance(summary_df, out_dir / "average_performance_summary.png")

    # metadata / audit note
    alpha_val = load_best_alpha_if_exists(best_alpha_json)
    audit_info = {
        "best_alpha_found": alpha_val is not None,
        "best_alpha": alpha_val,
        "cm_sc_fusion_threshold_source": "validation",
        "test_threshold_tuning": False,
        "test_minmax_fit": False,
        "dcs_included": dcs_included,
        "qfl_included": qfl_included,
        "dcs_outcome_col": dcs_outcome_col if dcs_included else None,
        "qfl_outcome_col": qfl_outcome_col if qfl_included else None,
    }

    with (out_dir / "evaluation_metadata.json").open("w", encoding="utf-8") as f:
        json.dump(audit_info, f, ensure_ascii=False, indent=2)

    print("\n✅ Validation-aware evaluation completed successfully.")
    print(f"Metrics CSV: {metrics_csv}")
    print(f"Summary CSV: {summary_csv}")
    print(f"Final report CSV: {final_report_csv}")
    print(f"Thresholds CSV: {out_dir / 'validation_selected_thresholds.csv'}")
    print(f"AUC plot: {out_dir / 'auc_comparison_per_disease.png'}")
    print(f"Average summary plot: {out_dir / 'average_performance_summary.png'}")
    print(f"Metadata JSON: {out_dir / 'evaluation_metadata.json'}")

    if not dcs_included:
        print("ℹ️ DCS skipped: rf_val_output / rf_output not fully available in config or files missing.")
    if not qfl_included:
        print("ℹ️ QFL skipped: rf_qfl_val_output / rf_qfl_output not fully available in config or files missing.")


if __name__ == "__main__":
    main()
