# run_pipeline_menu.py
import subprocess

def main():
    options = {
        "0": "run_prepare_metadata.py",
        "1": "run_prepare_dataset.py",
        "2": "run_minimize_dataset.py",
        "3": "run_train_swin_cm.py",
        "4": "run_compute_sc.py",
        "5": "run_compute_dcs_weights.py",
        "6": "run_compute_qfl_weights.py",
        
        # گام‌های تست (که از قبل انجام شده‌اند)
        "7": "run_compute_cm_test_dst.py",
        "8": "run_compute_sc_test_dst.py",
        
        # گام‌های جدید مربوط به Validation و امبدینگ‌های آن
        "9": "run_make_val_split.py",          # ساخت فایل شناسه‌های Validation
        "10": "run_compute_cm_val_dst.py",      # محاسبه امبدینگ CM برای Validation
        "11": "run_compute_sc_val_dst.py",      # محاسبه امبدینگ SC برای Validation
        
        # بهینه‌سازی، ارزیابی و آمار نهایی
        "12": "run_optimize_and_match_fusion.py", # تطبیق و بهینه‌سازی وزن‌ها روی Validation
        "13": "run_ablation_study.py",           # [NEW] Ablation & Robustness Study
        "14": "run_audit_before_eval.py",       
        "15": "run_eval_metrics_050428.py",     # تست نهایی روی دیتای Test
        "16": "run_visualize_final_results.py",               
        "17": "run_eval_metrics_all.py",               
    }

    print("=================================================================")
    print("                 MIMIC Fusion Pipeline Control                   ")
    print("=================================================================")
    print("Select the action to perform:")
    print(" 0: Prepare metadata")
    print(" 1: Prepare dataset")
    print(" 2: Minimize dataset")
    print(" 3: Train SwinNet 2D and compute Cm (Train Embeddings)")
    print(" 4: Compute Sc (Train Embeddings)")
    print(" 5: Compute DCS weights")
    print(" 6: Compute QFL weights")
    print("-----------------------------------------------------------------")
    print(" 7: Run compute Cm embedding for Test dataset (Done)")
    print(" 8: Run compute Sc embedding for Test dataset (Done)")
    print("-----------------------------------------------------------------")
    print(" 9: [NEW] Generate Validation Study IDs Split (No Leakage)")
    print("10: [NEW] Compute Cm Embeddings for Validation Dataset")
    print("11: [NEW] Compute Sc Embeddings for Validation Dataset")
    print("-----------------------------------------------------------------")
    print("12: Optimize Fusion Weights (Val Dataset) & Match CM/SC")
    print("13: [NEW] Run Ablation & Robustness Study (Val Dataset)")        
    print("14: Run Audit Before Evaluation")
    print("15: Run compute RF & Evaluation Metrics (Enhanced on Test Set)")        
    print("16: Run visualize final results")
    print("17: Run Eval Metrics All")

    print("=================================================================")
    
    choice = input("Enter your choice (0-17): ").strip()
    script = options.get(choice)
    
    if script:
        print(f"\n>>> Running: {script}...\n")
        subprocess.run(["python", script])
    else:
        print("Invalid choice")

if __name__ == "__main__":
    main()