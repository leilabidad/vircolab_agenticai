import pandas as pd
import torch
import timm
from torch.utils.data import DataLoader

from src.vision.dataset import DualViewCXRDataset
from src.vision.model import DualViewSwin
from src.vision.utils import load_cfg, cxr_transform


def extract_cm_dual(model, frontal, lateral):
    """
    Extract CM embedding using the trained CmFusionBlock
    (NOT just backbone averaging).
    """
    # CRITICAL FIX: Use the full model forward pass to get CM
    # This ensures consistency with training (Step 3)
    _, cm = model(frontal, lateral)
    
    if cm.ndim != 2:
        raise RuntimeError(f"Unexpected CM embedding shape: {tuple(cm.shape)}")
    
    return cm


def main():
    cfg = load_cfg("./config/config.yaml")
    cfg1 = load_cfg("./config/vision_config.yaml")

    paths = cfg["paths"]

    TEST_CSV = paths["final_mimic_visit_level_test"]
    CHECKPOINT = paths["checkpoint"]
    OUTPUT_CSV = paths["cm_test_output"]

    print(f"[INFO] TEST_CSV = {TEST_CSV}")
    print(f"[INFO] CHECKPOINT = {CHECKPOINT}")
    print(f"[INFO] OUTPUT_CSV = {OUTPUT_CSV}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] device = {device}")

    dataset = DualViewCXRDataset(
        csv_path=TEST_CSV,
        cfg=cfg1,
        split="test",
        transform=cxr_transform()
    )

    print(f"[INFO] test dataset size = {len(dataset)}")

    loader = DataLoader(
        dataset,
        batch_size=cfg1["training"]["batch_size"],
        shuffle=False,
        num_workers=4
    )

    backbone = timm.create_model(
        "swin_base_patch4_window7_224",
        pretrained=True,
        num_classes=0
    )

    model = DualViewSwin(
        backbone=backbone,
        out_dim=len(cfg1["data"]["label_columns"])
    ).to(device)

    state_dict = torch.load(CHECKPOINT, map_location=device)
    missing, unexpected = model.load_state_dict(state_dict, strict=False)

    print(f"[INFO] Missing keys: {missing}")
    print(f"[INFO] Unexpected keys: {unexpected}")
    
    # Check if cm_fusion weights are loaded
    if any("cm_fusion" in k for k in missing):
        print("[ERROR] cm_fusion weights are missing! Checkpoint may be from old training.")
        print("Please re-run Step 3 (run_train_swin_cm.py) with the updated code.")
    
    model.eval()

    rows = []
    cm_norms = []

    with torch.no_grad():
        for batch_idx, batch in enumerate(loader):
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            subject_id = batch[-2]
            study_id = batch[-1]

            # CRITICAL FIX: Use the corrected extract_cm_dual function
            cm = extract_cm_dual(model, frontal, lateral)
            cm_np = cm.cpu().numpy()

            batch_norms = torch.norm(cm, dim=1).detach().cpu().numpy()
            cm_norms.extend(batch_norms.tolist())

            if batch_idx == 0:
                print(f"[DEBUG] First batch CM shape: {cm_np.shape}")
                print(f"[DEBUG] First batch CM sample: {cm_np[0, :5] if cm_np.shape[0] > 0 else 'N/A'}")
                print(f"[DEBUG] First batch CM norm: {batch_norms[0]:.4f}")

            for i in range(cm_np.shape[0]):
                row = {
                    "subject_id": str(subject_id[i]),
                    "study_id": str(study_id[i]),
                }
                for j in range(cm_np.shape[1]):
                    row[f"cm_{j}"] = float(cm_np[i, j])
                rows.append(row)

    df = pd.DataFrame(rows)

    if df.empty:
        raise RuntimeError("No CM embeddings were generated for test set.")

    cm_cols = [c for c in df.columns if c.startswith("cm_")]
    if not cm_cols:
        raise RuntimeError("No cm_* columns were generated.")

    emb_std_mean = float(df[cm_cols].std().mean())
    emb_min = float(df[cm_cols].min().min())
    emb_max = float(df[cm_cols].max().max())

    print(f"[INFO] test output rows = {len(df)}")
    print(f"[INFO] number of cm columns = {len(cm_cols)}")
    print(
        f"[DEBUG] CM embedding stats -> min={emb_min:.6f}, "
        f"max={emb_max:.6f}, mean std={emb_std_mean:.6f}"
    )

    if len(cm_norms) > 0:
        norm_series = pd.Series(cm_norms)
        norm_min = float(norm_series.min())
        norm_max = float(norm_series.max())
        norm_std = float(norm_series.std())
        print(
            f"[DEBUG] CM norm stats -> min={norm_min:.6f}, "
            f"max={norm_max:.6f}, std={norm_std:.6f}"
        )

        # CRITICAL CHECK: With Soft Normalize, norms should be around 10.0
        if abs(norm_min - 10.0) > 2.0 or abs(norm_max - 10.0) > 2.0:
            print(
                f"[WARN] CM norms are not around 10.0 (expected with Soft Normalize). "
                f"Got range [{norm_min:.2f}, {norm_max:.2f}]. "
                f"This may indicate the checkpoint is from old training without Soft Normalize."
            )

        if norm_std == 0.0:
            print(
                "[WARN] CM norms are constant across all test samples. "
                "This may indicate embedding collapse or identical extraction."
            )

    if emb_std_mean == 0.0:
        print(
            "[WARN] Mean std of CM embedding columns is 0. "
            "Embeddings appear constant across rows."
        )

    df.to_csv(OUTPUT_CSV, index=False)
    print(f"[INFO] Saved test CM embeddings to: {OUTPUT_CSV}")


if __name__ == "__main__":
    main()