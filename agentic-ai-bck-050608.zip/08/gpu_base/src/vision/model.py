import torch
import torch.nn as nn
import torch.nn.functional as F


class CmFusionBlock(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        hidden = dim * 2

        self.fuse = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        self.gate = nn.Sequential(
            nn.Linear(dim * 4, dim),
            nn.Sigmoid()
        )

        self.refine = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU()
        )

    def forward(self, x_f, x_l):
        avg = 0.5 * (x_f + x_l)
        diff = torch.abs(x_f - x_l)
        prod = x_f * x_l

        fused_in = torch.cat([x_f, x_l, diff, prod], dim=1)

        gate = self.gate(fused_in)
        learned = self.fuse(fused_in)

        cm = gate * learned + (1.0 - gate) * avg
        cm = cm + 0.25 * diff
        cm = self.refine(cm)
        
        # Soft Normalize
        norm = torch.norm(cm, p=2, dim=1, keepdim=True).clamp(min=1e-6)
        target_norm = 10.0
        cm = cm * (target_norm / norm)
        
        return cm


class DualViewSwin(nn.Module):
    def __init__(self, backbone, out_dim):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = backbone.num_features
        self.cm_fusion = CmFusionBlock(self.embed_dim)
        self.classifier = nn.Linear(self.embed_dim, out_dim)

    def forward(self, frontal, lateral):
        x_f = self.backbone(frontal)
        x_l = self.backbone(lateral)
        cm = self.cm_fusion(x_f, x_l)
        logits = self.classifier(cm)
        return logits, cm