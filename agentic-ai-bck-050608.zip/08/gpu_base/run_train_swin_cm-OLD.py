import os
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from torch import optim
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.vision.dataset import DualViewCXRDataset
from src.vision.utils import load_cfg, cxr_transform

# ---------------------------------------------------------
# 1. Advanced CmFusionBlock
# ---------------------------------------------------------
class CmFusionBlock(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        hidden = dim * 2

        self.fuse = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        self.gate = nn.Sequential(
            nn.Linear(dim * 4, dim),
            nn.Sigmoid()
        )

        self.refine = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU()
        )

    def forward(self, x_f, x_l):
        avg = 0.5 * (x_f + x_l)
        diff = torch.abs(x_f - x_l)
        prod = x_f * x_l

        fused_in = torch.cat([x_f, x_l, diff, prod], dim=1) 

        gate = self.gate(fused_in)
        learned = self.fuse(fused_in)

        cm = gate * learned + (1.0 - gate) * avg
        cm = cm + 0.25 * diff
        cm = self.refine(cm)
        
        return F.normalize(cm, p=2, dim=1)

# ---------------------------------------------------------
# 2. Model Wrapper
# ---------------------------------------------------------
class DualViewSwin(nn.Module):
    def __init__(self, backbone, out_dim):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = backbone.num_features
        self.cm_fusion = CmFusionBlock(self.embed_dim)
        self.classifier = nn.Linear(self.embed_dim, out_dim)

    def forward(self, frontal, lateral):
        x_f = self.backbone(frontal)
        x_l = self.backbone(lateral)
        cm = self.cm_fusion(x_f, x_l)
        logits = self.classifier(cm)
        return logits, cm

# ---------------------------------------------------------
# 3. Main Training Script
# ---------------------------------------------------------
def main():
    cfg = load_cfg("./config/vision_config.yaml")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    dataset = DualViewCXRDataset(
        cfg["paths"]["csv"],
        cfg,
        cfg["data"]["train_split"],
        cxr_transform()
    )
    loader = DataLoader(
        dataset, 
        batch_size=cfg["training"]["batch_size"], 
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )

    backbone = timm.create_model(
        "swin_base_patch4_window7_224", 
        pretrained=True, 
        num_classes=0
    )
    
    model = DualViewSwin(
        backbone, 
        out_dim=len(cfg["data"]["label_columns"])
    ).to(device)

    optimizer = optim.AdamW(model.parameters(), lr=cfg["training"]["lr"])
    epochs = cfg["training"]["epochs"]
    
    print(f"Starting training for {epochs} epochs...")
    model.train()

    for epoch in range(epochs):
        pbar = tqdm(loader, desc=f"Epoch {epoch+1}/{epochs}")
        epoch_loss = 0
        
        for batch in pbar:
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            raw_labels = batch[2].to(device).float() 

            optimizer.zero_grad()
            logits, _ = model(frontal, lateral)

            # Masking Logic for -1 (Uncertain) labels
            valid_mask = (raw_labels != -1).float()
            targets = torch.where(raw_labels == -1, torch.zeros_like(raw_labels), raw_labels)

            loss_matrix = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
            masked_loss = (loss_matrix * valid_mask).sum() / valid_mask.sum().clamp(min=1e-6)

            masked_loss.backward()
            optimizer.step()

            epoch_loss += masked_loss.item()
            pbar.set_postfix({"loss": f"{masked_loss.item():.4f}"})

        print(f"Epoch {epoch+1} Average Loss: {epoch_loss/len(loader):.6f}")

    # Save Checkpoint
    checkpoint_path = cfg["paths"]["checkpoint"]
    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
    torch.save(model.state_dict(), checkpoint_path)
    print(f"Model saved to {checkpoint_path}")

    # ---------------------------------------------------------
    # 4. Final Cm Extraction
    # ---------------------------------------------------------
    print("Extracting final embeddings (Cm)...")
    model.eval()
    all_rows = []

    with torch.no_grad():
        for batch in tqdm(loader, desc="Extraction"):
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            # IDs are usually the last two elements in your dataset batch
            subject_ids = batch[-2]
            study_ids = batch[-1]

            _, cm = model(frontal, lateral)
            
            cm_np = cm.cpu().numpy()
            for i in range(len(subject_ids)):
                # Handle potential tensor/scalar subject_ids
                s_id = subject_ids[i].item() if torch.is_tensor(subject_ids[i]) else subject_ids[i]
                st_id = study_ids[i].item() if torch.is_tensor(study_ids[i]) else study_ids[i]
                
                row = {
                    "subject_id": s_id,
                    "study_id": st_id
                }
                for j, val in enumerate(cm_np[i]):
                    row[f"cm_{j}"] = val
                all_rows.append(row)

    df_cm = pd.DataFrame(all_rows)
    # BUG FIXED: .to_csv instead of .to(csv
    df_cm.to_csv(cfg["paths"]["cm_output"], index=False)
    print(f"Embeddings saved to {cfg['paths']['cm_output']}")

if __name__ == "__main__":
    main()
