import os
import json
import yaml
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

BASE_CFG_PATH = "./config/config.yaml"
VISION_CFG_PATH = "./config/vision_config.yaml"


def load_yaml(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def normalize_ids(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in ["subject_id", "study_id"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.replace(r"\.0$", "", regex=True)
                .str.replace(r"tensor\(", "", regex=True)
                .str.replace(r"\)", "", regex=True)
            )
    return df


def safe_numeric_series(s):
    return pd.to_numeric(s, errors="coerce").fillna(0.0).astype(float)


def minmax_scale(x):
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return x
    mn = np.nanmin(x)
    mx = np.nanmax(x)
    if np.isclose(mx, mn):
        return np.zeros_like(x, dtype=float)
    return (x - mn) / (mx - mn)


def evaluate_metrics(y_true, scores, threshold, model_name, label_name):
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)

    y_true = np.where(y_true > 0, 1, 0)
    y_pred = (scores >= threshold).astype(int)

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

    try:
        auc = roc_auc_score(y_true, scores) if len(np.unique(y_true)) > 1 else np.nan
    except Exception:
        auc = np.nan

    return {
        "disease": label_name,
        "model": model_name,
        "n": len(y_true),
        "auc": auc,
        "threshold": float(threshold),
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_acc": balanced_accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall_score": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp) if (tn + fp) > 0 else 0.0,
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "tp": int(tp),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
    }


def best_threshold_search(y_true, scores, n_grid=201):
    y_true = np.where(np.asarray(y_true) > 0, 1, 0)
    scores = np.asarray(scores).astype(float)

    finite_mask = np.isfinite(scores) & np.isfinite(y_true)
    y_true = y_true[finite_mask]
    scores = scores[finite_mask]

    if len(y_true) == 0 or len(np.unique(scores)) <= 1 or len(np.unique(y_true)) <= 1:
        return 0.5, 0.0

    lo, hi = float(np.nanmin(scores)), float(np.nanmax(scores))
    thresholds = np.linspace(lo, hi, n_grid)
    best_t = 0.5
    best_f1 = -1.0

    for t in thresholds:
        pred = (scores >= t).astype(int)
        f1 = f1_score(y_true, pred, zero_division=0)
        if f1 > best_f1:
            best_f1 = f1
            best_t = t

    return float(best_t), float(best_f1)


def merge_with_ground_truth(df_scores, df_full, label_cols):
    common_cols = ["subject_id", "study_id"]
    common_cols = [c for c in common_cols if c in df_scores.columns and c in df_full.columns]

    if not common_cols:
        raise KeyError("No common merge keys (subject_id or study_id) found between results and metadata.")

    merged_df = pd.merge(
        df_scores,
        df_full[common_cols + label_cols],
        on=common_cols,
        how="inner",
    )

    if merged_df.empty:
        raise ValueError("Merged dataset is empty! Check subject_id/study_id matching.")

    return merged_df, common_cols


def compute_model_scores(df):
    return {
        "CM Only": minmax_scale(safe_numeric_series(df["cm_score"])),
        "SC Only": minmax_scale(safe_numeric_series(df["sc_score"])),
        "Optimized Fusion": minmax_scale(safe_numeric_series(df["fusion_score"])),
    }


def main():
    print(">>> Starting Final Evaluation (Step 14)...")

    base_cfg = load_yaml(BASE_CFG_PATH)
    vision_cfg = load_yaml(VISION_CFG_PATH)

    paths = base_cfg.get("paths", {})
    label_cols = vision_cfg["data"]["label_columns"]
    if isinstance(label_cols, str):
        label_cols = [label_cols]

    fusion_output_dir = Path(paths.get("fusion_output_dir", "../gpu_base/results/fusion/"))
    fusion_val_path = fusion_output_dir / "fusion_val_results.csv"
    fusion_test_path = fusion_output_dir / "fusion_test_results.csv"

    if not fusion_val_path.exists():
        raise FileNotFoundError(f"Optimized fusion validation results not found: {fusion_val_path}")

    if not fusion_test_path.exists():
        raise FileNotFoundError(f"Optimized fusion test results not found: {fusion_test_path}")

    full_csv_path = Path(paths.get("mimic_prepared_csv"))
    if not full_csv_path.exists():
        raise FileNotFoundError(f"Metadata file not found: {full_csv_path}")

    df_full = normalize_ids(pd.read_csv(full_csv_path))
    df_val = normalize_ids(pd.read_csv(fusion_val_path))
    df_test = normalize_ids(pd.read_csv(fusion_test_path))

    merged_val, common_cols = merge_with_ground_truth(df_val, df_full, label_cols)
    merged_test, _ = merge_with_ground_truth(df_test, df_full, label_cols)

    print(f">> Successfully merged validation data on keys: {common_cols}. Total records: {len(merged_val)}")
    print(f">> Successfully merged test data on keys: {common_cols}. Total records: {len(merged_test)}")

    val_scores_by_model = compute_model_scores(merged_val)
    test_scores_by_model = compute_model_scores(merged_test)

    best_thresholds = {
        "CM Only": {},
        "SC Only": {},
        "Optimized Fusion": {},
    }

    threshold_rows = []

    print(">> Searching optimal thresholds on validation set...")

    for label in label_cols:
        if label not in merged_val.columns:
            continue

        y_val_raw = merged_val[label].fillna(0).values
        y_val = np.where(y_val_raw > 0, 1, 0)

        for model_name, scores in val_scores_by_model.items():
            best_t, best_f1 = best_threshold_search(y_val, scores)
            best_thresholds[model_name][label] = best_t
            threshold_rows.append(
                {
                    "disease": label,
                    "model": model_name,
                    "val_best_threshold": float(best_t),
                    "val_best_f1": float(best_f1),
                }
            )

    evaluation_rows = []

    print(">> Evaluating test set using thresholds selected from validation...")

    for label in label_cols:
        if label not in merged_test.columns:
            continue

        y_test_raw = merged_test[label].fillna(0).values
        y_test = np.where(y_test_raw > 0, 1, 0)

        for model_name, scores in test_scores_by_model.items():
            threshold = best_thresholds[model_name].get(label, 0.5)
            metrics = evaluate_metrics(y_test, scores, threshold, model_name, label)
            evaluation_rows.append(metrics)

    report_df = pd.DataFrame(evaluation_rows)
    threshold_df = pd.DataFrame(threshold_rows)

    fusion_output_dir.mkdir(parents=True, exist_ok=True)

    metrics_out_path = fusion_output_dir / "evaluation_final_metrics.csv"
    thresholds_out_path = fusion_output_dir / "selected_thresholds_from_val.csv"

    report_df.to_csv(metrics_out_path, index=False, encoding="utf-8-sig")
    threshold_df.to_csv(thresholds_out_path, index=False, encoding="utf-8-sig")

    summary_df = (
        report_df.groupby("model")[["auc", "f1", "accuracy", "specificity", "recall_score"]]
        .mean()
        .reset_index()
    )
    summary_df.rename(columns={"recall_score": "sensitivity (recall)"}, inplace=True)

    print("\n" + "=" * 70)
    print("                EVALUATION COMPLETED SUCCESSFULLY")
    print("=" * 70)
    print("Thresholds were selected on validation and applied unchanged to test.")
    print(summary_df.to_string(index=False))
    print("=" * 70)
    print(f"Detailed metric file saved to: {metrics_out_path.resolve()}")
    print(f"Validation-selected thresholds saved to: {thresholds_out_path.resolve()}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
