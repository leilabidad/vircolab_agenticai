import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path
import yaml

# تنظیمات ظاهری برای مقالات
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({'font.size': 12, 'figure.dpi': 150})

def load_config(path="./config/config.yaml"):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def main():
    print(">>> Starting Step 15: Final Visualization & Analytics...")
    
    cfg = load_config()
    results_dir = Path(cfg['paths'].get('fusion_output_dir', '../gpu_base/results/fusion/'))
    metrics_path = results_dir / "evaluation_final_metrics.csv"
    viz_dir = results_dir / "visualizations"
    viz_dir.mkdir(parents=True, exist_ok=True)

    if not metrics_path.exists():
        print(f"Error: Metrics file not found at {metrics_path}")
        return

    df = pd.read_csv(metrics_path)

    # 1. بارچارت مقایسه‌ای AUC برای هر بیماری
    plt.figure(figsize=(14, 8))
    sns.barplot(data=df, x='disease', y='auc', hue='model', palette='viridis')
    plt.title('Comparison of AUC Scores across 13 Pathologies', fontsize=16)
    plt.xticks(rotation=45, ha='right')
    plt.ylabel('Area Under ROC (AUC)')
    plt.axhline(0.5, ls='--', color='red', alpha=0.5, label='Random Guess')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig(viz_dir / "auc_comparison_per_disease.png")
    print(f"Saved: auc_comparison_per_disease.png")

    # 2. مقایسه میانگین متریک‌ها (Radar Chart یا Bar Chart)
    summary = df.groupby('model')[['auc', 'f1', 'accuracy', 'recall_score', 'specificity']].mean().reset_index()
    summary_melted = summary.melt(id_vars='model', var_name='Metric', value_name='Score')

    plt.figure(figsize=(10, 6))
    sns.barplot(data=summary_melted, x='Metric', y='Score', hue='model', palette='magma')
    plt.title('Average Model Performance Comparison', fontsize=15)
    plt.ylim(0, 1.0)
    plt.tight_layout()
    plt.savefig(viz_dir / "average_performance_summary.png")
    print(f"Saved: average_performance_summary.png")

    # 3. تولید جدول متنی برای لاگ
    print("\n" + "="*30)
    print("FINAL PERFORMANCE SUMMARY")
    print("="*30)
    print(summary.to_string(index=False))
    print("="*30)

    # 4. ذخیره فایل اکسل نهایی برای ضمیمه مقاله
    summary.to_csv(results_dir / "final_summary_report.csv", index=False)
    print(f"Final summary report saved to: {results_dir / 'final_summary_report.csv'}")

if __name__ == "__main__":
    main()
