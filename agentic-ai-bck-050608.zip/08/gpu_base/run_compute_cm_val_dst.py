import pandas as pd
import torch
import timm
from torch.utils.data import DataLoader
import os

from src.vision.dataset import DualViewCXRDataset
from src.vision.model import DualViewSwin
from src.vision.utils import load_cfg, cxr_transform


def extract_cm_dual(model, frontal, lateral):
    """
    Extract CM embedding using the trained CmFusionBlock
    (NOT just backbone averaging).
    """
    # CRITICAL FIX: Use the full model forward pass to get CM
    # This ensures consistency with training (Step 3)
    _, cm = model(frontal, lateral)
    
    return cm


def main():
    cfg = load_cfg("./config/config.yaml")
    cfg1 = load_cfg("./config/vision_config.yaml")

    paths = cfg["paths"]
    
    VAL_STUDY_IDS_CSV = paths["final_mimic_visit_level_val_study_ids"]
    FULL_DATA_CSV = paths["mimic_prepared_csv"]
    CHECKPOINT = paths["checkpoint"]
    OUTPUT_CSV = paths["cm_val_output"]

    print(f"[INFO] Loading IDs from: {VAL_STUDY_IDS_CSV}")
    df_ids = pd.read_csv(VAL_STUDY_IDS_CSV)
    
    print(f"[INFO] Loading full data to get image paths: {FULL_DATA_CSV}")
    df_full = pd.read_csv(FULL_DATA_CSV)

    
    #######################################
    
    # پاک‌سازی study_id قبل از merge
    df_ids['study_id'] = (
        df_ids['study_id']
        .astype(str)
        .str.strip()
        .str.replace('tensor(', '', regex=False)
        .str.replace(')', '', regex=False)
        .str.strip()
    )

    df_full['study_id'] = (
        df_full['study_id']
        .astype(str)
        .str.strip()
        .str.replace('tensor(', '', regex=False)
        .str.replace(')', '', regex=False)
        .str.strip()
    )

    df_val = pd.merge(df_ids[['study_id']], df_full, on='study_id', how='inner')


    ####################################
    
    if 'path_img_fr' not in df_val.columns:
        print("[ERROR] 'path_img_fr' not found even after merge!")
        print(f"Available columns: {df_val.columns.tolist()}")
        return

    temp_val_csv = "temp_val_with_paths.csv"
    df_val.to_csv(temp_val_csv, index=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    dataset = DualViewCXRDataset(
        csv_path=temp_val_csv,
        cfg=cfg1,
        split="val",
        transform=cxr_transform()
    )

    print(f"[INFO] Validation dataset size = {len(dataset)}")

    loader = DataLoader(
        dataset,
        batch_size=cfg1["training"]["batch_size"],
        shuffle=False,
        num_workers=4
    )

    backbone = timm.create_model(
        "swin_base_patch4_window7_224",
        pretrained=True,
        num_classes=0
    )

    model = DualViewSwin(
        backbone=backbone,
        out_dim=len(cfg1["data"]["label_columns"])
    ).to(device)

    state_dict = torch.load(CHECKPOINT, map_location=device)
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    
    print(f"[INFO] Missing keys: {missing}")
    print(f"[INFO] Unexpected keys: {unexpected}")
    
    # Check if cm_fusion weights are loaded
    if any("cm_fusion" in k for k in missing):
        print("[ERROR] cm_fusion weights are missing! Checkpoint may be from old training.")
        print("Please re-run Step 3 (run_train_swin_cm.py) with the updated code.")
    
    model.eval()

    rows = []
    cm_norms = []
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(loader):
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            subject_id = batch[-2]
            study_id = batch[-1]

            # CRITICAL FIX: Use the corrected extract_cm_dual function
            cm = extract_cm_dual(model, frontal, lateral)
            cm_np = cm.cpu().numpy()

            batch_norms = torch.norm(cm, dim=1).detach().cpu().numpy()
            cm_norms.extend(batch_norms.tolist())

            if batch_idx == 0:
                print(f"[DEBUG] First batch CM shape: {cm_np.shape}")
                print(f"[DEBUG] First batch CM sample: {cm_np[0, :5] if cm_np.shape[0] > 0 else 'N/A'}")
                print(f"[DEBUG] First batch CM norm: {batch_norms[0]:.4f}")

            for i in range(cm_np.shape[0]):
                row = {
                    "subject_id": str(subject_id[i]),
                    "study_id": str(study_id[i]),
                }
                for j in range(cm_np.shape[1]):
                    row[f"cm_{j}"] = float(cm_np[i, j])
                rows.append(row)

    df_results = pd.DataFrame(rows)
    
    # Check CM norms
    if len(cm_norms) > 0:
        norm_series = pd.Series(cm_norms)
        norm_min = float(norm_series.min())
        norm_max = float(norm_series.max())
        norm_std = float(norm_series.std())
        print(
            f"[DEBUG] CM norm stats -> min={norm_min:.6f}, "
            f"max={norm_max:.6f}, std={norm_std:.6f}"
        )

        # CRITICAL CHECK: With Soft Normalize, norms should be around 10.0
        if abs(norm_min - 10.0) > 2.0 or abs(norm_max - 10.0) > 2.0:
            print(
                f"[WARN] CM norms are not around 10.0 (expected with Soft Normalize). "
                f"Got range [{norm_min:.2f}, {norm_max:.2f}]. "
                f"This may indicate the checkpoint is from old training without Soft Normalize."
            )
    
    df_results.to_csv(OUTPUT_CSV, index=False)
    print(f"[INFO] Saved validation CM embeddings to: {OUTPUT_CSV}")
    
    if os.path.exists(temp_val_csv):
        os.remove(temp_val_csv)


if __name__ == "__main__":
    main()