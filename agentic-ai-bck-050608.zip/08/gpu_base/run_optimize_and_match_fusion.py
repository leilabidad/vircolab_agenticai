import os
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import dump
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src.vision.utils import load_cfg


# ----------------------------
# Helpers
# ----------------------------

def normalize_ids(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize subject_id / study_id to stable string form.
    Handles whitespace, '.0' suffix, tensor(...) wrappers, and null-ish text.
    """
    df = df.copy()

    for col in ("subject_id", "study_id"):
        if col not in df.columns:
            continue

        s = df[col].astype("string").str.strip()

        s = (
            s.str.replace(r"^tensor\(\s*", "", regex=True)
             .str.replace(r"\s*\)$", "", regex=True)
             .str.replace(r"\.0$", "", regex=True)
        )

        s = s.replace(
            {
                "<NA>": pd.NA,
                "nan": pd.NA,
                "None": pd.NA,
                "null": pd.NA,
            }
        )

        df[col] = s

    return df


def ensure_cols(df: pd.DataFrame, cols, name: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise KeyError(f"{name} is missing columns: {missing}")


def require_path(paths: dict, key: str, default=None) -> Path:
    value = paths.get(key, default)
    if not value:
        raise KeyError(f"Missing required config path: paths.{key}")

    path = Path(value).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"Configured path does not exist for paths.{key}: {path}")
    return path


def pick_merge_keys(*dfs):
    if all({"subject_id", "study_id"}.issubset(df.columns) for df in dfs):
        return ["subject_id", "study_id"]
    if all("study_id" in df.columns for df in dfs):
        return ["study_id"]
    raise KeyError("All input datasets must share study_id, or subject_id and study_id.")


def assert_unique_keys(df: pd.DataFrame, keys, name: str) -> None:
    dup = df[df.duplicated(keys, keep=False)]
    if not dup.empty:
        sample = dup[keys].drop_duplicates().head(10).to_dict("records")
        raise ValueError(f"{name} has duplicate merge keys {keys}; examples: {sample}")


def safe_numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").fillna(0.0).astype(float)


def clean_labels(df: pd.DataFrame, label_cols) -> pd.DataFrame:
    """
    Convert multilabel disease targets to clean binary ints.
    Anything equal to 1 becomes 1, everything else becomes 0.
    """
    df = df.copy()
    for c in label_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
        df[c] = (df[c] == 1.0).astype(int)
    return df


def mean_auc(y_true: np.ndarray, scores: np.ndarray, label_cols) -> float:
    """
    Mean ROC-AUC across label columns using the same scalar score.
    Skips labels that contain only one class.
    """
    aucs = []

    for i, label in enumerate(label_cols):
        y = np.asarray(y_true[:, i]).astype(int)
        if np.unique(y).size < 2:
            warnings.warn(f"Skipping AUC for {label}: only one class present.")
            continue
        aucs.append(roc_auc_score(y, scores))

    if not aucs:
        raise ValueError("No validation label contains both positive and negative cases.")

    return float(np.mean(aucs))


def build_cm_model():
    """
    Build a multilabel classifier for CM embeddings.
    """
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler(with_mean=False)),
        ("model", MultiOutputClassifier(
            LogisticRegression(
                max_iter=2000,
                class_weight="balanced",
                solver="lbfgs",
            )
        )),
    ])


def predict_multilabel_mean_positive_score(pipe, X: pd.DataFrame) -> np.ndarray:
    """
    For MultiOutputClassifier, predict_proba returns a list of [N, C] arrays.
    We extract the positive-class probability per label and then average over labels.
    """
    probs_list = pipe.predict_proba(X)

    if not isinstance(probs_list, list):
        probs_list = [probs_list]

    per_label_scores = []

    for probs in probs_list:
        probs = np.asarray(probs)

        if probs.ndim != 2:
            raise ValueError(f"Invalid predict_proba output shape: {probs.shape}")

        if probs.shape[1] == 1:
            # Degenerate classifier with one known class
            score = probs[:, 0].astype(float)
        else:
            score = probs[:, 1].astype(float)

        per_label_scores.append(score)

    if not per_label_scores:
        raise ValueError("No probability outputs were produced by the CM model")

    stacked = np.vstack(per_label_scores).T  # [N, L]
    return stacked.mean(axis=1)


def get_scores(cm_path, sc_path, name, emb_cols, pipe):
    print(f"\n>>> Processing {name} fusion...")

    df_cm = normalize_ids(pd.read_csv(cm_path))
    df_sc = normalize_ids(pd.read_csv(sc_path))

    ensure_cols(df_cm, emb_cols, f"{name} CM")

    if "score" in df_sc.columns:
        sc_col = "score"
    elif "sc_score" in df_sc.columns:
        sc_col = "sc_score"
    else:
        raise KeyError(f"{name} SC requires either 'score' or 'sc_score'")

    keys = pick_merge_keys(df_cm, df_sc)

    assert_unique_keys(df_cm, keys, f"{name} CM")
    assert_unique_keys(df_sc, keys, f"{name} SC")

    X = df_cm[emb_cols].apply(pd.to_numeric, errors="coerce")
    cm_score = predict_multilabel_mean_positive_score(pipe, X)

    cm_out = df_cm[keys].copy()
    cm_out["cm_score"] = cm_score

    sc_out = df_sc[keys].copy()
    sc_out["sc_score"] = safe_numeric(df_sc[sc_col])

    merged = cm_out.merge(
        sc_out,
        on=keys,
        how="inner",
        validate="one_to_one",
    )

    if merged.empty:
        raise ValueError(f"{name} CM/SC merge produced zero rows")

    print(f"[OK] {name} merged rows: {len(merged)}")
    print(
        f"[DEBUG] {name} cm_score stats: "
        f"min={merged['cm_score'].min():.6f}, "
        f"max={merged['cm_score'].max():.6f}, "
        f"mean={merged['cm_score'].mean():.6f}, "
        f"std={merged['cm_score'].std():.6f}"
    )
    print(
        f"[DEBUG] {name} sc_score stats: "
        f"min={merged['sc_score'].min():.6f}, "
        f"max={merged['sc_score'].max():.6f}, "
        f"mean={merged['sc_score'].mean():.6f}, "
        f"std={merged['sc_score'].std():.6f}"
    )

    return merged, keys


# ----------------------------
# Main
# ----------------------------

def main():
    cfg = load_cfg("./config/config.yaml")
    cfg1 = load_cfg("./config/vision_config.yaml")

    paths = cfg.get("paths", {})
    if not isinstance(paths, dict):
        raise TypeError("config.yaml: paths must be a mapping")

    full_csv_path = require_path(paths, "mimic_prepared_csv")
    cm_train_csv = require_path(paths, "cm_embedding")
    cm_val_csv = require_path(paths, "cm_val_output", "../gpu_base/results/final_mimic_cm_val_output.csv")
    cm_test_csv = require_path(paths, "cm_test_output")
    sc_val_csv = require_path(paths, "sc_val_output", "../gpu_base/results/final_mimic_sc_val_output.csv")
    sc_test_csv = require_path(paths, "sc_test_output")
    val_ids_path = require_path(
        paths,
        "final_mimic_visit_level_val_study_ids",
        "../gpu_base/results/final_mimic_visit_level_val_study_ids.csv",
    )

    out_dir = Path(paths.get("fusion_output_dir", "../gpu_base/results/fusion/")).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    label_cols = cfg1.get("data", {}).get("label_columns")
    if isinstance(label_cols, str):
        label_cols = [label_cols]
    if not label_cols:
        raise KeyError("vision_config.yaml: data.label_columns is required")

    print("[INFO] Loading data...")
    print(f"[INFO] full_csv_path = {full_csv_path}")
    print(f"[INFO] cm_train_csv  = {cm_train_csv}")
    print(f"[INFO] cm_val_csv    = {cm_val_csv}")
    print(f"[INFO] cm_test_csv   = {cm_test_csv}")
    print(f"[INFO] sc_val_csv    = {sc_val_csv}")
    print(f"[INFO] sc_test_csv   = {sc_test_csv}")
    print(f"[INFO] val_ids_path  = {val_ids_path}")
    print(f"[INFO] out_dir       = {out_dir}")

    # --------------------------------------------------
    # Load CM training embeddings + metadata labels
    # --------------------------------------------------
    print("[INFO] Loading training CM embeddings and metadata labels...")
    df_cm_train = normalize_ids(pd.read_csv(cm_train_csv))
    df_full = normalize_ids(pd.read_csv(full_csv_path))

    emb_cols = [c for c in df_cm_train.columns if c.startswith("cm_")]
    if not emb_cols:
        raise KeyError(
            "No CM embedding columns found in cm_embedding CSV "
            "(expected columns starting with 'cm_')"
        )

    ensure_cols(df_full, label_cols, "Full metadata CSV")

    train_keys = pick_merge_keys(df_cm_train, df_full)

    assert_unique_keys(df_cm_train, train_keys, "CM training embeddings")
    assert_unique_keys(df_full, train_keys, "Full metadata")

    df_full = clean_labels(df_full, label_cols)

    df_train = df_cm_train.merge(
        df_full[train_keys + label_cols],
        on=train_keys,
        how="inner",
        validate="one_to_one",
    )

    if df_train.empty:
        raise ValueError("Training merge between cm_embedding and full metadata produced zero rows")

    print(f"[INFO] CM train merged rows = {len(df_train)}")
    print(f"[INFO] CM train merge keys = {train_keys}")

    for c in emb_cols:
        df_train[c] = pd.to_numeric(df_train[c], errors="coerce")

    X_train = df_train[emb_cols]
    y_train = df_train[label_cols].values.astype(int)

    print(f"[INFO] CM embedding dims = {len(emb_cols)}")
    print(f"[INFO] Training CM multilabel model on {len(df_train)} rows...")

    pipe = build_cm_model()
    pipe.fit(X_train, y_train)

    model_path = out_dir / "cm_multilabel_model.joblib"
    dump(pipe, model_path)
    print(f"[INFO] Saved CM model to {model_path}")

    # --------------------------------------------------
    # Build validation and test CM/SC score tables
    # --------------------------------------------------
    val_base, val_keys = get_scores(cm_val_csv, sc_val_csv, "Validation", emb_cols, pipe)
    test_base, test_keys = get_scores(cm_test_csv, sc_test_csv, "Test", emb_cols, pipe)

    # --------------------------------------------------
    # Validation ground-truth
    # --------------------------------------------------
    df_val_ids = normalize_ids(pd.read_csv(val_ids_path))

    gt_keys = pick_merge_keys(df_val_ids, df_full)
    assert_unique_keys(df_full, gt_keys, "Full metadata")

    df_val_ids = df_val_ids.drop_duplicates(gt_keys)

    val_gt = df_val_ids[gt_keys].merge(
        df_full[gt_keys + label_cols],
        on=gt_keys,
        how="inner",
        validate="one_to_one",
    )

    if val_gt.empty:
        raise ValueError("Validation IDs did not match any rows in full metadata")

    print(f"[INFO] validation ground-truth rows = {len(val_gt)}")

    val_final = val_base.merge(
        val_gt[gt_keys + label_cols],
        on=gt_keys,
        how="inner",
        validate="one_to_one",
    )

    if val_final.empty:
        raise ValueError("Validation fusion output did not match validation ground truth")

    print(f"[INFO] validation merged rows = {len(val_final)}")
    print(f"[INFO] test merged rows = {len(test_base)}")

    # --------------------------------------------------
    # Search alpha on validation
    # --------------------------------------------------
    y_val = val_final[label_cols].values.astype(int)
    cm_scores = val_final["cm_score"].values.astype(float)
    sc_scores = val_final["sc_score"].values.astype(float)

    best_alpha = 0.5
    best_auc = -np.inf

    for alpha in np.linspace(0.0, 1.0, 21):
        fused = alpha * cm_scores + (1.0 - alpha) * sc_scores
        auc = mean_auc(y_val, fused, label_cols)
        print(f"[DEBUG] alpha={alpha:.2f} mean_auc={auc:.6f}")

        if auc > best_auc:
            best_auc = auc
            best_alpha = float(alpha)

    print(f"[INFO] Optimal CM weight (alpha): {best_alpha:.4f}")
    print(f"[INFO] Validation mean AUC: {best_auc:.6f}")

    # --------------------------------------------------
    # Apply alpha
    # --------------------------------------------------
    val_final["fusion_score"] = best_alpha * val_final["cm_score"] + (1.0 - best_alpha) * val_final["sc_score"]
    test_base["fusion_score"] = best_alpha * test_base["cm_score"] + (1.0 - best_alpha) * test_base["sc_score"]

    # --------------------------------------------------
    # Save outputs
    # --------------------------------------------------
    val_out = out_dir / "fusion_val_results.csv"
    test_out = out_dir / "fusion_test_results.csv"
    alpha_out = out_dir / "best_alpha.json"

    val_final.to_csv(val_out, index=False)
    test_base.to_csv(test_out, index=False)

    with open(alpha_out, "w", encoding="utf-8") as f:
        json.dump(
            {
                "best_alpha": best_alpha,
                "val_mean_auc": best_auc,
                "train_merge_keys": train_keys,
                "validation_merge_keys": val_keys,
                "test_merge_keys": test_keys,
                "ground_truth_merge_keys": gt_keys,
                "label_columns": label_cols,
                "num_cm_features": len(emb_cols),
                "cm_train_rows": int(len(df_train)),
                "val_rows": int(len(val_final)),
                "test_rows": int(len(test_base)),
                "full_csv_path": str(full_csv_path),
                "cm_train_csv": str(cm_train_csv),
                "cm_val_csv": str(cm_val_csv),
                "cm_test_csv": str(cm_test_csv),
                "sc_val_csv": str(sc_val_csv),
                "sc_test_csv": str(sc_test_csv),
                "val_ids_path": str(val_ids_path),
                "model_path": str(model_path),
            },
            f,
            indent=2,
            ensure_ascii=False,
        )

    print("\n[SUCCESS] Fusion completed.")
    print(f"[SUCCESS] Validation results: {val_out}")
    print(f"[SUCCESS] Test results: {test_out}")
    print(f"[SUCCESS] Alpha metadata: {alpha_out}")
    print(f"[SUCCESS] CM model: {model_path}")


if __name__ == "__main__":
    main()
