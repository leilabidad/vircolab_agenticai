from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split


# =========================
# Config
# =========================
FULL_CSV = Path("../gpu_base/results/final_mimic_visit_level.csv")
FIXED_TEST_CSV = Path("../gpu_base/results/final_mimic_visit_level_test.csv")
OUT_VAL_IDS_CSV = Path("../gpu_base/results/final_mimic_visit_level_val_study_ids.csv")

RANDOM_STATE = 42
VAL_RATIO_OF_FULL = 0.10   # حدود 10٪ از کل داده
SUBJECT_COL = "subject_id"
STUDY_COL = "study_id"

# ستون outcome را از بین این گزینه‌ها پیدا می‌کنیم
POSSIBLE_OUTCOME_COLS = [
    "outcome",
    "label",
    "target",
    "mortality",
    "hospital_expire_flag",
    "death",
]


def find_first_existing_column(df: pd.DataFrame, candidates: list[str], col_role: str) -> str:
    for c in candidates:
        if c in df.columns:
            return c
    raise KeyError(
        f"Could not find {col_role} column. Tried: {candidates}. "
        f"Available columns: {list(df.columns)}"
    )


def main():
    print(f"Reading main dataset from: {FULL_CSV}")
    full_df = pd.read_csv(FULL_CSV)

    print(f"Reading fixed test dataset from: {FIXED_TEST_CSV}")
    test_df = pd.read_csv(FIXED_TEST_CSV)

    # -------------------------
    # Validate required columns
    # -------------------------
    for col in [SUBJECT_COL, STUDY_COL]:
        if col not in full_df.columns:
            raise KeyError(f"Column '{col}' not found in full dataset. Columns: {list(full_df.columns)}")
        if col not in test_df.columns:
            raise KeyError(f"Column '{col}' not found in fixed test dataset. Columns: {list(test_df.columns)}")

    outcome_col = find_first_existing_column(full_df, POSSIBLE_OUTCOME_COLS, "outcome/label")

    # -------------------------
    # Normalize ID types
    # -------------------------
    full_df[SUBJECT_COL] = full_df[SUBJECT_COL].astype(str)
    full_df[STUDY_COL] = full_df[STUDY_COL].astype(str)

    test_df[SUBJECT_COL] = test_df[SUBJECT_COL].astype(str)
    test_df[STUDY_COL] = test_df[STUDY_COL].astype(str)

    # -------------------------
    # Remove fixed test subjects from candidates
    # to avoid subject leakage
    # -------------------------
    test_subjects = set(test_df[SUBJECT_COL].unique())
    test_studies = set(test_df[STUDY_COL].unique())

    candidate_df = full_df[~full_df[SUBJECT_COL].isin(test_subjects)].copy()

    print(f"Full rows: {len(full_df):,}")
    print(f"Fixed test rows: {len(test_df):,}")
    print(f"Candidate rows after removing test subjects: {len(candidate_df):,}")

    if candidate_df.empty:
        raise ValueError("Candidate dataframe is empty after removing fixed test subjects.")

    # -------------------------
    # Build subject-level table
    # -------------------------
    subject_outcome_df = (
        candidate_df[[SUBJECT_COL, outcome_col]]
        .drop_duplicates()
        .copy()
    )

    outcome_counts = subject_outcome_df.groupby(SUBJECT_COL)[outcome_col].nunique()
    bad_subjects = outcome_counts[outcome_counts > 1].index.tolist()

    if bad_subjects:
        print(
            f"WARNING: Found {len(bad_subjects)} subjects with multiple outcome values. "
            f"Using first outcome per subject."
        )
        subject_outcome_df = (
            candidate_df[[SUBJECT_COL, outcome_col]]
            .drop_duplicates(subset=[SUBJECT_COL], keep="first")
            .copy()
        )
    else:
        subject_outcome_df = (
            subject_outcome_df
            .drop_duplicates(subset=[SUBJECT_COL], keep="first")
            .copy()
        )

    n_full_rows = len(full_df)
    target_val_rows = round(n_full_rows * VAL_RATIO_OF_FULL)

    val_fraction_within_candidates = target_val_rows / len(candidate_df)
    val_fraction_within_candidates = min(max(val_fraction_within_candidates, 0.01), 0.5)

    print(f"Outcome column detected: {outcome_col}")
    print(f"Target validation rows (~10% of full): {target_val_rows:,}")
    print(f"Validation fraction within candidate pool: {val_fraction_within_candidates:.4f}")

    # -------------------------
    # Subject-level stratified split
    # -------------------------
    subjects = subject_outcome_df[SUBJECT_COL]
    y = subject_outcome_df[outcome_col]

    try:
        train_subjects, val_subjects = train_test_split(
            subjects,
            test_size=val_fraction_within_candidates,
            random_state=RANDOM_STATE,
            stratify=y,
        )
    except ValueError as e:
        print(f"Stratified split failed: {e}")
        print("Falling back to non-stratified subject-level split.")
        train_subjects, val_subjects = train_test_split(
            subjects,
            test_size=val_fraction_within_candidates,
            random_state=RANDOM_STATE,
            stratify=None,
        )

    train_subjects = set(train_subjects.astype(str))
    val_subjects = set(val_subjects.astype(str))

    # -------------------------
    # Construct train/validation dataframes
    # -------------------------
    train_df = candidate_df[candidate_df[SUBJECT_COL].isin(train_subjects)].copy()
    val_df = candidate_df[candidate_df[SUBJECT_COL].isin(val_subjects)].copy()

    if train_df.empty:
        raise ValueError("Train dataframe is empty after subject-level split.")
    if val_df.empty:
        raise ValueError("Validation dataframe is empty after subject-level split.")

    train_studies = set(train_df[STUDY_COL].unique())
    val_studies = (
        val_df[[STUDY_COL]]
        .drop_duplicates()
        .sort_values(STUDY_COL)
        .reset_index(drop=True)
    )

    # -------------------------
    # Final leakage checks
    # -------------------------
    train_subject_set = set(train_df[SUBJECT_COL].unique())
    val_subject_set = set(val_df[SUBJECT_COL].unique())
    val_study_set = set(val_df[STUDY_COL].unique())

    subject_overlap_train_val = train_subject_set.intersection(val_subject_set)
    study_overlap_train_val = train_studies.intersection(val_study_set)

    subject_overlap_with_test = val_subject_set.intersection(test_subjects)
    study_overlap_with_test = val_study_set.intersection(test_studies)

    if subject_overlap_train_val:
        raise AssertionError(
            f"Subject leakage detected between train and validation: "
            f"{len(subject_overlap_train_val)} overlapping subjects"
        )

    if study_overlap_train_val:
        raise AssertionError(
            f"Study overlap detected between train and validation: "
            f"{len(study_overlap_train_val)} overlapping studies"
        )

    if subject_overlap_with_test:
        raise AssertionError(
            f"Subject leakage detected between validation and fixed test: "
            f"{len(subject_overlap_with_test)} overlapping subjects"
        )

    if study_overlap_with_test:
        raise AssertionError(
            f"Study overlap detected between validation and fixed test: "
            f"{len(study_overlap_with_test)} overlapping studies"
        )

    # -------------------------
    # Save output
    # -------------------------
    OUT_VAL_IDS_CSV.parent.mkdir(parents=True, exist_ok=True)
    val_studies.to_csv(OUT_VAL_IDS_CSV, index=False)

    # -------------------------
    # Summary
    # -------------------------
    print("\nValidation split created successfully.")
    print(f"Saved validation study IDs to: {OUT_VAL_IDS_CSV}")
    print(f"Train subjects: {train_df[SUBJECT_COL].nunique():,}")
    print(f"Validation subjects: {val_df[SUBJECT_COL].nunique():,}")
    print(f"Validation studies: {val_df[STUDY_COL].nunique():,}")
    print(f"Validation rows: {len(val_df):,}")

    if outcome_col in val_df.columns:
        print("\nValidation outcome distribution:")
        print(val_df[outcome_col].value_counts(dropna=False))




    # -------------------------
    # Final full audit: train / val / test leakage report
    # -------------------------
    print("\n" + "=" * 72)
    print("FINAL SPLIT AUDIT")
    print("=" * 72)

    train_subject_set = set(train_df[SUBJECT_COL].unique())
    train_study_set = set(train_df[STUDY_COL].unique())

    val_subject_set = set(val_df[SUBJECT_COL].unique())
    val_study_set = set(val_df[STUDY_COL].unique())

    test_subject_set = set(test_df[SUBJECT_COL].unique())
    test_study_set = set(test_df[STUDY_COL].unique())

    def report_overlap(left_name, left_set, right_name, right_set, id_name):
        overlap = left_set.intersection(right_set)
        count = len(overlap)
        status = "OK" if count == 0 else "LEAK"
        print(f"[{status}] {id_name:<10} {left_name:<5} vs {right_name:<5}: {count:>6}")
        if count > 0:
            sample = sorted(list(overlap))[:10]
            print(f"       sample {id_name}s: {sample}")
        return count, overlap

    print("\nSplit sizes:")
    print(f"  Train : rows={len(train_df):,} | subjects={train_df[SUBJECT_COL].nunique():,} | studies={train_df[STUDY_COL].nunique():,}")
    print(f"  Val   : rows={len(val_df):,} | subjects={val_df[SUBJECT_COL].nunique():,} | studies={val_df[STUDY_COL].nunique():,}")
    print(f"  Test  : rows={len(test_df):,} | subjects={test_df[SUBJECT_COL].nunique():,} | studies={test_df[STUDY_COL].nunique():,}")

    print("\nOverlap checks:")
    subj_tv_count, subj_tv_overlap = report_overlap("train", train_subject_set, "val", val_subject_set, "subject_id")
    subj_tt_count, subj_tt_overlap = report_overlap("train", train_subject_set, "test", test_subject_set, "subject_id")
    subj_vt_count, subj_vt_overlap = report_overlap("val", val_subject_set, "test", test_subject_set, "subject_id")

    study_tv_count, study_tv_overlap = report_overlap("train", train_study_set, "val", val_study_set, "study_id")
    study_tt_count, study_tt_overlap = report_overlap("train", train_study_set, "test", test_study_set, "study_id")
    study_vt_count, study_vt_overlap = report_overlap("val", val_study_set, "test", test_study_set, "study_id")

    total_issues = (
        subj_tv_count + subj_tt_count + subj_vt_count +
        study_tv_count + study_tt_count + study_vt_count
    )

    if total_issues == 0:
        print("\n[PASS] No leakage detected across train / val / test.")
        print("       subject_id overlap = 0 for all pairs")
        print("       study_id   overlap = 0 for all pairs")
    else:
        raise AssertionError(
            "Leakage detected in split audit. "
            f"subject overlaps total={subj_tv_count + subj_tt_count + subj_vt_count}, "
            f"study overlaps total={study_tv_count + study_tt_count + study_vt_count}"
        )

    print("=" * 72)




    print("\nDone.")


if __name__ == "__main__":
    main()