import pandas as pd
import torch
import numpy as np
import yaml
import json
import time
import joblib
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import Ridge
from sklearn.decomposition import PCA

start_time = time.time()

with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

cm_df = pd.read_csv(cfg["paths"]["cm_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].astype(str)
    df["study_id"] = df["study_id"].astype(str)

cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(sc_df[["subject_id", "study_id", "sc_embedding"]], on=["subject_id", "study_id"], how="inner")
    .merge(out_df[["subject_id", "study_id", "outcome"]], on=["subject_id", "study_id"], how="inner")
)

if len(base_df) < 10:
    raise ValueError("Too few aligned samples after merge")

y_true = base_df["outcome"].astype(int).values

# --------------------------------------------------
# CRITICAL FIX: Use PCA (Unsupervised) to extract meaningful scalars
# L2 Norm fails because SwinNet with LayerNorm produces constant-norm vectors.
# Mean fails because LayerNorm-ed vectors have near-zero mean.
# PCA finds the direction of maximum variance, preserving real information.
# --------------------------------------------------
cm_embeds = base_df[cm_cols].values
pca_cm = PCA(n_components=1, random_state=42)
cm_scalar = pca_cm.fit_transform(cm_embeds).ravel()
print(f"[INFO] PCA for CM: explained variance ratio = {pca_cm.explained_variance_ratio_[0]:.4f}")

def parse_embedding(value):
    if pd.isna(value): return None
    if isinstance(value, str):
        try: return [float(x) for x in value.strip("[]").split(",")]
        except ValueError: return None
    if isinstance(value, (list, tuple)): return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding)
valid_mask = parsed_embeddings.apply(lambda x: x is not None)
base_df = base_df.loc[valid_mask].reset_index(drop=True)
cm_scalar = cm_scalar[valid_mask.values]
y_true = y_true[valid_mask.values]

sc_vectors = np.array(parsed_embeddings.loc[valid_mask].tolist(), dtype=np.float32)
pca_sc = PCA(n_components=1, random_state=42)
sc_scalar = pca_sc.fit_transform(sc_vectors).ravel()
print(f"[INFO] PCA for SC: explained variance ratio = {pca_sc.explained_variance_ratio_[0]:.4f}")

# Save PCA models and scalers
output_dir = cfg["paths"].get("output_dir", "../gpu_base/results/")
joblib.dump(pca_cm, f"{output_dir}pca_cm.pkl")
joblib.dump(pca_sc, f"{output_dir}pca_sc.pkl")

scaler_cm = MinMaxScaler().fit(cm_scalar.reshape(-1, 1))
scaler_sc = MinMaxScaler().fit(sc_scalar.reshape(-1, 1))
joblib.dump(scaler_cm, f"{output_dir}scaler_cm.pkl")
joblib.dump(scaler_sc, f"{output_dir}scaler_sc.pkl")

Cm = scaler_cm.transform(cm_scalar.reshape(-1, 1)).ravel()
Sc = scaler_sc.transform(sc_scalar.reshape(-1, 1)).ravel()
Cm_Sc = Cm * Sc

X_processed = np.column_stack([Cm, Sc, Cm_Sc])

lr_model = Ridge(alpha=1.0)
lr_model.fit(X_processed, y_true)
weights = lr_model.coef_.tolist()
intercept = lr_model.intercept_

weights_json = {
    "w1": float(weights[0]),
    "w2": float(weights[1]),
    "w3": float(weights[2]),
    "intercept": float(intercept)
}

with open(cfg["paths"]["dcs_weights_json"], "w") as f:
    json.dump(weights_json, f, indent=4)

print(f"[INFO] Learned DCS weights: w1={weights_json['w1']:.4f}, w2={weights_json['w2']:.4f}, w3={weights_json['w3']:.4f}, intercept={weights_json['intercept']:.4f}")
print(f"[INFO] Saved PCA models and scalers to {output_dir}")

df_final = base_df[["subject_id", "study_id", "outcome"]].copy()
df_final["Cm"] = Cm
df_final["Sc"] = Sc
df_final["Cm_Sc"] = Cm_Sc
df_final["Rf_DCS"] = weights_json["w1"] * Cm + weights_json["w2"] * Sc + weights_json["w3"] * Cm_Sc + weights_json["intercept"]
df_final.to_csv(cfg["paths"]["rf_output"], index=False)

print("Finished successfully")
print("Elapsed time (s):", round(time.time() - start_time, 2))