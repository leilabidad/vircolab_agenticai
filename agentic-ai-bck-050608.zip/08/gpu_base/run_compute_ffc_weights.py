import pandas as pd
import torch
import numpy as np
import yaml
import json
import time
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression

# --------------------------------------------------
# Timing
# --------------------------------------------------
start_time = time.time()

# --------------------------------------------------
# Load configuration
# --------------------------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# --------------------------------------------------
# Load data
# --------------------------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# --------------------------------------------------
# Normalize IDs
# --------------------------------------------------
for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].astype(str)
    df["study_id"] = df["study_id"].astype(str)

# --------------------------------------------------
# Merge datasets
# --------------------------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(
        sc_df[["subject_id", "study_id", "sc_embedding"]],
        on=["subject_id", "study_id"],
        how="inner"
    )
    .merge(
        out_df[["subject_id", "study_id", "outcome"]],
        on=["subject_id", "study_id"],
        how="inner"
    )
)

if len(base_df) < 10:
    raise ValueError("Too few aligned samples after merge")

# --------------------------------------------------
# Parse SC embeddings
# --------------------------------------------------
def parse_embedding(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        try:
            return [float(x) for x in value.strip("[]").split(",")]
        except ValueError:
            return None
    if isinstance(value, (list, tuple)):
        return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding).dropna()
EXPECTED_DIM = parsed_embeddings.apply(len).iloc[0]
valid_mask = parsed_embeddings.apply(lambda x: x is not None and len(x) == EXPECTED_DIM)

base_df = base_df.loc[valid_mask].reset_index(drop=True)
sc_vectors = parsed_embeddings.loc[valid_mask].tolist()

# --------------------------------------------------
# Prepare full feature matrix
# --------------------------------------------------
cm_features = base_df[cm_cols].values
sc_features = np.array(sc_vectors)
X_full = np.hstack([cm_features, sc_features])
X_full_scaled = MinMaxScaler().fit_transform(X_full)
y_true = base_df["outcome"].astype(int).values

# --------------------------------------------------
# Linear Regression to compute weights (Full Feature Concat)
# --------------------------------------------------
lr_model = LinearRegression()
lr_model.fit(X_full_scaled, y_true)
weights = lr_model.coef_
intercept = lr_model.intercept_

weights_json = {
    "weights": weights.tolist(),
    "intercept": float(intercept)
}

# Save weights
with open("./results/full_feature_weights.json", "w") as f:
    json.dump(weights_json, f, indent=4)

# --------------------------------------------------
# Compute predictions
# --------------------------------------------------
y_pred_scores = X_full_scaled @ weights + intercept

df_final = base_df[["subject_id", "study_id", "outcome"]].copy()
df_final["y_pred"] = y_pred_scores
df_final.to_csv("./results/full_feature_predictions.csv", index=False)

# --------------------------------------------------
# Done
# --------------------------------------------------
print("Finished successfully")
print("Elapsed time (s):", round(time.time() - start_time, 2))
