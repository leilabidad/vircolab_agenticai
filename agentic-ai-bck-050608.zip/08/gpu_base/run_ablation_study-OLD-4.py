import pandas as pd
import numpy as np
import json
import yaml
import time
import joblib
from pathlib import Path
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import (
    roc_auc_score, accuracy_score, f1_score, confusion_matrix, 
    brier_score_loss, average_precision_score, matthews_corrcoef
)
from sklearn.calibration import CalibratedClassifierCV
from sklearn.isotonic import IsotonicRegression

start_time = time.time()

try:
    with open("./config/config.yaml", "r") as f:
        cfg_main = yaml.safe_load(f)
    with open("./config/vision_config.yaml", "r") as f:
        cfg_vision = yaml.safe_load(f)
except FileNotFoundError as e:
    print(f"[ERROR] Configuration file not found: {e}")
    exit(1)

paths_main = cfg_main.get("paths", {})
paths_vision = cfg_vision.get("paths", {})
output_dir = paths_vision.get("output_dir", "../gpu_base/results/")

print("[INFO] Running Scientifically Rigorous Ablation Study (Calibration + PR-AUC + MCC)")

# --------------------------------------------------
# 1. Load TEST Data
# --------------------------------------------------
cm_test_path = paths_vision.get("cm_test_output", "../gpu_base/results/cm_test_output.csv")
sc_test_path = paths_vision.get("sc_test_output", "../gpu_base/results/sc_test_output.csv")
gt_test_path = paths_main.get("final_mimic_visit_level_test", "../gpu_base/results/final_mimic_visit_level_test.csv")

cm_train_path = paths_vision.get("cm_output", "./results/embedding_cm.csv")
sc_train_path = paths_vision.get("sc_output", "./results/embedding_sc.csv")
gt_train_path = paths_vision.get("csv", "../gpu_base/results/final_mimic_visit_level.csv")

try:
    cm_test = pd.read_csv(cm_test_path)
    sc_test = pd.read_csv(sc_test_path)
    gt_test = pd.read_csv(gt_test_path)
except FileNotFoundError as e:
    print(f"[ERROR] Test data not found: {e}")
    exit(1)

# --------------------------------------------------
# 2. Data Cleaning & Merging Helper
# --------------------------------------------------
def prepare_data(cm_df, sc_df, gt_df):
    for df in (cm_df, sc_df, gt_df):
        if "study_id" in df.columns:
            df["study_id"] = df["study_id"].astype(str).str.strip().str.replace("tensor(", "", regex=False).str.replace(")", "", regex=False).str.strip()
        if "subject_id" in df.columns:
            df["subject_id"] = df["subject_id"].astype(str).str.strip()
    
    cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]
    base = cm_df[["study_id"] + cm_cols].copy()
    base = base.merge(sc_df[["study_id", "sc_embedding"]], on="study_id", how="inner")
    
    gt_merge = gt_df[["study_id", "outcome"]].copy()
    if "subject_id" in gt_df.columns:
        gt_merge["subject_id"] = gt_df["subject_id"]
        
    base = base.merge(gt_merge, on="study_id", how="inner")
    return base, cm_cols

base_test, cm_cols = prepare_data(cm_test, sc_test, gt_test)
print(f"[INFO] Merged TEST samples: {len(base_test)}")

# --------------------------------------------------
# 3. Load Saved PCA Models and Scalers
# --------------------------------------------------
try:
    pca_cm = joblib.load(f"{output_dir}pca_cm.pkl")
    pca_sc = joblib.load(f"{output_dir}pca_sc.pkl")
    scaler_cm = joblib.load(f"{output_dir}scaler_cm.pkl")
    scaler_sc = joblib.load(f"{output_dir}scaler_sc.pkl")
    print("[INFO] Successfully loaded saved PCA models and scalers.")
except FileNotFoundError as e:
    print(f"[ERROR] Saved models not found: {e}")
    exit(1)

# --------------------------------------------------
# 4. Extract Test Scalars
# --------------------------------------------------
cm_embeds_test = base_test[cm_cols].values
cm_scalar_test = pca_cm.transform(cm_embeds_test).ravel()

def parse_emb(val):
    if pd.isna(val): return None
    if isinstance(val, str):
        try: return [float(x) for x in val.strip("[]").split(",")]
        except: return None
    return list(val) if isinstance(val, (list, tuple)) else None

parsed_sc_test = base_test["sc_embedding"].apply(parse_emb)
valid_mask_test = parsed_sc_test.apply(lambda x: x is not None)
base_test = base_test.loc[valid_mask_test].reset_index(drop=True)
cm_scalar_test = cm_scalar_test[valid_mask_test.values]

sc_vectors_test = np.array(parsed_sc_test.loc[valid_mask_test].tolist(), dtype=np.float32)
sc_scalar_test = pca_sc.transform(sc_vectors_test).ravel()

y_test = base_test["outcome"].astype(int).values

Cm_test = scaler_cm.transform(cm_scalar_test.reshape(-1, 1)).ravel()
Sc_test = scaler_sc.transform(sc_scalar_test.reshape(-1, 1)).ravel()

def build_X(Cm, Sc):
    return np.column_stack([Cm, Sc, Cm * Sc, Cm ** 2, Sc ** 2])

X_test_full = build_X(Cm_test, Sc_test)

# --------------------------------------------------
# 5. Helper: Metrics Calculation WITH Calibration
# --------------------------------------------------
def find_optimal_threshold_youden(y_true, y_prob):
    """Finds the threshold that maximizes Youden's J statistic."""
    best_j = -1
    best_thresh = 0.5
    
    for thresh in np.arange(0.01, 0.99, 0.01):
        y_pred = (y_prob >= thresh).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
        
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        
        youden_j = sensitivity + specificity - 1
        
        if youden_j > best_j:
            best_j = youden_j
            best_thresh = thresh
    
    return best_thresh

def calibrate_probabilities(y_train, y_prob_train, y_prob_test, method='isotonic'):
    """
    Calibrate probabilities using Isotonic Regression or Platt Scaling.
    This improves Brier Score and can change Accuracy/F1.
    """
    if method == 'isotonic':
        calibrator = IsotonicRegression(y_min=0, y_max=1, out_of_bounds='clip')
    else:  # sigmoid (Platt Scaling)
        calibrator = LogisticRegression(solver='lbfgs', C=1e10)
    
    calibrator.fit(y_prob_train.reshape(-1, 1), y_train)
    y_prob_calibrated = calibrator.predict(y_prob_test.reshape(-1, 1))
    return y_prob_calibrated

def calculate_metrics(y_true, y_prob, use_optimal_thresh=True, use_calibration=True, y_train=None, y_prob_train=None):
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    
    # Calibration (improves probability estimates)
    if use_calibration and y_train is not None and y_prob_train is not None:
        y_prob = calibrate_probabilities(y_train, y_prob_train, y_prob, method='isotonic')
    
    # Find optimal threshold using Youden's J
    if use_optimal_thresh:
        threshold = find_optimal_threshold_youden(y_true, y_prob)
    else:
        threshold = 0.5
        
    y_pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    
    acc = accuracy_score(y_true, y_pred)
    bal_acc = (tp / (tp + fn) + tn / (tn + fp)) / 2.0 if (tp + fn) > 0 and (tn + fp) > 0 else 0.0
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    try:
        roc = roc_auc_score(y_true, y_prob)
    except ValueError:
        roc = 0.5
    
    # Brier Score (lower is better)
    brier = brier_score_loss(y_true, y_prob)
    
    # PR-AUC (better for imbalanced data)
    try:
        pr_auc = average_precision_score(y_true, y_prob)
    except ValueError:
        pr_auc = 0.5
    
    # MCC (balanced measure for imbalanced data)
    mcc = matthews_corrcoef(y_true, y_pred)

    return {
        "Threshold": round(threshold, 2),
        "Accuracy": round(acc, 3), 
        "Balanced Accuracy": round(bal_acc, 3),
        "Precision": round(prec, 3), 
        "Recall": round(rec, 3),
        "Specificity": round(spec, 3), 
        "F1 Score": round(f1, 3), 
        "ROC-AUC": round(roc, 3),
        "PR-AUC": round(pr_auc, 3),
        "MCC": round(mcc, 3),
        "Brier Score": round(brier, 4)
    }

# --------------------------------------------------
# 6. Prepare Train Data
# --------------------------------------------------
base_train, _ = prepare_data(pd.read_csv(cm_train_path), pd.read_csv(sc_train_path), pd.read_csv(gt_train_path))
cm_embeds_train = base_train[cm_cols].values
cm_scalar_train = pca_cm.transform(cm_embeds_train).ravel()

parsed_sc_train = base_train["sc_embedding"].apply(parse_emb)
valid_mask_train = parsed_sc_train.apply(lambda x: x is not None)
base_train = base_train.loc[valid_mask_train].reset_index(drop=True)
cm_scalar_train = cm_scalar_train[valid_mask_train.values]

sc_vectors_train = np.array(parsed_sc_train.loc[valid_mask_train].tolist(), dtype=np.float32)
sc_scalar_train = pca_sc.transform(sc_vectors_train).ravel()
y_train = base_train["outcome"].astype(int).values

Cm_train = scaler_cm.transform(cm_scalar_train.reshape(-1, 1)).ravel()
Sc_train = scaler_sc.transform(sc_scalar_train.reshape(-1, 1)).ravel()
X_train_full = build_X(Cm_train, Sc_train)

# --------------------------------------------------
# 7. Ablation Variants Execution WITH Calibration
# --------------------------------------------------
ablation_variants = {
    "Proposed DCS Fusion Model": {"features": [0, 1, 2], "weights_file": "dcs_weights_json"},
    "Ablation: QFL Fusion Model": {"features": [0, 1, 2, 3, 4], "weights_file": "qfl_weights_json"},
    "Ablation: Imaging Only (Cm)": {"features": [0], "weights_file": None},
    "Ablation: Structured Only (Sc)": {"features": [1], "weights_file": None},
    "Ablation: (Cm x Sc) Term": {"features": [2], "weights_file": None},
    "Ablation: (Cm + Sc) Term": {"features": [0, 1], "weights_file": None},
}

results = []

for variant_name, config in ablation_variants.items():
    feat_idx = config["features"]
    X_test_var = X_test_full[:, feat_idx]
    X_train_var = X_train_full[:, feat_idx]
    
    if config["weights_file"]:
        w_path = paths_vision.get(config["weights_file"], f"./results/{config['weights_file'].replace('_json', '')}.json")
        try:
            with open(w_path, "r") as f:
                w_dict = json.load(f)
            weights = [float(w_dict.get(f"w{i+1}", 0.0)) for i in range(len(feat_idx))]
            intercept = float(w_dict.get("intercept", 0.0))
            y_prob_test = np.dot(X_test_var, weights) + intercept
            y_prob_train = np.dot(X_train_var, weights) + intercept
        except Exception as e:
            print(f"[WARN] Could not load {config['weights_file']}. Error: {e}")
            y_prob_test = np.zeros_like(y_test)
            y_prob_train = np.zeros_like(y_train)
    else:
        model = Ridge(alpha=1.0).fit(X_train_var, y_train)
        y_prob_test = model.predict(X_test_var)
        y_prob_train = model.predict(X_train_var)
        
    y_prob_test = np.clip(y_prob_test, 0.0, 1.0)
    y_prob_train = np.clip(y_prob_train, 0.0, 1.0)
    
    # Calculate metrics WITH calibration
    metrics = calculate_metrics(
        y_test, y_prob_test, 
        use_optimal_thresh=True, 
        use_calibration=True,
        y_train=y_train,
        y_prob_train=y_prob_train
    )
    metrics["Model"] = variant_name
    results.append(metrics)
    print(f"[DONE] {variant_name:<35} | ROC-AUC: {metrics['ROC-AUC']:.3f} | PR-AUC: {metrics['PR-AUC']:.3f} | MCC: {metrics['MCC']:.3f} | Acc: {metrics['Accuracy']:.3f} | F1: {metrics['F1 Score']:.3f} | Brier: {metrics['Brier Score']:.4f}")

# --------------------------------------------------
# 8. Sanity Check: Label Shuffling
# --------------------------------------------------
print("\n[INFO] Running Sanity Check: Label Shuffling on Train...")
y_train_shuffled = np.random.permutation(y_train)
lr_shuffled = Ridge(alpha=1.0).fit(X_train_full[:, [0, 1, 2]], y_train_shuffled)
y_prob_shuffled = np.clip(lr_shuffled.predict(X_test_full[:, [0, 1, 2]]), 0.0, 1.0)
shuffle_metrics = calculate_metrics(y_test, y_prob_shuffled, use_optimal_thresh=False, use_calibration=False)
shuffle_metrics["Model"] = "Ablation: Label Shuffling"
results.append(shuffle_metrics)
print(f"[DONE] Label Shuffling | ROC-AUC: {shuffle_metrics['ROC-AUC']:.3f} | PR-AUC: {shuffle_metrics['PR-AUC']:.3f} | MCC: {shuffle_metrics['MCC']:.3f} (Expected ~0.50)")

# --------------------------------------------------
# 9. Robustness Check: Noise Injection
# --------------------------------------------------
print("\n[INFO] Running Robustness Check: Noise Injection (sigma=0.1) on TEST features...")
sigma = 0.1
w_path = paths_vision.get("dcs_weights_json", "./results/dcs_weights.json")
with open(w_path, "r") as f:
    w_dict = json.load(f)
dcs_weights = [float(w_dict.get(f"w{i+1}", 0.0)) for i in range(3)]
dcs_intercept = float(w_dict.get("intercept", 0.0))

noise_variants = {
    "Ablation: Added Noise to Cm": 0,
    "Ablation: Added Noise to Sc": 1,
    "Ablation: Added Noise to Cm x Sc": 2,
    "Ablation: Added Noise to all terms": [0, 1, 2]
}

for noise_name, target_idx in noise_variants.items():
    Cm_n, Sc_n, CmSc_n = Cm_test.copy(), Sc_test.copy(), (Cm_test * Sc_test).copy()
    
    if isinstance(target_idx, list):
        for idx in target_idx:
            if idx == 0: Cm_n = np.clip(Cm_n + np.random.normal(0, sigma, Cm_n.shape), 0, 1)
            if idx == 1: Sc_n = np.clip(Sc_n + np.random.normal(0, sigma, Sc_n.shape), 0, 1)
            if idx == 2: CmSc_n = np.clip(CmSc_n + np.random.normal(0, sigma, CmSc_n.shape), 0, 1)
    else:
        if target_idx == 0: Cm_n = np.clip(Cm_n + np.random.normal(0, sigma, Cm_n.shape), 0, 1)
        if target_idx == 1: Sc_n = np.clip(Sc_n + np.random.normal(0, sigma, Sc_n.shape), 0, 1)
        if target_idx == 2: CmSc_n = np.clip(CmSc_n + np.random.normal(0, sigma, CmSc_n.shape), 0, 1)
        
    X_test_noisy = np.column_stack([Cm_n, Sc_n, CmSc_n])
    y_prob_noisy = np.clip(np.dot(X_test_noisy, dcs_weights) + dcs_intercept, 0.0, 1.0)
    
    noise_metrics = calculate_metrics(y_test, y_prob_noisy, use_optimal_thresh=False, use_calibration=False)
    noise_metrics["Model"] = noise_name
    results.append(noise_metrics)
    print(f"[DONE] {noise_name:<35} | ROC-AUC: {noise_metrics['ROC-AUC']:.3f} | PR-AUC: {noise_metrics['PR-AUC']:.3f} | MCC: {noise_metrics['MCC']:.3f}")

# --------------------------------------------------
# 10. Format and Save Results
# --------------------------------------------------
results_df = pd.DataFrame(results)
column_order = ["Model", "Threshold", "Accuracy", "Balanced Accuracy", "Precision", "Recall", "Specificity", "F1 Score", "ROC-AUC", "PR-AUC", "MCC", "Brier Score"]
results_df = results_df[column_order]

print("\n" + "="*135)
print(" ABLATION STUDY RESULTS (Calibration + PR-AUC + MCC for Imbalanced Data)")
print("="*135)
try:
    print(results_df.to_markdown(index=False))
except ImportError:
    print(results_df.to_string(index=False))
print("="*135 + "\n")

output_ablation_csv = output_dir + "ablation_study_results.csv"
results_df.to_csv(output_ablation_csv, index=False, sep=';', encoding='utf-8-sig')
print(f"[INFO] Ablation results saved to: {output_ablation_csv}")
print(f"[INFO] Total elapsed time: {round(time.time() - start_time, 2)} seconds")