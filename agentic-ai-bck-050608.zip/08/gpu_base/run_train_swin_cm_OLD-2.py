import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from torch import optim
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.linear_model import Ridge
from sklearn.metrics import roc_auc_score

from src.vision.dataset import DualViewCXRDataset
from src.vision.utils import load_cfg, cxr_transform

# ---------------------------------------------------------
# 1. Advanced CmFusionBlock (with Soft Normalize)
# ---------------------------------------------------------
class CmFusionBlock(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        hidden = dim * 2

        self.fuse = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        self.gate = nn.Sequential(
            nn.Linear(dim * 4, dim),
            nn.Sigmoid()
        )

        self.refine = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU()
        )

    def forward(self, x_f, x_l):
        avg = 0.5 * (x_f + x_l)
        diff = torch.abs(x_f - x_l)
        prod = x_f * x_l

        fused_in = torch.cat([x_f, x_l, diff, prod], dim=1)

        gate = self.gate(fused_in)
        learned = self.fuse(fused_in)

        cm = gate * learned + (1.0 - gate) * avg
        cm = cm + 0.25 * diff
        cm = self.refine(cm)
        
        # Soft Normalize: scales to target_norm while preserving relative differences
        norm = torch.norm(cm, p=2, dim=1, keepdim=True).clamp(min=1e-6)
        target_norm = 10.0
        cm = cm * (target_norm / norm)
        
        return cm

# ---------------------------------------------------------
# 2. Model Wrapper
# ---------------------------------------------------------
class DualViewSwin(nn.Module):
    def __init__(self, backbone, out_dim):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = backbone.num_features
        self.cm_fusion = CmFusionBlock(self.embed_dim)
        self.classifier = nn.Linear(self.embed_dim, out_dim)

    def forward(self, frontal, lateral):
        x_f = self.backbone(frontal)
        x_l = self.backbone(lateral)
        cm = self.cm_fusion(x_f, x_l)
        logits = self.classifier(cm)
        return logits, cm

# ---------------------------------------------------------
# 3. Validation ROC-AUC Evaluation (FIXED: No Data Leakage)
# ---------------------------------------------------------
def extract_embeddings(model, loader, device):
    """Extract CM embeddings and study_ids from a dataloader."""
    model.eval()
    all_cm = []
    all_study_ids = []
    
    with torch.no_grad():
        for batch in loader:
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            study_ids = batch[-1]
            
            _, cm = model(frontal, lateral)
            all_cm.append(cm.cpu().numpy())
            all_study_ids.extend([
                s.item() if torch.is_tensor(s) else s for s in study_ids
            ])
    
    return np.vstack(all_cm), all_study_ids


def evaluate_val_roc(model, train_loader, val_loader, device, outcome_col="outcome"):
    """
    CRITICAL FIX: Fit Ridge on TRAIN, evaluate on VALIDATION.
    This prevents data leakage and gives a true estimate of CM quality.
    """
    val_df = val_loader.dataset.df if hasattr(val_loader.dataset, 'df') else None
    
    if val_df is None or outcome_col not in val_df.columns:
        print("[WARN] Cannot compute ROC-AUC: outcome column not available")
        return 0.5
    
    # Extract embeddings from both train and val
    cm_train, train_ids = extract_embeddings(model, train_loader, device)
    cm_val, val_ids = extract_embeddings(model, val_loader, device)
    
    # Map study_ids to outcomes
    train_df = train_loader.dataset.df
    train_df["study_id"] = train_df["study_id"].astype(str)
    val_df["study_id"] = val_df["study_id"].astype(str)
    
    # Get train labels
    train_id_str = [str(s) for s in train_ids]
    train_temp = pd.DataFrame({"study_id": train_id_str})
    train_temp = train_temp.merge(train_df[["study_id", outcome_col]], on="study_id", how="left")
    y_train = train_temp[outcome_col].values
    
    # Get val labels
    val_id_str = [str(s) for s in val_ids]
    val_temp = pd.DataFrame({"study_id": val_id_str})
    val_temp = val_temp.merge(val_df[["study_id", outcome_col]], on="study_id", how="left")
    y_val = val_temp[outcome_col].values
    
    # Filter NaNs
    train_valid = ~np.isnan(y_train)
    val_valid = ~np.isnan(y_val)
    
    if train_valid.sum() < 10 or val_valid.sum() < 10:
        print("[WARN] Too few valid labels for ROC-AUC computation")
        return 0.5
    
    cm_train = cm_train[train_valid]
    y_train = y_train[train_valid].astype(int)
    cm_val = cm_val[val_valid]
    y_val = y_val[val_valid].astype(int)
    
    if len(np.unique(y_train)) < 2 or len(np.unique(y_val)) < 2:
        print("[WARN] Only one class present")
        return 0.5
    
    # CRITICAL: Fit on TRAIN, evaluate on VALIDATION (no leakage!)
    try:
        probe = Ridge(alpha=10.0)  # Stronger regularization for high-dim
        probe.fit(cm_train, y_train)
        y_prob = probe.predict(cm_val)
        y_prob = np.clip(y_prob, 0.0, 1.0)
        roc = roc_auc_score(y_val, y_prob)
        return roc
    except Exception as e:
        print(f"[WARN] ROC-AUC computation failed: {e}")
        return 0.5

# ---------------------------------------------------------
# 4. Main Training Script with Early Stopping
# ---------------------------------------------------------
def main():
    cfg = load_cfg("./config/vision_config.yaml")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Train dataset
    train_dataset = DualViewCXRDataset(
        cfg["paths"]["csv"],
        cfg,
        cfg["data"]["train_split"],
        cxr_transform()
    )
    train_loader = DataLoader(
        train_dataset, 
        batch_size=cfg["training"]["batch_size"], 
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )
    
    # Validation dataset
    val_split = cfg["data"].get("val_split", "val")
    val_dataset = DualViewCXRDataset(
        cfg["paths"]["csv"],
        cfg,
        val_split,
        cxr_transform()
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=cfg["training"]["batch_size"],
        shuffle=False,
        num_workers=4,
        pin_memory=True
    )
    
    print(f"[INFO] Train samples: {len(train_dataset)}")
    print(f"[INFO] Validation samples: {len(val_dataset)}")

    backbone = timm.create_model(
        "swin_base_patch4_window7_224", 
        pretrained=True, 
        num_classes=0
    )
    
    model = DualViewSwin(
        backbone, 
        out_dim=len(cfg["data"]["label_columns"])
    ).to(device)

    optimizer = optim.AdamW(model.parameters(), lr=cfg["training"]["lr"])
    max_epochs = cfg["training"]["epochs"]
    
    # Early Stopping Parameters
    patience = cfg["training"].get("early_stop_patience", 3)
    best_val_roc = 0.0
    epochs_no_improve = 0
    best_state_dict = None
    best_epoch = 0
    
    print(f"\n[INFO] Starting training for up to {max_epochs} epochs...")
    print(f"[INFO] Early stopping patience: {patience} epochs")
    print(f"[INFO] Monitoring: Validation ROC-AUC (Train-fit, Val-evaluate)\n")
    
    model.train()

    for epoch in range(max_epochs):
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{max_epochs}")
        epoch_loss = 0
        
        for batch in pbar:
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            raw_labels = batch[2].to(device).float() 

            optimizer.zero_grad()
            logits, _ = model(frontal, lateral)

            valid_mask = (raw_labels != -1).float()
            targets = torch.where(raw_labels == -1, torch.zeros_like(raw_labels), raw_labels)

            loss_matrix = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
            masked_loss = (loss_matrix * valid_mask).sum() / valid_mask.sum().clamp(min=1e-6)

            masked_loss.backward()
            optimizer.step()

            epoch_loss += masked_loss.item()
            pbar.set_postfix({"loss": f"{masked_loss.item():.4f}"})

        avg_loss = epoch_loss / len(train_loader)
        print(f"Epoch {epoch+1} Average Train Loss: {avg_loss:.6f}")
        
        # Validation Evaluation (FIXED: no data leakage)
        val_roc = evaluate_val_roc(model, train_loader, val_loader, device)
        print(f"Epoch {epoch+1} Validation ROC-AUC (CM proxy): {val_roc:.4f}")
        
        if val_roc > best_val_roc + 1e-4:
            best_val_roc = val_roc
            epochs_no_improve = 0
            best_state_dict = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            best_epoch = epoch + 1
            print(f"  ✓ New best model! Saving checkpoint (ROC-AUC: {best_val_roc:.4f})")
        else:
            epochs_no_improve += 1
            print(f"  ✗ No improvement ({epochs_no_improve}/{patience})")
        
        if epochs_no_improve >= patience:
            print(f"\n[INFO] Early stopping triggered at epoch {epoch+1}")
            print(f"[INFO] Best epoch was {best_epoch} with ROC-AUC: {best_val_roc:.4f}")
            break
    
    # Load Best Model and Save Checkpoint
    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)
        print(f"\n[INFO] Loaded best model from epoch {best_epoch}")
    
    checkpoint_path = cfg["paths"]["checkpoint"]
    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
    torch.save(model.state_dict(), checkpoint_path)
    print(f"[INFO] Best model saved to {checkpoint_path}")

    # Final Cm Extraction (on TRAIN set)
    print("\n[INFO] Extracting final embeddings (Cm) from training set...")
    model.eval()
    all_rows = []

    with torch.no_grad():
        for batch in tqdm(train_loader, desc="Extraction"):
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            subject_ids = batch[-2]
            study_ids = batch[-1]

            _, cm = model(frontal, lateral)
            
            cm_np = cm.cpu().numpy()
            for i in range(len(subject_ids)):
                s_id = subject_ids[i].item() if torch.is_tensor(subject_ids[i]) else subject_ids[i]
                st_id = study_ids[i].item() if torch.is_tensor(study_ids[i]) else study_ids[i]
                
                row = {
                    "subject_id": s_id,
                    "study_id": st_id
                }
                for j, val in enumerate(cm_np[i]):
                    row[f"cm_{j}"] = val
                all_rows.append(row)

    df_cm = pd.DataFrame(all_rows)
    df_cm.to_csv(cfg["paths"]["cm_output"], index=False)
    print(f"[INFO] Train embeddings saved to {cfg['paths']['cm_output']}")
    print(f"[INFO] Final Validation ROC-AUC: {best_val_roc:.4f}")
    print(f"[INFO] Training completed successfully!")

if __name__ == "__main__":
    main()