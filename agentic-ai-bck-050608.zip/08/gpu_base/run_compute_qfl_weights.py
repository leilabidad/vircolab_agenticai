import pandas as pd
import numpy as np
import yaml
import json
import time
import joblib
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import Ridge

start_time = time.time()

with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

cm_df = pd.read_csv(cfg["paths"]["cm_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].astype(str)
    df["study_id"] = df["study_id"].astype(str)

cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]

base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(sc_df[["subject_id", "study_id", "sc_embedding"]], on=["subject_id", "study_id"], how="inner")
    .merge(out_df[["subject_id", "study_id", "outcome"]], on=["subject_id", "study_id"], how="inner")
)

if len(base_df) < 10:
    raise ValueError("Too few aligned samples after merge")

y_true = base_df["outcome"].astype(int).values

# --------------------------------------------------
# Load PCA models from Step 5 (ENSURE CONSISTENCY)
# --------------------------------------------------
output_dir = cfg["paths"].get("output_dir", "../gpu_base/results/")

try:
    pca_cm = joblib.load(f"{output_dir}pca_cm.pkl")
    pca_sc = joblib.load(f"{output_dir}pca_sc.pkl")
    scaler_cm = joblib.load(f"{output_dir}scaler_cm.pkl")
    scaler_sc = joblib.load(f"{output_dir}scaler_sc.pkl")
    print("[INFO] Successfully loaded PCA models and scalers from Step 5")
except FileNotFoundError as e:
    print(f"[ERROR] PCA models not found: {e}")
    print("Please run Step 5 (run_compute_dcs_weights.py) first.")
    exit(1)

# --------------------------------------------------
# Extract scalars using saved PCA models (CONSISTENT with Step 5)
# --------------------------------------------------
cm_embeds = base_df[cm_cols].values
cm_scalar = pca_cm.transform(cm_embeds).ravel()
print(f"[INFO] CM scalar range: [{cm_scalar.min():.4f}, {cm_scalar.max():.4f}]")

def parse_embedding(value):
    if pd.isna(value): return None
    if isinstance(value, str):
        try: return [float(x) for x in value.strip("[]").split(",")]
        except ValueError: return None
    if isinstance(value, (list, tuple)): return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding)
valid_mask = parsed_embeddings.apply(lambda x: x is not None)
base_df = base_df.loc[valid_mask].reset_index(drop=True)
cm_scalar = cm_scalar[valid_mask.values]
y_true = y_true[valid_mask.values]

sc_vectors = np.array(parsed_embeddings.loc[valid_mask].tolist(), dtype=np.float32)
sc_scalar = pca_sc.transform(sc_vectors).ravel()
print(f"[INFO] SC scalar range: [{sc_scalar.min():.4f}, {sc_scalar.max():.4f}]")

# --------------------------------------------------
# Normalize using saved scalers (CONSISTENT with Step 5)
# --------------------------------------------------
Cm = scaler_cm.transform(cm_scalar.reshape(-1, 1)).ravel()
Sc = scaler_sc.transform(sc_scalar.reshape(-1, 1)).ravel()

Cm_Sc = Cm * Sc
Cm2 = Cm ** 2
Sc2 = Sc ** 2

X_processed = np.column_stack([Cm, Sc, Cm_Sc, Cm2, Sc2])

# --------------------------------------------------
# Ridge Regression (with regularization to prevent overfitting)
# --------------------------------------------------
lr_model = Ridge(alpha=1.0)
lr_model.fit(X_processed, y_true)
weights = lr_model.coef_.tolist()
intercept = lr_model.intercept_

weights_json = {
    "w1": float(weights[0]),
    "w2": float(weights[1]),
    "w3": float(weights[2]),
    "w4": float(weights[3]),
    "w5": float(weights[4]),
    "intercept": float(intercept)
}

with open(cfg["paths"]["qfl_weights_json"], "w") as f:
    json.dump(weights_json, f, indent=4)

print(f"[INFO] Learned QFL weights: w1={weights_json['w1']:.4f}, w2={weights_json['w2']:.4f}, w3={weights_json['w3']:.4f}, w4={weights_json['w4']:.4f}, w5={weights_json['w5']:.4f}, intercept={weights_json['intercept']:.4f}")

# --------------------------------------------------
# Compute QFL predictions
# --------------------------------------------------
df_final = base_df[["subject_id", "study_id", "outcome"]].copy()
df_final["Cm"] = Cm
df_final["Sc"] = Sc
df_final["Cm_Sc"] = Cm_Sc
df_final["Cm2"] = Cm2
df_final["Sc2"] = Sc2

df_final["Rf_QFL"] = (
    weights_json["w1"] * Cm +
    weights_json["w2"] * Sc +
    weights_json["w3"] * Cm_Sc +
    weights_json["w4"] * Cm2 +
    weights_json["w5"] * Sc2 +
    weights_json["intercept"]
)

df_final.to_csv(cfg["paths"]["rf_qfl_output"], index=False)

print("Finished successfully")
print("Elapsed time (s):", round(time.time() - start_time, 2))