import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from torch import optim
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.linear_model import Ridge
from sklearn.metrics import roc_auc_score

from src.vision.dataset import DualViewCXRDataset
from src.vision.utils import load_cfg, cxr_transform

# ---------------------------------------------------------
# 1. Advanced CmFusionBlock (with Soft Normalize)
# ---------------------------------------------------------
class CmFusionBlock(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        hidden = dim * 2

        self.fuse = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.LayerNorm(dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        self.gate = nn.Sequential(
            nn.Linear(dim * 4, dim),
            nn.Sigmoid()
        )

        self.refine = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.GELU()
        )

    def forward(self, x_f, x_l):
        avg = 0.5 * (x_f + x_l)
        diff = torch.abs(x_f - x_l)
        prod = x_f * x_l

        fused_in = torch.cat([x_f, x_l, diff, prod], dim=1)

        gate = self.gate(fused_in)
        learned = self.fuse(fused_in)

        cm = gate * learned + (1.0 - gate) * avg
        cm = cm + 0.25 * diff
        cm = self.refine(cm)
        
        # Soft Normalize
        norm = torch.norm(cm, p=2, dim=1, keepdim=True).clamp(min=1e-6)
        target_norm = 10.0
        cm = cm * (target_norm / norm)
        
        return cm

# ---------------------------------------------------------
# 2. Model Wrapper
# ---------------------------------------------------------
class DualViewSwin(nn.Module):
    def __init__(self, backbone, out_dim):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = backbone.num_features
        self.cm_fusion = CmFusionBlock(self.embed_dim)
        self.classifier = nn.Linear(self.embed_dim, out_dim)

    def forward(self, frontal, lateral):
        x_f = self.backbone(frontal)
        x_l = self.backbone(lateral)
        cm = self.cm_fusion(x_f, x_l)
        logits = self.classifier(cm)
        return logits, cm

# ---------------------------------------------------------
# 3. Helper: Interpret Cm Strength
# ---------------------------------------------------------
def interpret_cm_strength(roc_auc):
    """Provides a human-readable assessment of Cm quality."""
    if roc_auc < 0.55:
        return "WEAK (Cm is mostly random. Needs more training or stronger backbone.)"
    elif 0.55 <= roc_auc < 0.65:
        return "MODERATE (Cm has some signal. Good for fusion, but relies on text.)"
    elif 0.65 <= roc_auc < 0.75:
        return "STRONG (Cm is very predictive on its own!)"
    else:
        return "VERY STRONG (Excellent visual features!)"

# ---------------------------------------------------------
# 4. Validation ROC-AUC Evaluation
# ---------------------------------------------------------
def extract_embeddings(model, loader, device):
    model.eval()
    all_cm = []
    all_study_ids = []
    
    with torch.no_grad():
        for batch in loader:
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            study_ids = batch[-1]
            
            _, cm = model(frontal, lateral)
            all_cm.append(cm.cpu().numpy())
            all_study_ids.extend([
                s.item() if torch.is_tensor(s) else s for s in study_ids
            ])
    
    return np.vstack(all_cm), all_study_ids


def evaluate_val_roc(model, train_loader, val_loader, device, outcome_col="outcome"):
    val_df = val_loader.dataset.df if hasattr(val_loader.dataset, 'df') else None
    if val_df is None or outcome_col not in val_df.columns:
        return 0.5
    
    cm_train, train_ids = extract_embeddings(model, train_loader, device)
    cm_val, val_ids = extract_embeddings(model, val_loader, device)
    
    train_df = train_loader.dataset.df
    train_df["study_id"] = train_df["study_id"].astype(str)
    val_df["study_id"] = val_df["study_id"].astype(str)
    
    train_id_str = [str(s) for s in train_ids]
    train_temp = pd.DataFrame({"study_id": train_id_str})
    train_temp = train_temp.merge(train_df[["study_id", outcome_col]], on="study_id", how="left")
    y_train = train_temp[outcome_col].values
    
    val_id_str = [str(s) for s in val_ids]
    val_temp = pd.DataFrame({"study_id": val_id_str})
    val_temp = val_temp.merge(val_df[["study_id", outcome_col]], on="study_id", how="left")
    y_val = val_temp[outcome_col].values
    
    train_valid = ~np.isnan(y_train)
    val_valid = ~np.isnan(y_val)
    
    if train_valid.sum() < 10 or val_valid.sum() < 10:
        return 0.5
    
    cm_train = cm_train[train_valid]
    y_train = y_train[train_valid].astype(int)
    cm_val = cm_val[val_valid]
    y_val = y_val[val_valid].astype(int)
    
    if len(np.unique(y_train)) < 2 or len(np.unique(y_val)) < 2:
        return 0.5
    
    try:
        # Alpha=10.0 is good for high-dimensional embeddings
        probe = Ridge(alpha=10.0)
        probe.fit(cm_train, y_train)
        y_prob = probe.predict(cm_val)
        y_prob = np.clip(y_prob, 0.0, 1.0)
        roc = roc_auc_score(y_val, y_prob)
        return roc
    except Exception:
        return 0.5

# ---------------------------------------------------------
# 5. Main Training Script (ENHANCED)
# ---------------------------------------------------------
def main():
    cfg = load_cfg("./config/vision_config.yaml")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Datasets
    train_dataset = DualViewCXRDataset(cfg["paths"]["csv"], cfg, cfg["data"]["train_split"], cxr_transform())
    train_loader = DataLoader(train_dataset, batch_size=cfg["training"]["batch_size"], shuffle=True, num_workers=4, pin_memory=True)
    
    val_split = cfg["data"].get("val_split", "val")
    val_dataset = DualViewCXRDataset(cfg["paths"]["csv"], cfg, val_split, cxr_transform())
    val_loader = DataLoader(val_dataset, batch_size=cfg["training"]["batch_size"], shuffle=False, num_workers=4, pin_memory=True)
    
    print(f"[INFO] Train samples: {len(train_dataset)} | Val samples: {len(val_dataset)}")

    # --- CHANGE 1: Stronger Backbone (Optional but recommended by professor) ---
    # If you have enough VRAM, change 'swin_base...' to 'swin_large_patch4_window7_224' in config or here.
    backbone_name = cfg["training"].get("backbone_name", "swin_base_patch4_window7_224")
    print(f"[INFO] Using Backbone: {backbone_name}")
    
    backbone = timm.create_model(backbone_name, pretrained=True, num_classes=0)
    
    model = DualViewSwin(backbone, out_dim=len(cfg["data"]["label_columns"])).to(device)

    # --- CHANGE 2: Differential Learning Rates (Professional Fine-Tuning) ---
    # Lower LR for backbone (to keep pre-trained features), higher LR for new fusion layers
    base_lr = cfg["training"]["lr"]
    optimizer = optim.AdamW([
        {'params': model.backbone.parameters(), 'lr': base_lr * 0.1, 'weight_decay': 0.01},
        {'params': list(model.cm_fusion.parameters()) + list(model.classifier.parameters()), 'lr': base_lr, 'weight_decay': 0.01}
    ])

    # --- CHANGE 3: Cosine Annealing Scheduler ---
    max_epochs = cfg["training"]["epochs"]
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_epochs, eta_min=1e-6)

    patience = cfg["training"].get("early_stop_patience", 5) # Increased patience for better fine-tuning
    best_val_roc = 0.0
    epochs_no_improve = 0
    best_state_dict = None
    best_epoch = 0
    
    print(f"\n[INFO] Starting Enhanced Training for {max_epochs} epochs...")
    print(f"[INFO] Strategy: Differential LR + Cosine Scheduler + Patience={patience}\n")
    
    model.train()

    for epoch in range(max_epochs):
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{max_epochs}")
        epoch_loss = 0
        
        for batch in pbar:
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            raw_labels = batch[2].to(device).float() 

            optimizer.zero_grad()
            logits, _ = model(frontal, lateral)

            valid_mask = (raw_labels != -1).float()
            targets = torch.where(raw_labels == -1, torch.zeros_like(raw_labels), raw_labels)

            loss_matrix = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
            masked_loss = (loss_matrix * valid_mask).sum() / valid_mask.sum().clamp(min=1e-6)

            masked_loss.backward()
            optimizer.step()

            epoch_loss += masked_loss.item()
            pbar.set_postfix({"loss": f"{masked_loss.item():.4f}"})

        avg_loss = epoch_loss / len(train_loader)
        scheduler.step() # Update LR
        current_lr = optimizer.param_groups[0]['lr']
        
        print(f"Epoch {epoch+1} | Train Loss: {avg_loss:.4f} | LR: {current_lr:.6f}")
        
        # Evaluate Cm Strength
        val_roc = evaluate_val_roc(model, train_loader, val_loader, device)
        strength_status = interpret_cm_strength(val_roc)
        print(f"Epoch {epoch+1} | Cm ROC-AUC: {val_roc:.4f} | Status: {strength_status}")
        
        # Early Stopping Logic
        if val_roc > best_val_roc + 1e-4:
            best_val_roc = val_roc
            epochs_no_improve = 0
            best_state_dict = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            best_epoch = epoch + 1
            print(f"  [BEST] New best Cm! Saving checkpoint.")
        else:
            epochs_no_improve += 1
            print(f"  [WAIT] No improvement ({epochs_no_improve}/{patience})")
        
        if epochs_no_improve >= patience:
            print(f"\n[STOP] Early stopping triggered. Best epoch: {best_epoch} (ROC-AUC: {best_val_roc:.4f})")
            break
    
    # Load Best Model
    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)
        print(f"\n[INFO] Loaded best model from epoch {best_epoch}")
    
    checkpoint_path = cfg["paths"]["checkpoint"]
    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
    torch.save(model.state_dict(), checkpoint_path)
    print(f"[INFO] Checkpoint saved to {checkpoint_path}")

    # Final Extraction
    print("\n[INFO] Extracting final Cm embeddings...")
    model.eval()
    all_rows = []
    with torch.no_grad():
        for batch in tqdm(train_loader, desc="Extraction"):
            frontal = batch[0].to(device)
            lateral = batch[1].to(device)
            subject_ids = batch[-2]
            study_ids = batch[-1]
            _, cm = model(frontal, lateral)
            cm_np = cm.cpu().numpy()
            for i in range(len(subject_ids)):
                s_id = subject_ids[i].item() if torch.is_tensor(subject_ids[i]) else subject_ids[i]
                st_id = study_ids[i].item() if torch.is_tensor(study_ids[i]) else study_ids[i]
                row = {"subject_id": s_id, "study_id": st_id}
                for j, val in enumerate(cm_np[i]):
                    row[f"cm_{j}"] = val
                all_rows.append(row)

    df_cm = pd.DataFrame(all_rows)
    df_cm.to_csv(cfg["paths"]["cm_output"], index=False)
    print(f"[INFO] Done! Final Cm ROC-AUC proxy: {best_val_roc:.4f}")

if __name__ == "__main__":
    main()