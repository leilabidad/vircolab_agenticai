# run_audit_before_eval.py
import json
import warnings
from pathlib import Path
import yaml
import pandas as pd

# تنظیمات پیکربندی
BASE_CFG = Path("./config/config.yaml")
VISION_CFG = Path("./config/vision_config.yaml")

def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def normalize_ids(df: pd.DataFrame) -> pd.DataFrame:
    """نرمال‌سازی شناسه‌ها برای جلوگیری از خطای تطابق به دلیل نوع داده"""
    df = df.copy()
    for col in ["subject_id", "study_id"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.replace(r"\.0$", "", regex=True)
                .str.replace(r"tensor\(", "", regex=True)
                .str.replace(r"\)", "", regex=True)
            )
    return df

def require_cols(df, required, name):
    """بررسی وجود ستون‌های حیاتی"""
    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f"{name}: missing columns {missing}")

def load_csv(path, name):
    """بارگذاری ایمن فایل‌های CSV"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{name}: not found at -> {p.resolve()}")
    return pd.read_csv(p)

def main():
    print(">>> Starting Comprehensive Audit before Step 14 (Evaluation)...")
    
    # تنظیمات اولیه گزارش
    report = {
        "status": "PASS",
        "split_policy": "study_level",
        "checks": {},
        "warnings": [],
    }

    # بارگذاری کانفیگ‌ها
    vision_cfg = load_yaml(VISION_CFG)
    base_cfg = load_yaml(BASE_CFG)
    paths = base_cfg.get("paths", {})
    
    # شناسایی ستون‌های لیبل (Multi-label support)
    label_cols = vision_cfg["data"]["label_columns"]
    if isinstance(label_cols, str):
        label_cols = [label_cols]

    # تعیین مسیر دقیق فایل‌های خروجی گام ۱۲ و متادیتا
    full_csv_path = paths.get("mimic_prepared_csv")
    cm_train_csv = paths.get("cm_embedding")
    fusion_output_dir = Path(paths.get("fusion_output_dir", "../gpu_base/results/fusion/"))
    
    fusion_val_path = fusion_output_dir / "fusion_val_results.csv"
    fusion_test_path = fusion_output_dir / "fusion_test_results.csv"

    print(">>> Loading datasets and normalizing IDs...")
    df_full = normalize_ids(load_csv(full_csv_path, "Metadata (Full)"))
    df_cm_train = normalize_ids(load_csv(cm_train_csv, "CM Training Set"))
    df_fusion_val = normalize_ids(load_csv(fusion_val_path, "Fusion Validation Results"))
    df_fusion_test = normalize_ids(load_csv(fusion_test_path, "Fusion Test Results"))

    # صحت‌سنجی ساختار فایل‌ها
    require_cols(df_full, ["study_id"] + label_cols, "Metadata")
    require_cols(df_cm_train, ["study_id"], "Training Data")
    require_cols(df_fusion_val, ["study_id", "fusion_score"], "Val Results")
    require_cols(df_fusion_test, ["study_id", "fusion_score"], "Test Results")

    # -------- تحلیل نشت اطلاعات (Leakage Analysis) --------
    train_studies = set(df_cm_train["study_id"].dropna())
    val_studies = set(df_fusion_val["study_id"].dropna())
    test_studies = set(df_fusion_test["study_id"].dropna())

    study_leak_val = sorted(train_studies & val_studies)
    study_leak_test = sorted(train_studies & test_studies)
    study_leak_val_test = sorted(val_studies & test_studies)

    # ذخیره در گزارش
    report["checks"]["leakage"] = {
        "train_val_study_overlap": len(study_leak_val),
        "train_test_study_overlap": len(study_leak_test),
        "val_test_study_overlap": len(study_leak_val_test),
    }

    # بررسی نشت در سطح بیمار (Subject Level)
    if "subject_id" in df_cm_train.columns and "subject_id" in df_fusion_test.columns:
        train_subjs = set(df_cm_train["subject_id"].dropna())
        test_subjs = set(df_fusion_test["subject_id"].dropna())
        subj_leak = sorted(train_subjs & test_subjs)
        report["checks"]["leakage"]["train_test_subject_overlap"] = len(subj_leak)
        if subj_leak:
            report["warnings"].append(
                f"Subject-level overlap: {len(subj_leak)} subjects appear in both Train and Test."
            )

    # -------- تعیین وضعیت نهایی ممیزی (Gatekeeping Logic) --------
    if study_leak_test:
        # نشت در دیتای تست خطای قرمز (بحرانی) است
        report["status"] = "FAIL"
        report["checks"]["leakage"]["status"] = "CRITICAL_FAIL"
        report["checks"]["leakage"]["reason"] = f"CRITICAL: {len(study_leak_test)} studies leaked into TEST set!"
    elif study_leak_val:
        # نشت در دیتای ولیدیشن (با توجه به فرآیند فعلی) پذیرفتنی اما همراه با هشدار است
        report["status"] = "WARNING"
        report["warnings"].append(
            f"Validation Leakage Detected: {len(study_leak_val)} studies overlap with Training. "
            "This is acceptable for Alpha optimization, provided the TEST set is clean."
        )
        report["checks"]["leakage"]["status"] = "WARNING_VAL_LEAK"
    else:
        report["status"] = "PASS"
        report["checks"]["leakage"]["status"] = "PASS"

    # -------- ذخیره و نمایش خروجی --------
    fusion_output_dir.mkdir(parents=True, exist_ok=True)
    report_path = fusion_output_dir / "audit_report_final.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 65)
    print("                FINAL AUDIT REPORT (Pre-Evaluation)")
    print("=" * 65)
    print(f"Overall Status       : {report['status']}")
    print(f"Total Train Studies  : {len(train_studies)}")
    print(f"Total Test Studies   : {len(test_studies)}")
    print("-" * 65)
    print(f"Leakage Train-Val    : {len(study_leak_val)} (STATUS: ALLOWED WITH WARNING)")
    print(f"Leakage Train-Test   : {len(study_leak_test)} (STATUS: {'FAIL' if study_leak_test else 'PASS'})")
    print(f"Audit Report Saved   : {report_path.resolve()}")
    print("=" * 65)

    if report["warnings"]:
        print("\n[!] Warnings:")
        for w in report["warnings"]:
            print(f"    - {w}")

    # توقف برنامه فقط در صورت نشت در دیتای تست
    if report["status"] == "FAIL":
        print("\n[ERROR] Audit failed due to critical leakage in Test set. Evaluation aborted.")
        raise RuntimeError("Critical Data Leakage in Test Set!")
    
    print("\n>>> Audit verification successful. You may proceed to Step 14.")

if __name__ == "__main__":
    main()
