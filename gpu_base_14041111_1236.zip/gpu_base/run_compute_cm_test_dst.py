import pandas as pd
import torch
import timm
from torch.utils.data import DataLoader
from src.vision.dataset import DualViewCXRDataset
from src.vision.model import DualViewSwin
from src.vision.utils import load_cfg, cxr_transform

# --------------------------------------------------
# Config & device
# --------------------------------------------------
cfg = load_cfg("./config/config.yaml")
cfg1 = load_cfg("./config/vision_config.yaml")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.backends.cudnn.benchmark = True

# --------------------------------------------------
# Paths
# --------------------------------------------------
FULL_CSV = cfg["paths"]["mimic_prepared_csv"]
TRAIN_CM_CSV = cfg["paths"]["cm_embedding"]
TEST_CSV = cfg["paths"]["final_mimic_visit_level_test"]
TEST_CM_OUT = cfg["paths"]["cm_test_output"]

# --------------------------------------------------
# Load full dataset
# --------------------------------------------------
full_df = pd.read_csv(FULL_CSV)
full_df["study_id"] = full_df["study_id"].astype(str)

# --------------------------------------------------
# Load train CM embeddings
# --------------------------------------------------
train_df = pd.read_csv(TRAIN_CM_CSV)
train_df["study_id"] = train_df["study_id"].astype(str)
train_studies = set(train_df["study_id"])

# --------------------------------------------------
# Build test-only dataframe
# --------------------------------------------------
test_df = full_df[~full_df["study_id"].isin(train_studies)]

# ---------------- HARD SAFETY CHECKS ----------------
if len(test_df) == 0:
    raise RuntimeError("❌ Test set is EMPTY. All studies are seen in training.")

overlap = set(test_df["study_id"]) & train_studies
if len(overlap) > 0:
    raise RuntimeError(
        f"❌ DATA LEAKAGE DETECTED: {len(overlap)} overlapping study_ids"
    )

print("✅ Train/Test separation verified")
print(f"Train studies: {len(train_studies)}")
print(f"Test records:  {len(test_df)}")

# --------------------------------------------------
# Add split column to ensure test dataset remains unchanged
# --------------------------------------------------
test_df[cfg1["data"]["split_column"]] = 'test'
test_df.to_csv(TEST_CSV, index=False)

# --------------------------------------------------
# Dataset & loader (TEST ONLY)
# --------------------------------------------------
dataset = DualViewCXRDataset(
    csv_path=TEST_CSV,
    cfg=cfg1,
    split='test',  # important
    transform=cxr_transform()
)

# ---------------- SANITY CHECK ----------------
if len(dataset) == 0:
    raise RuntimeError("❌ Test dataset is empty! Check CSV content and split column.")

sample = dataset[0]
print("Sample IDs (subject_id / study_id):", sample[3], sample[4])
print("Sample frontal/lateral types:", type(sample[0]), type(sample[1]))
print("Sample labels shape:", sample[2].shape)

loader = DataLoader(
    dataset,
    batch_size=cfg1["training"]["batch_size"],
    shuffle=False,
    num_workers=4
)

# --------------------------------------------------
# Model (MUST match training)
# --------------------------------------------------
backbone = timm.create_model(
    "swin_base_patch4_window7_224",
    pretrained=True,
    num_classes=0
)

model = DualViewSwin(
    backbone=backbone,
    out_dim=len(cfg1["data"]["label_columns"])
).to(device)

state_dict = torch.load(cfg["paths"]["checkpoint"], map_location=device)
model.load_state_dict(state_dict, strict=True)
model.eval()

# --------------------------------------------------
# CM extraction
# --------------------------------------------------
def extract_cm_dual(model, frontal, lateral):
    f = model.backbone(frontal)
    l = model.backbone(lateral)
    return 0.5 * (f + l)

rows = []

with torch.no_grad():
    for batch in loader:
        frontal = batch[0].to(device)
        lateral = batch[1].to(device)
        subject_id = batch[-2]
        study_id = batch[-1]

        cm = extract_cm_dual(model, frontal, lateral).cpu().numpy()

        for i in range(cm.shape[0]):
            row = {
                "subject_id": str(subject_id[i]),
                "study_id": str(study_id[i])
            }
            for j, v in enumerate(cm[i]):
                row[f"cm_{j}"] = float(v)
            rows.append(row)

# --------------------------------------------------
# Save CM test embeddings
# --------------------------------------------------
pd.DataFrame(rows).to_csv(TEST_CM_OUT, index=False)

print(f"✅ CM test embeddings saved to: {TEST_CM_OUT}")
