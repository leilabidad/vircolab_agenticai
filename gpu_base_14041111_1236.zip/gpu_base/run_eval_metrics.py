import pandas as pd
import numpy as np
import json
import re
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    roc_auc_score, accuracy_score, balanced_accuracy_score,
    precision_score, recall_score, f1_score, confusion_matrix
)
import yaml

# -------------------------------
# Config
# -------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg1 = yaml.safe_load(f)

with open("./config/config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

FULL_CSV = cfg["paths"]["mimic_prepared_csv"]
CM_TEST = cfg["paths"]["cm_test_output"]
SC_TEST = cfg["paths"]["sc_test_output"]
WEIGHTS_JSON = cfg1["paths"]["dcs_weights_json"]

# -------------------------------
# Load weights
# -------------------------------
with open(WEIGHTS_JSON, "r") as f:
    weights = json.load(f)

# -------------------------------
# Load datasets
# -------------------------------
cm_df = pd.read_csv(CM_TEST)
sc_df = pd.read_csv(SC_TEST)
full_df = pd.read_csv(FULL_CSV)

# -------------------------------
# Clean IDs
# -------------------------------
def clean_id(x):
    if pd.isna(x):
        return ""
    x = str(x)
    nums = re.findall(r'\d+', x)
    return nums[0] if nums else ""

for df in [cm_df, sc_df, full_df]:
    df['subject_id'] = df['subject_id'].apply(clean_id)
    df['study_id'] = df['study_id'].apply(clean_id)

# -------------------------------
# Parse SC embeddings
# -------------------------------
def parse_embedding(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        try:
            return [float(x) for x in value.strip("[]").split(",")]
        except:
            return None
    if isinstance(value, (list, tuple)):
        return list(value)
    return None

sc_df["sc_vector"] = sc_df["sc_embedding"].apply(parse_embedding)
sc_df = sc_df.dropna(subset=["sc_vector"]).reset_index(drop=True)

# -------------------------------
# Align outcome from full CSV
# -------------------------------
outcome_df = full_df[["subject_id", "study_id", "outcome"]]
merged_df = (
    cm_df.merge(sc_df[["subject_id", "study_id", "sc_vector"]], on=["subject_id", "study_id"], how="inner")
          .merge(outcome_df, on=["subject_id", "study_id"], how="inner")
)
merged_df = merged_df[merged_df["outcome"].isin([0, 1])].reset_index(drop=True)
if merged_df.empty:
    raise RuntimeError("Merged dataset is empty. Check your IDs in CM, SC, and FULL CSV!")

# -------------------------------
# Compute DCS_RF
# -------------------------------
cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]
cm_values = merged_df[cm_cols].values.mean(axis=1)
sc_vectors = merged_df["sc_vector"].tolist()

def compute_rf(cm_values, sc_vectors, weights):
    cm_scaled = MinMaxScaler().fit_transform(cm_values.reshape(-1, 1)).ravel()
    sc_proj = np.array([np.mean(v) for v in sc_vectors])
    sc_scaled = MinMaxScaler().fit_transform(sc_proj.reshape(-1, 1)).ravel()
    cm_sc = cm_scaled * sc_scaled
    X = np.stack([cm_scaled, sc_scaled, cm_sc], axis=1)
    rf_pred = X @ np.array([weights["w1"], weights["w2"], weights["w3"]]) + weights["intercept"]
    return rf_pred

merged_df["DCS_RF"] = compute_rf(cm_values, sc_vectors, weights)

# -------------------------------
# Compute SwinNet 2D projection
# -------------------------------
# CM embeddings projection (mean + min-max)
cm_proj = merged_df[cm_cols].values.mean(axis=1)
swin_scaled = MinMaxScaler().fit_transform(cm_proj.reshape(-1, 1)).ravel()
merged_df["SwinNet_2D"] = swin_scaled

# -------------------------------
# Evaluation
# -------------------------------
y_true = merged_df["outcome"].astype(int).values
dcs_score = merged_df["DCS_RF"].values
swin_score = merged_df["SwinNet_2D"].values

def evaluate_model(y_true, score, model_name, threshold=0.5):
    score = np.nan_to_num(score, nan=0.0)
    y_pred = (score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    return {
        "model": model_name,
        "threshold": threshold,
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp + 1e-8),
        "f1_score": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, score)
    }

metrics = [
    evaluate_model(y_true, dcs_score, "DCS_RF"),
    evaluate_model(y_true, swin_score, "SwinNet_2D")
]

metrics_df = pd.DataFrame(metrics)
metrics_df.to_csv("./results/comparison_metrics_finalised.csv", index=False)

print("✅ RF & SwinNet_2D evaluation completed successfully.")
print(metrics_df)
