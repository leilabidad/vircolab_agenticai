import subprocess

def main():
    options = {
        "0": "run_prepare_metadata.py",
        "1": "run_prepare_dataset.py",
        "2": "run_minimize_dataset.py",
        "3": "run_train_swin_cm.py",
        "4": "run_compute_sc.py",
        "5": "run_compute_dcs_weights.py",
        "6": "run_compute_cm_test_dst.py",
        "7": "run_compute_sc_test_dst.py",
        "8": "run_eval_metrics.py"
    }

    print("Select the action to perform:")
    print("0: Prepare metadata")
    print("1: Prepare dataset")
    print("2: Minimize dataset")
    print("3: Train SwinNet 2D and compute Cm")
    print("4: Compute Sc")
    print("5: Compute DCS weights")
    print("6: Run compute Cm embedding for Test dataset")
    print("7: Run compute Sc embedding for Test dataset")
    print("8: Run compute RF & Evaluation Metrics ML")
        
    choice = input("Enter your choice (0-8): ").strip()
    script = options.get(choice)
    
    if script:
        subprocess.run(["python", script])
    else:
        print("Invalid choice")

if __name__ == "__main__":
    main()
