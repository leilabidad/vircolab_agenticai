import pandas as pd
import torch
import numpy as np
import yaml
import json
import time
from sklearn.preprocessing import MinMaxScaler
from scipy.optimize import minimize

# --------------------------------------------------
# Timing
# --------------------------------------------------
start_time = time.time()

# --------------------------------------------------
# Load configuration
# --------------------------------------------------
with open("./config/vision_config.yaml", "r") as f:
    cfg = yaml.safe_load(f)

# --------------------------------------------------
# Load data
# --------------------------------------------------
cm_df = pd.read_csv(cfg["paths"]["cm_output"])
sc_df = pd.read_csv(cfg["paths"]["sc_output"])
out_df = pd.read_csv(cfg["paths"]["csv"])

# --------------------------------------------------
# Normalize ID types
# --------------------------------------------------
for df in (cm_df, sc_df, out_df):
    df["subject_id"] = df["subject_id"].astype(str)
    df["study_id"] = df["study_id"].astype(str)

# --------------------------------------------------
# Sanity checks
# --------------------------------------------------
if "outcome" not in out_df.columns:
    raise ValueError("Missing required column: outcome")

cm_cols = [c for c in cm_df.columns if c.startswith("cm_")]
if not cm_cols:
    raise ValueError("No cm_ columns found in cm_df")

if "sc_embedding" not in sc_df.columns:
    raise ValueError("Missing sc_embedding column in sc_df")

# --------------------------------------------------
# Merge datasets (strict alignment)
# --------------------------------------------------
base_df = (
    cm_df[["subject_id", "study_id"] + cm_cols]
    .merge(
        sc_df[["subject_id", "study_id", "sc_embedding"]],
        on=["subject_id", "study_id"],
        how="inner"
    )
    .merge(
        out_df[["subject_id", "study_id", "outcome"]],
        on=["subject_id", "study_id"],
        how="inner"
    )
)

if len(base_df) < 10:
    raise ValueError("Too few aligned samples after merge")

# --------------------------------------------------
# CM projection
# --------------------------------------------------
cm_embeds = torch.tensor(
    base_df[cm_cols].values,
    dtype=torch.float32
)

cm_proj = cm_embeds.mean(dim=1).numpy().reshape(-1, 1)
cm_scaled = MinMaxScaler().fit_transform(cm_proj).ravel()

# --------------------------------------------------
# SC embedding parsing and validation (CRITICAL FIX)
# --------------------------------------------------
def parse_embedding(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        try:
            return [float(x) for x in value.strip("[]").split(",")]
        except ValueError:
            return None
    if isinstance(value, (list, tuple)):
        return list(value)
    return None

parsed_embeddings = base_df["sc_embedding"].apply(parse_embedding)

# Determine expected embedding dimension
valid_lengths = parsed_embeddings.dropna().apply(len)
if valid_lengths.empty:
    raise ValueError("No valid SC embeddings found")

EXPECTED_DIM = valid_lengths.iloc[0]

# Keep only rows with valid and correctly-sized embeddings
valid_mask = parsed_embeddings.apply(
    lambda x: x is not None and len(x) == EXPECTED_DIM
)

base_df = base_df.loc[valid_mask].reset_index(drop=True)
sc_vectors = parsed_embeddings.loc[valid_mask].tolist()
cm_scaled = cm_scaled[valid_mask.values]

# --------------------------------------------------
# SC projection
# --------------------------------------------------
sc_embeds = torch.tensor(
    sc_vectors,
    dtype=torch.float32
)

sc_proj = sc_embeds.mean(dim=1).numpy().reshape(-1, 1)
sc_scaled = MinMaxScaler().fit_transform(sc_proj).ravel()

# --------------------------------------------------
# Final modeling dataframe
# --------------------------------------------------
df = base_df[["subject_id", "study_id", "outcome"]].copy()
df["Cm"] = cm_scaled
df["Sc"] = sc_scaled
df["Cm_Sc"] = df["Cm"] * df["Sc"]

df = df.dropna().reset_index(drop=True)

# --------------------------------------------------
# Regression setup
# --------------------------------------------------
X = df[["Cm", "Sc", "Cm_Sc"]].values
y = df["outcome"].values

def loss(weights):
    prediction = X @ weights[:3] + weights[3]
    return np.mean((prediction - y) ** 2)

bounds = [
    (0, None),   # w1
    (0, None),   # w2
    (0, None),   # w3
    (None, None) # intercept
]

initial = np.array([0.1, 0.1, 0.1, 0.0])

result = minimize(loss, initial, bounds=bounds)

if not result.success:
    raise RuntimeError("Optimization failed: " + result.message)

w1, w2, w3, intercept = result.x

# --------------------------------------------------
# Predictions
# --------------------------------------------------
df["Rf_pred"] = X @ np.array([w1, w2, w3]) + intercept

# --------------------------------------------------
# Save outputs
# --------------------------------------------------
df.to_csv(cfg["paths"]["rf_output"], index=False)

weights = {
    "w1": float(w1),
    "w2": float(w2),
    "w3": float(w3),
    "intercept": float(intercept)
}

with open(cfg["paths"]["dcs_weights_json"], "w") as f:
    json.dump(weights, f, indent=4)

# --------------------------------------------------
# Done
# --------------------------------------------------
print("Finished successfully")
print("Elapsed time (s):", round(time.time() - start_time, 2))
